import React, {Component} from 'react';
import axios from 'axios';
import SavedWorkflow from './savedworkflow';
import SelectComp from './selectedworkflow';
import { Modal,Button} from 'react-bootstrap';
import Loader from '../../../components/Loader';
import setAuthToken from '../../../utils/setAuthToken';
class SavedWorkflows extends Component{
    state={
        saveddata:[            
        ],
        assigneddata:[],
        assigned:false,
        visible:false,
        selected: false,
        index: null,
        loading:false,
        startdate:null
    }

    componentWillMount(){
        
        setAuthToken()
      axios.get(`/api/workflowProcess/getWorkflowProcessActionCandidate?candidate=${this.props.props.match.params.id}`)
            .then(response=>{
                console.log("aaaaaaaaaaaaaaaaaa",response)
                if(response.data.data.length!==0){
                this.setState({assigned:true, assigneddata:response.data.data})}
            })
            .catch(error=>{console.log(error)})
    }

assignWorkflow(data){

    let abc={
        workflowId:data,
        candidate:this.props.props.match.params.id,
        startDate:this.state.startdate
    }
    console.log("Data passed",abc)
    this.setState({loading:true});
    setAuthToken()
    axios.post("/api/workflowProcess/processWorkflowAction",abc)
    .then(response=>{
        if(response.data.success){
         this.setState({loading:false,selected:false,assigned:true, assigneddata:response.data.data})   
        }
    }).catch((err)=>{
        this.setState({loading:false})
    })
}
    toggle=()=>{
        this.setState(prevState=>({
            visible: !prevState.visible
        }))
    }
    DateChange=(e)=>{
        this.setState({startdate:e.target.value})
    }
    assigntoggle=()=>{
        this.setState({assigned:false});
        this.loadWorkflows();
    }

        clickHandler=()=>{
            this.setState({visible:false, selected: false})
        }

        handleOptionChange = changeEvent => {
            this.setState({
              index: changeEvent.target.value
            });
          };
    
    loadWorkflows = ()=>{
        this.setState({
            visible: true
        })  
        setAuthToken()
         axios.get("/api/workflow/getWorkflow")
            .then(response=>{
                console.log("fetcheddata",response.data.data);
                    response.data.data.map(key=>{
                    let indiwork=key;
                    this.setState(prevState=>({
                        saveddata: [...prevState.saveddata,{...indiwork}]
                    }))
                })})
    }
          handleFormSubmit = formSubmitEvent => {
            formSubmitEvent.preventDefault();

            this.setState({ selected: true, visible: false})
          }; 

    render(){
    let button=null;

    if(this.state.visible){
        button=(
            this.state.saveddata.map((indivworkflow, index)=>{
            // console.log(indivworkflow);
            let newworkarray=indivworkflow.workflowItems;
            let newworkname=indivworkflow.workflowName;
            let totaldays=0;
            let totalactions=newworkarray.length;
            {newworkarray.map((indivObj)=>{
                    const newindiobj= {...indivObj};
                    if(Number(newindiobj.dayNo)>totaldays)
                        totaldays=Number(newindiobj.dayNo);
                })}   
                return  (<div className="form-check">
                                <label>
                                <input
                                    type="radio"
                                    name={newworkname}
                                    value={index}
                                    checked={this.state.index === index}
                                    onChange={this.handleOptionChange}
                                    className="form-check-input"
                                />
                                <SavedWorkflow  newworkname={newworkname} totalactions={totalactions} totaldays={totaldays} />
                                </label>
                            </div>
                    )
                        })
        )    
    }
    let saved=(<div>
        <Modal size='lg' show={this.state.visible} onHide={this.toggle}>
        <Modal.Header closeButton>
          <Modal.Title>Saved Workflows: </Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <form>
                {button}
                <div className="form-group">
                        <button style={{marginLeft:'35%'}} onClick={this.handleFormSubmit} className="btn btn-outline-primary .btn-block mt-2" type="submit">
                        Assign Workflow
                        </button>
                        <button style={{marginLeft:'10%', paddingLeft:'10', paddingRight:'10'}}  onClick={this.clickHandler} className="btn btn-outline-danger .btn-block mt-2" type="submit">
                        Cancel
                        </button>
                </div>
            </form>
        </Modal.Body>
        </Modal>
        <button className="btn btn-primary .btn-block mt-2" style={{padding:'10px',border:'none', marginTop:'0%', marginLeft:'40%'}} onClick={this.loadWorkflows}>Assign a Workflow</button>        
    </div>
        )
        if(this.state.assigned){
            let newworkname=this.state.assigneddata[0] &&this.state.assigneddata[0].workflow.workflowName;
            let newworkarray=this.state.assigneddata;
            saved=(<div style={{margin:'10px'}}>
            <h5>
                <span style={{paddingLeft:'20px'}}>Workflow: {newworkname}</span> <i class="far fa-edit" onClick={this.assigntoggle} 
            style={{ cursor:'pointer'}}></i>
            
         <span style={{float:'right', paddingRight:'20px'}}><input type="date" value={this.state.startdate} onChange={this.DateChange} className="form-control d-inline"/></span>
         </h5>
        {
            newworkarray.map((indivObj)=>{
                return <SelectComp editobj={indivObj} label={indivObj.actionType} time={indivObj.time} dayNo={indivObj.dayNo} 
                template={indivObj.template} actionType={indivObj.actionType} id={indivObj._id}/>
            })
        }</div>)
        }
    if(this.state.selected && !this.state.visible){
            let newworkarray=this.state.saveddata[this.state.index].workflowItems;
            let newworkname=this.state.saveddata[this.state.index].workflowName;
            saved=(<div style={{margin:'10px'}}>
                <h5>
                    <span style={{paddingLeft:'20px'}}>Workflow: {newworkname}</span> <i class="far fa-edit" onClick={this.toggle} style={{ cursor:'pointer'}}></i>            
                    <Button onClick={()=>this.assignWorkflow(this.state.saveddata[this.state.index]._id)}> Assign Workflow</Button>
                    <span style={{float:'right', paddingRight:'20px'}}><input type="date" value={this.state.startdate} onChange={this.DateChange} className="form-control d-inline"/></span>
                </h5>
            {
                newworkarray.map((indivObj)=>{
                    return <SelectComp label={indivObj.label} time={indivObj.time} dayNo={indivObj.dayNo} template={indivObj.template} actionType={indivObj.actionType} id={indivObj._id}/>
                })
            }</div>)
    }
return(
        <div>
            {this.loading && <Loader/>}
            {saved}
        </div>
            );
    }}
    export default SavedWorkflows;