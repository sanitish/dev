import React,{useState} from 'react';
import {Redirect} from 'react-router-dom';
import { Card, CardBody, CardHeader, Row, Col, Button } from 'reactstrap';
import MessageTemplates from './messagetemplate';
import EmailTemplates from './emailtemplates';
import FormTemplates from './formtemplates';


const SavedTemplates = () => {
    const [show,setShow]=useState(false);
    const [show1,setShow1]=useState(false);
    const [show2,setShow2]=useState(false);
    let message='',email='',form='';
const messageHandler=()=>{
    setShow(true);
}
const emailHandler=()=>{
    setShow1(true);
}
const formHandler=()=>{
    setShow2(true);
}

if(show){
    return <Redirect to="/apps/savedTemplates/message" />
}
if(show1){
    return <Redirect to="/apps/savedTemplates/email" />
}
if(show2){
    return <Redirect to="/apps/savedTemplates/form" />
}
    return (
        <React.Fragment>
            <Card>
                <CardBody>
                    <h3 className="mb-3 mt-0 header-title">Saved Templates</h3>

                    <Row className="bg-light p-3">
                        <Col xl={4} lg={6}>
                            <Card className="mb-4 mb-xl-0">
                                <CardHeader style={{backgroundColor:'dodgerblue', color:'white', paddingBottom:'33px', borderLeft:'2px solid dodgerblue',borderRadius:'15px 15px 0 0'}}>Email Templates</CardHeader>
                                <CardBody  style={{backgroundColor:'lightskyblue', color:'white', borderLeft:'2px solid lightskyblue',borderRadius:'0 0 15px 15px'}}>
                                    <p className="card-text">Choose from one of our saved Email template collection which are frequently used.</p>
                                    <Button style={{float:'right'}} color="primary" onClick={emailHandler}>Open</Button>
                                </CardBody>
                            </Card>
                        </Col>
                        <Col xl={4} lg={6}>
                            <Card className="mb-4 mb-xl-0">
                            <CardHeader style={{backgroundColor:'dodgerblue', color:'white', paddingBottom:'33px', borderLeft:'2px solid dodgerblue',borderRadius:'15px 15px 0 0'}}>SMS and Whatsapp Templates</CardHeader>
                            <CardBody  style={{backgroundColor:'lightskyblue', color:'white', borderLeft:'2px solid lightskyblue',borderRadius:'0 0 15px 15px'}}>
                                    <p className="card-text">Choose from one of our saved Message template collection which are frequently used.</p>
                                    <Button style={{float:'right'}} color="primary" onClick={messageHandler}>Open</Button>
                                </CardBody>
                            </Card>
                        </Col>
                        <Col xl={4} lg={6}>
                            <Card className="mb-4 mb-xl-0">
                            <CardHeader style={{backgroundColor:'dodgerblue', color:'white', paddingBottom:'33px', borderLeft:'2px solid dodgerblue',borderRadius:'15px 15px 0 0'}}>Form Templates</CardHeader>
                            <CardBody  style={{backgroundColor:'lightskyblue', color:'white', borderLeft:'2px solid lightskyblue',borderRadius:'0 0 15px 15px'}}>
                                    <p className="card-text">Choose from one of our saved Form template collection which are frequently used.</p>
                                    <Button style={{float:'right'}}color="primary" onClick={formHandler}>Open</Button>
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </CardBody>
            </Card>
            {email}
            {message}
            {form}
        </React.Fragment>
    );
};

export default SavedTemplates;
