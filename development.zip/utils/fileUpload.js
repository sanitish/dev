var AWS = require('aws-sdk')
var multer = require('multer')
var multerS3 = require('multer-s3')
var crypto = require('crypto');
var mime = require('mime');

AWS.config.update({
  secretAccessKey: "+FtW1WZgKXcMdv5MOXNzYEAYpsKM2V6LdlFR+yno",
  accessKeyId: "AKIAIU7CIDU6ZV6SBOKQ",
  region: 'ap-south-1' // region of your bucket
});

var s3 = new AWS.S3();
exports.s3 = s3;

exports.uploadFile = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'teststayspace/beamfox',
    acl: 'public-read',
    key: function(req, file, cb) {
        // console.log(req)
          // console.log(s3)
        console.log(file);
      crypto.pseudoRandomBytes(4, function(err, raw) {
        cb(null, file.originalname.split('.')[0] + Date.now() + '.' + mime.getExtension(file.mimetype));
      })
    }

  })
});