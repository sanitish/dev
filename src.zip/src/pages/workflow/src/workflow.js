import React, { Component } from 'react';
import axios from 'axios';
import classes from './workflow.module.css';
import EmailComp from './emailcomp';
import SmsComp from './smscomp';
import WhatsappComp from './whatsappcomp';
import CallComp from './callcomp';
import VideoComp from './videocomp';
import MeetComp from './meetcomp';
import FormComp from './formcomp';
import EditableLabel from 'react-editable-label'; 
import setAuthToken from '../../../utils/setAuthToken';
class Workflow extends Component{

    // componentWillMount(){
        
    //     setAuthToken()
    //   axios.get('/api/user/getUsers')
    //         .then(response=>{
    //             console.log("aaaaaaaaaaaaaaaaaa",response)
    //             if(response.data.data.length!==0){
    //             this.setState({assigned:true, assigneddata:response.data.data})}
    //         })
    //         .catch(error=>{console.log(error)})
    // }
    state={
        workflowarray:[],
        workappend:[],
        templates:['hello','how are you','long time no C'],
        dropdown:[
            { label: "Hey", value: 1 },
            { label: "Wassup", value: 2 },
            { label: "How are you?", value: 3 },
            { label: "Long time no see", value: 4 },
            { label: "any updates", value: 5 },
            { label: "lets meet", value: 6 },
          ],
          assignedname:[
            { label: "Suhail", value: 1 },
            { label: "Arpit", value: 2 },
            { label: "Kriti", value: 3 },
          ],
          messageTemplate:[
              `Hello Trudy, here’s a link to the corporate office, where your first week’s training will be held. Have fun tomorrow! https://beamfox.io/txthq`,
              `We’re so excited to have you join our team, Carla! We made this welcome video for you with staff intros and a campus tour – enjoy! https://beamfox.io/textwel`,
              `Lisabeth – Welcome to Beamfox! Here’s a link to your schedule for this first week (https://beamfox.io/m9ph5uj). If you have any questions, don’t hesitate to text or call me! — Suhail`,
              `Hi, it’s Brad at Beamfox, and I’ll be your staff trainer this week! Do you have any questions I can help you out with before your first day?`,
              `Hi John, just a reminder to bring your social security card, current picture ID, and completed paperwork along with you on Tues.`,
              `Sparla, which compliance session would work best for you: M 9-1, M 1-5, or W 11-3?`,
              `Hi Bernice! Just a reminder that you still need to complete your workplace behavior module before the end of the month. Here’s the link: https://beamfox.com/txtmb`,
              `Lydia – have you heard about the Beamfox Knowledge series that starts next Wed.? I think it’d really help you with your developer questions.`,
              `Ty, don’t miss out on your team’s sales training on Fri! Text me if you’ll be there – and with any lunch requests`,
              `We Know you’re busy, just wanted to confirm you’ll be at the sales training tomorrow – lots of tips to help you hit your goals!`,
              `The Lock Down Leads training is going on run in the conference room – and there’s pizza. Come on up!`,
              `Betsy, tomorrow is the last day to opt-in for dental and vision coverage. You mentioned you were interested in this – can I help you get signed up?`,
              `Renauldo – you mentioned you wanted to change your 401K deductions this quarter. Deadline is next Tuesday.`,
              `Hey team! Our partner benefits have expanded – join Gold’s Gym at a 25% discount with your employee id. `,
              `Hi Bob – I hope you’re having a good summer! We haven’t heard from you for a bit, so I thought I’d check in.`,
              `Are you still interested in remaining active on our freelance developers list? If so, I have a position that might be perfect for you.`
          ],
          formTemplate:[`
          First Name
          Last Name 
          Have you used a different name in the past?
          ⛒ Yes
          ⛒ No
          Current Address 
          Address Line 1
          Address Line 2
          City
          State
          Zip Code
          Have you lived at the previous address?
          ⛜ Yes
          ⛜ No
          Date of Birth
          Social Security Number
          Phone
          Drivers License Number
          Driver's License State
          The information above is correct to the best of my knowledge.*
          ⛛ Yes
          `,
        `Available To Start_______________________
        Referral Source___________________________
        Have you ever been employed by us before:   Yes/No
        Are you legally permitted to work in this country:    Yes/No
        Are you above the minimum working age of _______:  Yes/No
        Have you ever been convicted of a felony:   Yes/No
        If yes please explain__________________________
        A positive response is not an automatic bar to employment with the company. The offense for which the person was convicted in relation to the position to which they have applied will be considered.
        Please indicate availability to work:
        Monday
        Tuesday
        Wednesday
        Thursday
        Friday
        Saturday
        Sunday
        `
        ],
          emailTemplate:[` Welcome to [Company name]
          Dear [Employee’s name],
          We are all really excited to welcome you to our team! As agreed, your start date is [date.] We expect you to be in our offices by [time] and our dress code is [casual/ business casual.]
          [If necessary, remind your employee that they need to bring their ID/ paperwork.]
          At [Company name], we care about giving our employees everything they need to perform their best. As you will soon see, we have prepared your workstation with all necessary equipment. Our team will help you set up your computer, software and online accounts on your first day. [Plus, if applicable, mention any extra things you’ve prepared for your new hire, like a parking spot, a coffee mug with their name or a company t-shirt.]
          We’ve planned your first days to help you settle in properly. You can find more details in the enclosed agenda. As you will see, you’ll have plenty of time to read and complete your employment paperwork (HR will be there to help you during this process!) You will also meet with your hiring manager to discuss your first steps. For your first week, we have also planned a few training sessions to give you a better understanding of our company and operations.
          Our team is excited to meet you and look forward to introducing themselves to you during [planned event/ lunchtime].
          If you have any questions prior to your arrival, please feel free to email or call me and I’ll be more than happy to help you.
          We are looking forward to working with you and seeing you achieve great things!
          Best regards,
          [Your name]
          [Your signature]
          `,
            `Subject: <Candidate Name> employee verification 

            Dear <First Name>,
            
             I am <Your Name> from <Company Name>.
             This is with regard to the referral check of <Name>, who worked with you as .
            
            
            Can you please let me know the following details about them: 
            
            Name: 
            Period of Employment:
            Designation: 
            CTC: 
            Reason for leaving the organization: 
            Exit formalities: Completed / Uncompleted 
            Verified By: 
            
            It would be very kind if you could spare a few minutes and provide your feedback. Your cooperation in this regard will be highly appreciated. , a quick response by return email would be appreciated. 
            
            Thanks 
            <Your Name>
            
            You can also attach scanned documents (relieving ,experience letters,pay slip) provided by candidates. `,`Please welcome [First and last name] who will be the new [job title] !

            We are excited for you to join the team.[First Name] will be responsible for [job duties]. [First name] joins us from previously working at [employment background] and graduated from [academic background] 
           
           We know you’re going to be a valuable asset to our company and can’t wait to see what you accomplish at [company name].
           
           Cheers! 
           [Name]
           `,`I am very pleased to announce that our team is growing. [Start date, e.g. Next week or Next Monday], [Name] will be joining us as our new [job title.] [Add information about what they’ll be doing / what they’ll be responsible]. [He/She] has previously worked at [Add information about employment background] / [He/She] has recently graduated from [Add information about academic background.]. Please join me in welcoming our new team member and make sure to stop by to introduce yourselves!
           In behalf of [company], we would like to welcome [name] as the new [job title]. All of us here are excited to get to know you and work with you on upcoming projects. [Name] joins us from having graduated from [academic background] and working at [employment background]. Welcome [name] to our team.”
           [name] will be joining [company] on [start date] to fill our position in the [division] department. [name]’s experience comes from working at [employment background] and graduated from [academic background]. [insert fun personal fact about new hire]. Thanks for joining me in welcoming [name] to the team.
           `,
                `Hi <First Name>

                Sharing company dress code policy brief at your perusal. Feel free to reach out in case of any query or details. 
                
                Dress code policy
                 
                Policy brief & purpose
                Our dress code company policy outlines how we expect our employees to dress at work. Employees should note that their appearance matters when representing our company in front of clients, visitors or other parties. An employee’s appearance can create a positive or negative impression that reflects on our company and culture.
                Scope
                This policy applies to all our employees.
                Policy elements
                These dress code rules always apply:
                All employees must be clean and well-groomed. Grooming styles dictated by religion and ethnicity aren’t restricted.
                All clothes must be work-appropriate. Clothes that are typical in workouts and outdoor activities aren’t allowed.
                All clothes must project professionalism. Clothes that are too revealing or inappropriate aren’t allowed.
                All clothes must be clean and in good shape. Discernible rips, tears or holes aren’t allowed.
                Employees must avoid clothes with stamps that are offensive or inappropriate.
                What is Business Dress Code?
                Our company’s official dress code is [ Business/ Business Casual/ Smart Casual/ Casual. ]
                We may change our dress code in special cases. For example, we may require employees to wear semi-formal attire for an event. Then, both male and female employees should wear suits, ties, white shirts and appropriate shoes. Our company may also introduce [dress-down Friday] when employees can wear more casual clothing like jeans, simple blouses and boots. This won’t apply if employees are meeting with clients, partners and other external parties.
                An employee’s position may inform their dress code. If employees frequently meet with clients or prospects, they should conform to a business dress code.
                Disciplinary Consequences
                When an employee disregards our dress code, their supervisor should reprimand them. The employee should start respecting our dress code immediately. In some cases, supervisors may ask employees to return home to change.
                Employees may face more severe consequences up to and including termination, if:
                Their appearance causes irreparable damage, like loss of a major client.
                They repeatedly violate our dress code.
                 Thank You 
                <Name>
                `,
                `Appropriate Business Attire
                Business attire is to be worn Monday and through Friday. Appropriate business attire for employee include the following:
                Men:
                               Blazers, suits, or sport coats
                Dress slacks            
                @Ties                
                @Dress shirts with buttons and collars
                @Dress shoes
                Women:
                Dresses
                Skirts or skorts*
                Dress slacks
                Blouses
                Dress shoes
                Sweaters
                Nylons or stocking
                       
                * Skorts are defined as non-tailored split skirts. They do not include walking shorts or Bermuda shorts.
                Appropriate Casual Business Attire
                Casual business attire may be worn on Friday of each week. Appropriate casual business
                attire for employees including the following:
                Men:
                Sport coats or blazers
                Slacks, Chinos or Dockers
                Polo shirts with collars
                Oxford button-down shirts
                Sweaters and cardigans
                Loafers and huaraches
                Sweaters
                Women
                Slacks
                Stirrup pants
                Walking shorts
                Polo shirts
                Culottes, skorts, or splint skirts
                Loafers and huaraches
                Sweaters
                Unacceptable Attire
                Plain or pocket T-shirts
                Cutoffs
                T-shirts with logos          
                Athletic wear
                Thongs of any kind          
                Blue denim jeans
                Spandex or Lycra such as biker shorts    
                Tennis shoes
                Tank tops, tube tops, halter tops with spaghetti straps          
                Deck shoes
                Underwear as outerwear
                Beach wear            
                Midriff length tops
                Provocative attire          
                Off-the-shoulder tops
                Workout clothes or shoes        
                Evening wear
                Enforcement
                Department managers and supervisors are responsible for monitoring and enforcing this policy. The policy will be administered according to the following action steps:
                1.    If questionable attire is worn in the office, the respective department             supervisor/manager will hold a personal, private discussion with the employee to advise and counsel the employee regarding the inappropriateness of the attire.
                2.    If an obvious policy violation occurs, the department supervisor/manager will hold a private discussion with the employee and ask the employee to go home and change his/her attire immediately.
                3.    Repeated policy violations will result in disciplinary action, up to and including termination.
                `,`To All Employees,
                The management of [company or department] would like to invite everyone to come out and enjoy some food and fun. You have all worked so hard this past [length of time], and we would like to show how much we appreciate all you do for the company and the customer.
                The Employee Luncheon will be held at [time] on [date]. The Luncheon will be located [location]. We will serve [including a summary of the menu], and there will be entertainment in the form of [list entertainment].
                Everyone is encouraged to attend and enjoy the food and company.
                Thanks,
                `,`You are invited to lunch with [Manager Name] and a member of the HR team. 
                This is an opportunity to meet some of the team members, as well as share and provide any suggestions about your Pre-bording experience here at [Company name]. 
                
                Date -
                Time -
                Location -
                Contact- 
                
                RSVP no later than - [Date]
                
                [Address]
                
                
                
                See you on the lunch
                
                Cheers!
                First Name
                `,`You are cordially invited to our office dinner party as an expression of our gratitude for being highly dedicated to lead your team this whole year. The dinner will be on Friday, July 29th starting from 6 o'clock in the evening at The Hilton, Cambridge.
                Winnie Schwab.
                `
      ],
        workflowname: '',
        saved: false,
        templatechoice:''
    }
    EmailHandler=()=>{
        this.setState(prevState=>({
        workflowarray:[...prevState.workflowarray,{actionType : 'Email'}] 
    }))}
    SmsHandler=()=>{
        this.setState(prevState=>({        
            workflowarray:[...prevState.workflowarray,{actionType : 'Sms'}] 
    }))}
    WhatsappHandler=()=>{
        this.setState(prevState=>({        
            workflowarray:[...prevState.workflowarray,{actionType : 'Whatsapp'}] 
    }))}
    CallHandler=()=>{
        this.setState(prevState=>({        
            workflowarray:[...prevState.workflowarray,{actionType : 'Call'}] 
    }))}
    VideoHandler=()=>{
        this.setState(prevState=>({        
            workflowarray:[...prevState.workflowarray,{actionType : 'Video'}] 
    }))}
    FormHandler=()=>{
        this.setState(prevState=>({        
            workflowarray:[...prevState.workflowarray,{actionType : 'Form'}] 
    }))}
    MeetHandler=()=>{
        this.setState(prevState=>({        
            workflowarray:[...prevState.workflowarray,{actionType : 'Meet'}] 
    }))}
    SaveHandler=()=>{
        const data={
            workflowItems: this.state.workflowarray,
            workflowName: this.state.workflowname
        }
        console.log("dataiop:", data);
        axios.post("/api/workflow/createWorkflow",data)
            .then(response=>{
                if(response.status===200){
                    alert("Workflow Created");
                }
                console.log("REsp",response)})
            .catch(error=>{
                alert(error);
            });
        // this.props.history.push("/saved");
    }
    CancelHandler=()=>{
        this.setState({show: false});
    }
    changeHandler=(value, label, id)=>{
        const newworkflow= [...this.state.workflowarray];
        newworkflow.map((indivObj, index)=>{
            if(index==id){
                const newindiobj= {...indivObj};
                newindiobj[label]=value;
                newworkflow[index]=newindiobj;
            }
        this.setState({workflowarray:newworkflow});
        })  
    }
    templateHandler=()=>{
        this.setState({show: true});
    }

    templatechoiceHandler=(temp)=>{
        this.setState({templatechoice: temp});
    }
    TemplateChooseHandler=(temp)=>{
        this.templatechoiceHandler(temp);
        console.log(this.state.templatechoice)
        console.log(temp)
        this.CancelHandler();
    }

    handleChange=(selectedOption, index)=>{
        this.changeHandler(selectedOption.label, 'template', index);
    }
    assignChange=(selectedOption, index)=>{
        this.changeHandler(selectedOption.label, 'assignedTo', index);
    }
    assignChange2=(selectedOption, index)=>{
        this.changeHandler(selectedOption.label, 'assignedType', index);
    }
    templateChange=(selectedOption,index)=>{
        this.changeHandler(selectedOption,'template',index)
    }
    workflowNameHandler=(value)=>{
        this.setState({workflowname: value});
    }
    structureHandler=(workflowobject, index)=>{
        if(workflowobject.actionType=='Email')
            return <EmailComp dropdown={this.state.emailTemplate} inputchangeHandler={this.changeHandler} index={index} templateChange={this.templateChange}/>
        else if(workflowobject.actionType=='Sms')
            return <SmsComp dropdown={this.state.messageTemplate} index={index} inputchangeHandler={this.changeHandler} templateChange={this.templateChange}/>    
        else if(workflowobject.actionType=='Call')
            return <CallComp dropdown={this.state.assignedname} index={index} inputchangeHandler={this.changeHandler} handleChange2={this.assignChange2} handleChange={this.assignChange}/>
        else if(workflowobject.actionType=='Whatsapp')
            return <WhatsappComp dropdown={this.state.messageTemplate} index={index} inputchangeHandler={this.changeHandler} templateChange={this.templateChange}/>                    
        else if(workflowobject.actionType=='Video')
            return <VideoComp dropdown={this.state.assignedname} index={index} inputchangeHandler={this.changeHandler} handleChange2={this.assignChange2} handleChange={this.assignChange}/>  
        else if(workflowobject.actionType=='Form')
            return <FormComp dropdown={this.state.formTemplate} index={index} inputchangeHandler={this.changeHandler} templateChange={this.templateChange}/>  
        else if(workflowobject.actionType=='Meet')
            return <MeetComp dropdown={this.state.assignedname} index={index} inputchangeHandler={this.changeHandler} handleChange2={this.assignChange2} handleChange={this.assignChange}/>
        }
        
    render(){
        const actions=(
            <ul className={classes.NavigationItems} >
                <h2 style={{textAlign:'center', paddingTop:'20px' , color:'white'}}>Actions</h2>
                <li className={classes.NavigationItem}>
                    <button onClick={this.EmailHandler}><i className={classes.old} class="far fa-envelope fa-2x"></i><span className={classes.new}>Email</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.SmsHandler}><i className={classes.old} class="far fa-comment-alt fa-2x"></i><span className={classes.new}>SMS</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.WhatsappHandler}><i className={classes.old} class="fab fa-whatsapp fa-2x"></i><span className={classes.new}>Whatsapp</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.CallHandler}><i className={classes.old} class="fas fa-phone-alt fa-2x"></i><span className={classes.new}> Call</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.VideoHandler}><i className={classes.old} class="fas fa-video fa-2x"></i><span className={classes.new}>Video</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.MeetHandler}><i className={classes.old} class="far fa-handshake fa-2x"></i><span className={classes.new}>Meetup</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.FormHandler}><i className={classes.old} class="far fa-file-alt fa-2x"></i><span className={classes.new}>Form</span></button>
                </li>
            </ul>
        );
        const structure=(
            this.state.workflowarray.map((i, index)=>
            (<div style={{display:'block', width:'100%'}}>
                {index!=0 ?
                    (<div style={{textAlign: 'center'}}>
                        <div className={classes.v1}></div> 
                        <p style={{paddingTop:'40px'}}>{i.dayNo-this.state.workflowarray[index-1].dayNo} days later</p>
                        <div  className={classes.v1}></div>
                    </div>): null
                }
                <div className={classes.NavigationItem} >
                    { 
                    this.structureHandler(i, index)
                    }
                </div>
            </div>)
            )
        )
    return (
        <div className={classes.Workflowbod}>     
            <div className={classes.Toolbar}>
                {actions}
            </div>       
            <div className={classes.Content}>
                <div >
                    {this.state.workflowarray.length===0?null:<button class="btn btn-outline-success" style={{float:'right',marginRight:'20px'}} onClick={this.SaveHandler}>Save</button>}
                </div>
                <div className={classes.Header}>
                        <EditableLabel
                            inputClass="form-control"
                            initialValue={'Workflow Name'}
                            save={(value) => {this.workflowNameHandler(value)}}
                        /><i style={{margin:'5px'}}class="far fa-edit"></i>
                </div>
                <div style={{padding:'0 50px'}}>
                    {structure}                    
                </div>    
            </div>
        </div>
    )
    }
}
export default Workflow;