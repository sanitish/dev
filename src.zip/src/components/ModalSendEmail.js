import React,{useState} from 'react';
import { Row, Col, Card, CardBody } from 'reactstrap';
import { Modal, Button } from 'react-bootstrap';
import Axios from 'axios';
import Loader from './Loader';
import setAuthToken from '../utils/setAuthToken';

const ModalSendSms = ({candidate}) =>{
  const [task, setTask] = useState({
    email:candidate.candidateEmail,
    candidate :candidate._id,
    subject:'',
    message:''

    });

const {email,subject,message} = task;

const onChange= e =>{
  setTask({...task, [e.target.name]:e.target.value});
}

    const [show, setShow] = useState(false);
    const [error, setError] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
const onSubmit = (e) =>{
  e.preventDefault();

  setLoading(true)
  setAuthToken()

    Axios.post('/api/sendgrid/sendEmail',task).
    then((res)=>{
      setLoading(false)

        setShow(false);
    }).catch((err)=>{
      setLoading(false)

        setShow(false);

    })
}
  return(  <>
    <button className="btn btn-sm btn-primary" onClick={handleShow}><i className='uil uil-email mr-1'></i>Email</button>

    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
  <Modal.Title>Send Email to {candidate.candidateName}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
      {loading && <Loader/>}

      <Row>
            <Col>
                <Card>
                    <CardBody>
                    <form>
                    <div class="form-group">
              <label>Email</label>
              <textarea type="email" class="form-control" name="email" value={email} disabled/>
            </div>
            <div class="form-group">
              <label>Subject</label>
              <textarea type="text" class="form-control" name="subject" value={subject} onChange={onChange}/>
            </div>
            <div class="form-group">
              <label>Body</label>
              <textarea type="text" row="7" class="form-control" name="message" value={message} onChange={onChange}/>
            </div>
            
          </form>
                    </CardBody>
                </Card>
            </Col>
        </Row>    
      </Modal.Body>


      {/* <Link className="btn text-right" to="/">continue</Link> */}
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
</Button>
        <Button variant="primary" onClick={onSubmit}>
          Send
</Button>
      </Modal.Footer>
    </Modal>
  </>
  )
    
}

export default ModalSendSms;