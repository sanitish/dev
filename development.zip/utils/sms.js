// Download the helper library from https://www.twilio.com/docs/node/install
// Your Account Sid and Auth Token from twilio.com/console
// DANGER! This is insecure. See http://twil.io/secure

const accountSid = 'AC258c6f56533761eab2188e71451a2648';
const authToken = '75ef322ec04f62073069e029f8396aa5';
const client = require('twilio')(accountSid, authToken);
const sendSms =  async(options) =>{
 const result =  await  client.messages
    .create({
       body: 'options.data&&options.data',
       to: '+1 510 890 3395',
       from:'+1 301 603 3053',
      //  to: `+115108903395${options.candidateMobileNumber&&options.candidateMobileNumber}`,
       statusCallback: 'https://app.beamfox.io/api/sendgrid/smsWebhook',

     })
     return result;
};
//sendSms()
module.exports = sendSms;

