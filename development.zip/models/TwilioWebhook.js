const mongoose = require('mongoose');

const TwilioSchema = new mongoose.Schema({
    actionType: {
        type: String,
        required: true
    },
    emailId: {
        type: String,
        required: false
    },
    sid: {
        type: String,
        require: true
    },
    eventId: {
        type: String,
    },

    status: {
        type: String,
        required: false
    },
    time: {
        type: String,
        required: false
    },


    workflow: {
        type: mongoose.Schema.ObjectId,
        ref: 'Workflow',
        //required: true
    },
    candidate: {
        type: mongoose.Schema.ObjectId,
        ref: 'Candidate',
        //required: true
    },
    duration: {
        type: Number,
        required: false
    },

    //   createdBy: {
    //     type: mongoose.Schema.ObjectId,
    //     ref: 'User',
    //    // required: true
    //   },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('TwilioWebhook', TwilioSchema);