const accountSid = 'AC258c6f56533761eab2188e71451a2648';
const authToken = '75ef322ec04f62073069e029f8396aa5';
const client = require('twilio')(accountSid, authToken);


const buyNumber=async(options)=>{
    console.log(options,'opt');
    //====remove console when corrected in .catch error=======

   const result= await client.incomingPhoneNumbers
      .create({phoneNumber: options})
      .then(incoming_phone_number => console.log(incoming_phone_number.sid))
      .catch(error=>console.log('no longer available,try again')
      );


}

    module.exports=buyNumber;