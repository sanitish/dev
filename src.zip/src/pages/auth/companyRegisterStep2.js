import React, { useState, useContext, useEffect } from 'react';
import { connect } from 'react-redux';
import { Redirect, Link } from 'react-router-dom'
import {

    Input,
    FormText

} from 'reactstrap';
import { Container, Row, Col, Card, CardBody, Label, FormGroup, Button, Alert, InputGroup, InputGroupAddon, CustomInput } from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { Mail, Lock, User } from 'react-feather';

import { isUserAuthenticated } from '../../helpers/authUtils';
import Loader from '../../components/Loader';
import logo from '../../assets/images/logo.png';



import AuthContext from '../../context/auth/authContext';
import CompanyContext from '../../context/company/companyContext';

const CompanyRegister2 = props => {
    const authContext = useContext(AuthContext);
    const { companyRegister, loading, error, clearErrors, isAuthenticated } = authContext;

    const companyContext = useContext(CompanyContext);
const {registerDetail,formInput,clearForm} = companyContext;
console.log(registerDetail);
    const [user, setUser] = useState({
        role:'',
        orgnisationName: '',
        orgnisationSize: ''
    });

    const { orgnisationName, orgnisationSize,role } = user;

    /**
    * Handles the submit
    */

    const onChange = e => setUser({ ...user, [e.target.name]: e.target.value });

    const handleValidSubmit = (event) => {
        //  console.log(email,password)
      formInput({ orgnisationName, orgnisationSize,role });
      props.history.push('/account/companyRegister3');

    }

    /**
    * Redirect to root
    */
   const renderRedirectToRoot = () => {
    const isAuthTokenValid = isUserAuthenticated();
    console.log(registerDetail.length)
    if (registerDetail.length<1) {
        return <Redirect to='/account/companyRegister1' />
    }
}


    const isAuthTokenValid = isUserAuthenticated();
    return (
        <React.Fragment>

            {renderRedirectToRoot()}

            {<div className="account-pages mt-5 mb-5">
                <Container>
                    <Row className="justify-content-center">
                        <Col xl={10}>
                            <Card className="">
                                <CardBody className="p-0">
                                    <Row>
                                        <Col md={6} className="p-5 position-relative">
                                            { /* preloader */}
                                            {loading && <Loader />}

                                            <div className="mx-auto mb-5">
                                                <a href="/">
                                                    <img className="logo" src={logo} alt="" height="24" />
                                                    <h3 className="d-inline align-middle ml-1 text-logo text-primary">Beamfox</h3>
                                                </a>
                                            </div>

                                            <h6 className="h5 mb-0 mt-4">Tailor-maid just for you.</h6>

                                            {error && <Alert color="danger" isOpen={error ? true : false}>
                                                <div>{error}</div>
                                            </Alert>}

                                            <AvForm onValidSubmit={handleValidSubmit} className="authentication-form mt-5">
           
                                                <FormGroup>
                                                    <Label for="exampleEmail2">Role</Label>
                                                    <Input type="text" name="role" id="exampleEmail2" placeholder="Your role" value={role} onChange={onChange} />
                                                </FormGroup>

                                                <AvGroup className="">
                                                <Label for="exampleEmail2">Orgnisation Name</Label>
                                                        <InputGroup>
                                                        
                                                            <AvInput type="text" name="orgnisationName" id="exampleEmail2" placeholder="Beamfox" value={orgnisationName} onChange={onChange} required />

                                                        </InputGroup>
                                                        
                                                        <AvFeedback>This field is invalid</AvFeedback>
                                                    </AvGroup>
                                  

                                                <FormGroup>
                                                    <Label for="exampleEmail2">Orgnisation Size</Label>
                                                    <Input type="text" name="orgnisationSize" id="exampleEmail2" placeholder="500" value={orgnisationSize} onChange={onChange} />
                                                </FormGroup>

                                                <FormGroup className="form-group mb-0 mt-5 text-center">

                          
                                                <Button color="danger" className="btn align-items-center btn-lg" style={{paddingLeft:"15%",paddingRight:"15%"}}>

Next<i className="uil uil-arrow-right mr-1 ml-2"></i>


</Button>
                                                </FormGroup>
                                            </AvForm>
                                        </Col>

                                        <Col md={6} className="d-none d-md-inline-block">
                                            <div className="auth-page-sidebar1">
                                                <div className="overlay"></div>
                                         
                                            </div>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>

                    <Row className="mt-1">
                        <Col className="col-12 text-center">
                            <p className="text-muted">Already have an account? <Link to="/account/login" className="text-primary font-weight-bold ml-1">Sign In</Link></p>
                        </Col>
                    </Row>
                </Container>
            </div>}
        </React.Fragment>
    )
};




export default CompanyRegister2;