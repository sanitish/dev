import React from 'react';
import EditableLabel from 'react-editable-label'; 
import { Card, CardGroup} from 'react-bootstrap';
import Select from 'react-select';
import './template.css';

const MeetComp=(props)=>{
    const customStyles = {
        menu: (provided, state) => ({
          ...provided,
          color: state.selectProps.color})}
    const index=props.index;
    return(
<div style={{width: '100%', margin: '30px 10px 0px 10px'}}>
        <CardGroup>
            <Card>
                <Card.Header style={{cursor:'pointer',display:'flex', backgroundColor:'darkcyan', color:'white', borderLeft:'2px solid darkcyan',borderRadius:'15px 0 0 0', fontSize:'15px'}}>
                        <EditableLabel
                            inputClass="form-control col-md-11"
                            initialValue={'Freshers'}
                            save={(value) => {props.inputchangeHandler(value, 'label',index)}}
                        /><i style={{margin:'5px'}} class="far fa-edit col-md-1"></i>
                    </Card.Header>
                <Card.Body style={{backgroundColor:'lightseagreen', color:'white', borderLeft:'2px solid lightseagreen',borderRadius:'0 0 0 15px'}}>
                    <Card.Text>
                        Meet up
                    </Card.Text>
                </Card.Body>
            </Card>
            <Card>
            <Card.Header style={{backgroundColor:'darkcyan', color:'white', fontSize:'15px'}}>Assign</Card.Header>
                <Card.Body style={{backgroundColor:'lightseagreen', color:'white'}}>
                    <Card.Text>Assigned To: 
                        <Select styles={customStyles} color='black' options={ props.dropdown } onChange={(selectedOption)=>props.handleChange(selectedOption, index)} /> 
                    </Card.Text>
                    <Card.Text>Meet Type:
                        <Select  styles={customStyles} color='black' options={[{value:1,label:'Beamfox Meet'}]} onChange={(selectedOption)=>props.handleChange2(selectedOption, index)} /> 
                    </Card.Text>
                </Card.Body>
            </Card>
            <Card>
            <Card.Header style={{fontSize:'15px', backgroundColor:'darkcyan', color:'white', borderRight:'2px solid darkcyan',borderRadius:'0 15px 0 0'}}>Scheduled on</Card.Header>
                <Card.Body style={{backgroundColor:'lightseagreen', color:'white', borderRight:'2px solid lightseagreen',borderRadius:'0 0 15px 0'}}>
                    <Card.Text>
                    <input type="number" class="form-control" placeholder="Day 0" onChange={(event)=>{props.inputchangeHandler(event.target.value, 'dayNo', index)}}/>
                    </Card.Text>
                    <Card.Text>
                    <input type="time" class="form-control" onChange={(event)=>{props.inputchangeHandler(event.target.value, 'time', index)}}/>
                    </Card.Text>
                </Card.Body>
            </Card>
        </CardGroup>
    </div>
)
                        }
export default MeetComp;