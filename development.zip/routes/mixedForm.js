const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');

const {createMixedForm,getMixedForm,deleteMixedForm} = require('../controllers/mixedForm');


router.post('/createMixedForm',createMixedForm);


router.get('/getMixedForm',getMixedForm);

router.delete('/deleteMixedForm',deleteMixedForm);

module.exports = router;