const jwt = require('jsonwebtoken');
const Workflow = require('../models/Workflow');
const WorkflowProcessAction = require('../models/WorkflowProcessAction');

const User = require('../models/User');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const sendEmail = require('../utils/sendEmail');

const moment = require('moment');



  exports.assignWorkflow = asyncHandler(async (req, res, next) => {
    const {startDate, workflowId, candidate,  } = req.body;

    const workflow = await Workflow.findById(workflowId);
   // console.log('nitish',workflow);
    
    if(!workflow){
        return next(new ErrorResponse('Please not found', 400));
    }


    let nitish = await workflow.workflowItems.map(item=>({...item._doc, doe:moment(startDate).add(item.dayNo,'days')}));
    const assignWorkflow = new WorkflowProcess({
      workflowName:workflow.workflowName,
      startDate:moment(startDate).add(1, 'seconds'),
      workflowProcessItems:nitish,
      workflow:workflowId,
      candidate:'5e9302b96dd2174bfce303fb'
    });
 await assignWorkflow.save();
    res.status(200).json({
      success: true,
      data: assignWorkflow
    });
  });



  
  exports.processWorkflowAction = asyncHandler(async (req, res, next) => {
console.log(req.body)
  const {startDate, workflowId, candidate  } = req.body;
  const workflow = await Workflow.findById(workflowId);
  
  if(!workflow){
      return next(new ErrorResponse('Please not found', 400));
  }
if(!candidate){
  return next(new ErrorResponse('candioate not found', 400));
}
  await WorkflowProcessAction.remove({candidate:candidate});


  const a = workflow.workflowItems.map((item)=>{
    console.log(item)
    return({
      ...item._doc,workflow:workflowId,candidate:candidate, doe:moment(startDate).add(item.dayNo,'days' ),addedBy:req.user._id
    })
  })
 console.log('nitishjhgjh',a);
   const w = await WorkflowProcessAction.insertMany(a);
   
   console.log(w);

   res.status(200).json({
    success: true,
    data: w
  });
  });

  exports.getWorkflowProcessAction = asyncHandler(async (req, res, next) => {
    const workFlow = await WorkflowProcessAction.find({addedBy:req.user._id}).select('actionType doe candidate').populate('candidate', 'candidateName');
    res.status(200).json({
      success: true,
      count:workFlow.length,
      data: workFlow
    });
  });

  exports.getWorkflowProcessActionCandidate = asyncHandler(async (req, res, next) => {
    console.log(req.query)
    const workFlow = await WorkflowProcessAction.find(req.query).populate('workflow','workflowName');
    
    console.log(workFlow)
    res.status(200).json({
      success: true,
      // count:workFlow.length,
      data: workFlow
    });
  });


  exports.editWorkflowProcessAction=asyncHandler(async(req,res,next)=>{
    //params ya body decide kr lena
    const workflowProcessAction = await WorkflowProcessAction.findByIdAndUpdate(req.query.id, req.body, {
      new: true,
      runValidators: true
    });
  
    res.status(200).json({
      success: true,
      data: workflowProcessAction
    });

  })

  exports.deleteWorkflowProcessAction=asyncHandler(async(req,res,next)=>{
    //params ya body decide kr lena
    const workflow = await WorkflowProcessAction.findById(req.body.id);

    if (!workflow) {
      return next(
        new ErrorResponse(`No workflow with the id of ${req.body.id}`, 404)
      );
    }
    else{
      await workflow.remove();

      res.status(200).json({
        success: true,
        data: {'delete post':'successfull'}
      });
    }

  })