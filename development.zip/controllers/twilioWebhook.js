const TwilioWebhook = require("../models/TwilioWebhook");
const ErrorResponse = require("../utils/errorResponse");
const asyncHandler = require("../middleware/async");

const sms = require("../utils/sms");
const voiceCall = require("../utils/voiceCall");
const whatsapp = require("../utils/whatsApp");
const sendEmail = require("../utils/sendEmail");

const moment = require("moment");

const showNumber = require("../utils/showNumber");
const buyNumber = require("../utils/buyNumber");

//========================Send Sms===============
exports.sendSms = asyncHandler(async (req, res, next) => {
  try {
    const result = await sms(req.body);
    console.log(result)
    if (result) {
      const webStore = new TwilioWebhook({
        candidate: req.body.candidate,
        actionType: "Sms",
        sid: result.sid,          
        status: result.status,
        time:  Date.now(),
        
      });
        if(req.body.workflow){
          webStore.workflow = req.body.workflow
        }
      await webStore.save();
            res.status(200).json({success: true,data: 'ok'});

      
      
    } else {
       return next(
        new ErrorResponse(`something went wrong`, 400)
      );
    }
  } catch (err) {
    return next(
      new ErrorResponse(`something went wrong`, 400)
    );  }

});

exports.handleSmsWebhook = asyncHandler(async (req, res, next) => {
  const hook = await TwilioWebhook.findOne(
    { sid: req.body.SmsSid },
    async (err, res) => {
      if (res) {
        const candi = res.candidate;
        const newHook = await TwilioWebhook.create({
          candidate: candi,
          workflow:res.workflow,
          actionType: "Sms",
          sid: req.body.SmsSid,

          status: req.body.SmsStatus,
          time: Date.now()
        });
      }
    }
  );
  //  res.status(200).json({
  //    success: true,
  //    data: tasks
  //  });
});

//========================Send Call===============
exports.sendCall = asyncHandler(async (req, res, next) => {
  try {
    const result = await voiceCall(req.body);   
    console.log(result) 
    if (result) {
      const webStore = new TwilioWebhook({
        candidate: req.body.candidate,
        actionType: "Call",
        sid: result.sid,          
        status: result.status,
        time:  Date.now(),
        
      });
        if(req.body.workflow){
          webStore.workflow = req.body.workflow
        }
      await webStore.save();
            res.status(200).json({success: true,data: 'ok'});

      
      
    } else {
       return next(
        new ErrorResponse(`something went wrong`, 400)
      );
    }
  } catch (err) {
    console.log(err);
  }
  //  res.status(200).json({
  //    success: true,
  //    data: tasks
  //  });
});
exports.handleCallWebhook = asyncHandler(async (req, res, next) => {
  const hook = await TwilioWebhook.findOne(
    { sid: req.body.CallSid },
    async (err, res) => {
      if (res) {
        const candi = res.candidate;
        const workflow = req.workflow
        console.log("candi found", candi);
        const newHook = await TwilioWebhook.create({
          candidate: candi,
          workflow:res.workflow,
          actionType: "Call",
          sid: req.body.CallSid,
          status: req.body.CallStatus,
          time: Date.now(),
          duration:req.body.CallDuration
        });
        console.log("newHook", newHook);
      }
    }
  );
  //  res.status(200).json({
  //    success: true,
  //    data: tasks
  //  });
});
//========================whatsapp Completed===============
exports.sendWhatsapp = asyncHandler(async (req, res, next) => {
  try {
    if (result) {
      const webStore = new TwilioWebhook({
        candidate: req.body.candidate,
        actionType: "WhatsApp",
        sid: result.sid,          
        status: result.status,
        time:  Date.now(),
        
      });
        if(req.body.workflow){
          webStore.workflow = req.body.workflow
        }
      await webStore.save();
            res.status(200).json({success: true,data: 'ok'});

      
      
    } else {
       return next(
        new ErrorResponse(`something went wrong`, 400)
      );
    }
  } catch (err) {
    console.log(err);
  }
});
exports.handleWhatsappWebhook = asyncHandler(async (req, res, next) => {
  const hook = await TwilioWebhook.findOne(
    { sid: req.body.SmsSid },
    async (err, res) => {
      if (res) {
        const candi = res.candidate;
        const newHook = await TwilioWebhook.create({
          candidate: candi,
          workflow:res.workflow,
          actionType: "WhatsApp",
          sid: req.body.SmsSid,
          status: req.body.SmsStatus,
          time: Date.now(),
        });
      }
    }
  );
  //  res.status(200).json({
  //    success: true,
  //    data: tasks
  //  });
});
//========================Email=============y===
exports.sendEmail = asyncHandler(async (req, res, next) => {
  try {
    if(req.user.email){
      req.body.replyToEmail = req.user.email;
      req.body.senderName= req.user.name
    }
    const result = await sendEmail(req.body);
    if (result) {
      var y = JSON.stringify(Object.assign({}, result[0]).headers); //y
      var t = y.split(",");
      var sid = t[5].split(":")[1].replace('"', "");
      sid = sid.replace('"', "");
      const webStore = new TwilioWebhook({
        candidate: req.body.candidate,
        actionType: "Email",
        emailId: req.body.email,
        sid: sid,
        status: "created",
        time: Date.now(),
      });

      if(req.body.workflow){
        webStore.workflow = req.body.workflow;
      }

          console.log(webStore,'rishabh hai yaha pe')
      await webStore.save();
            res.status(200).json({success: true,data: 'ok'});

      
      
    } else {
       return next(
        new ErrorResponse(`something went wrong`, 400)
      );
    }
  } catch (err) {
    console.log(err);
  }
  //  res.status(200).json({
  //    success: true,
  //    data: tasks
  //  });
});
exports.handleEmailWebhook = asyncHandler(async (req, res, next) => {
  const result = req.body;
  console.log(req.body);
  var p = 0;
  for (obj in result) {
    const { email, event, sg_message_id, timestamp, sg_event_id } = req.body[p++];
    var x = sg_message_id + "";
    var l = x.indexOf(".filter");
    var sid = x.substring(0, l);
    console.log( email, event, sg_message_id, timestamp, sg_event_id);
    
    TwilioWebhook.findOne({ sid: sid }, async (err, res) => {
      console.log(res)
      if (res) {
        const candi = res.candidate;
        const hook = await TwilioWebhook.create({
          candidate: candi,
          workflow:res.workflow,
          eventId: sg_event_id,
          emailId: email,
          actionType: "Email",
          sid: sid,
          status: event,
          time: timestamp,
        });
        console.log(hook,'from iris')
      } else 
      {
        console.log("bakchodi ho gyi last");
      }
    });
  }
});
//======================showNumber====================
exports.getNumber = asyncHandler(async (req, res, next) => {
  console.log(req.body);
  try {
    const result = await showNumber(req.body);
    if (result) {
      console.log(result, "res");
      //=========buy number=========
      const result2 = await buyNumber(result);
      if (result2) {
        //====remove console when corrected=======
        console.log("successfull, you got new number", result2);
      } else {
        //====remove console when corrected=======
        console.log("no longer available");
      }
    } else {
      //====remove console when corrected=======
       return next(
        new ErrorResponse(`something went wrong`, 400)
      );
    }
  } catch (err) {
    console.log(err);
  }

  //  res.status(200).json({
  //    success: true,
  //    data: tasks
  //  });
});
