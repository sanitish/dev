import React, {Component} from 'react';
import axios from 'axios';

const Activity = (item) => {
    console.log("itemobj",item)
    return <div className="pb-4">
        <div className="media">
            <div className="event-date text-center mr-4">
                <div className="bg-soft-primary p-1 rounded text-primary font-size-14">{item.time}</div>
            </div>
            <div className="media-body">
                <h6 className="font-size-15 mt-0 mb-1">{item.status}</h6>
                {/* <p className="text-muted font-size-14">{item.description}</p> */}
            </div>
        </div>
    </div>
}

class Activities extends Component{

    state={
        activities:[]
    }

    componentWillMount (){
        //  this.setState({isMounted:true})
        axios.get("https://beamfox.xyz/api/candidate/getCandidateActivity")
            .then(response=>{
                console.log("fetcheddata",response.data.data);
                response.data.data.map(inditask=>{
                    let newinditask=inditask;
                this.setState(prevState=>({
                    activities: [...prevState.activities,{...newinditask}]
                }))                    
                })
                })
            }

    render(){
    console.log("activityarray",this.state.activities)
    const activityshow=(
        this.state.activities.map(inditask=>(
            <React.Fragment>
                <h5 className="mt-3">{inditask.actionType}</h5>
                <div className="left-timeline mt-3 mb-3 pl-4">
                    <ul className="list-unstyled events mb-0">
                        {inditask.webhook.map((itemobj, idx) => {
                            return (<li className="event-list" key={idx}>
                                <Activity {...itemobj} />
                            </li>)
                        })}
                    </ul>
                </div>
            </React.Fragment>            
        ))
    )

    return <>{activityshow}</>;
    }
}
export default Activities;
