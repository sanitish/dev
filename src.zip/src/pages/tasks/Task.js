import React from 'react';
import {
    Row, Col, Card, CardBody, 
    CustomInput
} from 'reactstrap';




const Task = (task) => {
    let color='',background='';
                                if(task[0].priority === 'high'){
                                    color='red';background='lightcoral'
                                }
                                else if(task[0].priority === 'medium'){
                                    color='blue';background="lightskyblue"}
                                else if(task[0].priority === 'low'){
                                    color='green';background="palegreen"}
  //  console.log("insidetask",task[0].taskName)
    return <React.Fragment>
        <Card>
            <CardBody>
                <Row className="pb-3 border-bottom">
                    <Col>
                        <CustomInput type="checkbox" id={`task-${task[0]._id}`} label="Mark as completed" defaultChecked={task[0].isCompleted}
                            className="float-left"></CustomInput>
                    </Col>
                </Row>

                <Row>
                    <Col>
                        <h4 className="mt-3">{task[0].taskName}</h4>

                        <Row>
                            <Col>
                                
                                    <p>{task[0].taskDescription}</p>
                                    <p>Candidate:{task[0].candidate}</p>
                                    {/* <p>Task Status:{task[0].isCompleted}</p> */}
                                    <p>Priority:<li className="list-inline-item pr-1">
                                <span style={{color:color, backgroundColor:background}}>{task[0].priority}</span>
                            </li> </p>
                                    <p>Completion Date:{task[0].date}</p>
                                    
                                
                            </Col>
                        </Row>  
                     </Col>
                </Row>
            </CardBody>
        </Card>
    </React.Fragment>
}

export default Task;