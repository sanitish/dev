import React, { Component } from 'react';

/**
 * Renders the Footer
 */
class Footer extends Component {

    render() {
        return (
            <>
   {  false &&       <footer className="footer">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-12">
                            2020 &copy; Beamfox. All Rights Reserved. Crafted with <i className='uil uil-heart text-danger font-size-12'></i> by 
                                <a href="http://beamfox.io" target="_blank"  className="ml-1">beamfox</a>
                        </div>
                    </div>
                </div>
            </footer>}
            </>
        )
    }
}

export default Footer;