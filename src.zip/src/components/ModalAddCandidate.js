import React,{useState} from 'react';
import { Row, Col, Card, CardBody } from 'reactstrap';
import { Modal, Button } from 'react-bootstrap';
import Axios from 'axios';
import Loader from './Loader';
import {
 
  CustomInput,
  Form,
  FormGroup,
  Label,
  Input,
  FormText,
  Alert
  
} from 'reactstrap';
const ModalAddCandidate = ({candidate}) =>{

  const [show, setShow] = useState(false);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);

  const [user, setUser] = useState({
    candidateEmail:candidate.candidateEmail,
    candidateName:candidate.candidateName,
    team:candidate.team,
    manager:candidate.manager,
    sourceOfHire:candidate.sourceOfHire,
    candidateMobileNumber:candidate.candidateMobileNumber,
    candidateDesignation:candidate.candidateDesignation,
    joiningDate:candidate.joiningDate

});

const { candidateEmail, candidateName ,team,manager,sourceOfHire,candidateMobileNumber,candidateDesignation,joiningDate} = user;

  /**
   * Handles the submit
   */
  const onChange = e => setUser({ ...user, [e.target.name]: e.target.value });

  const onSubmit = (e) => {
      e.preventDefault();
      console.log(user)
      Axios.post(`/api/candidate/editCandidate?id=${candidate._id}`,user).
      then((res)=>{
          console.log(res);
          setShow(false);
      }).catch((err)=>{
          console.log(err)
          setShow(false);
  
      })
      
  }


    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);



  return(  <>
    <i className="uil uil-edit ml-5" onClick={handleShow} style={{cursor:"pointer"}}></i>
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
  <Modal.Title>Send Call to {candidate.candidateName}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
      {/* {loading && <Loader/>} */}

      <Card>
            <CardBody>
                <h4 className="header-title mt-0">Add Potential Candidate</h4>
                <p className="text-muted">
                    Enter the name and candidateEmail of Candidate. And send invite{' '}
                </p>
                {error && <Alert color="danger" isOpen={error ? true : false}>
                                                    <div>{error}</div>
                                                </Alert>}
                                                {loading && <Loader />}

                <Row>
                    <Col xl={6}>
                        
                <Form onSubmit={onSubmit}> 
                <FormGroup>
                        <Label for="exampleNam2">Name</Label>
                        <Input type="text" name="candidateName" id="exampleNma2" placeholder="Enter name" value={candidateName} onChange={onChange}/>
                       </FormGroup>

                    <FormGroup>
                        <Label for="exampleEmal2">candidateEmail</Label>
                        <Input type="email" name="candidateEmail" id="exampleEmal2" placeholder="Enter Candidate candidateEmail" value={candidateEmail} onChange={onChange}/>
                        </FormGroup>

                    <FormGroup>
                        <Label for="exampleEmail2">Mobile Number</Label>
                        <Input type="text" name="candidateMobileNumber" id="examplemobileNo2" placeholder="Enter Candidate Mobile Number" value={candidateMobileNumber} onChange={onChange}/>
                           </FormGroup> 
                    
                    <FormGroup>
                        <Label for="exampledesignation2">candidateDesignation</Label>
                        <Input type="text" name="candidateDesignation" id="exampledesignation2" placeholder="Enter candidateDesignation" value={candidateDesignation} onChange={onChange}/>
                              </FormGroup>
                
                    
                </Form>
                </Col>
                <Col xl={6}>
                        <Form>
                            
                    <FormGroup>
                        <Label for="exampleEmail2">Team</Label>
                        <Input type="text" name="team" id="exampleteam2" placeholder="Team Or Function Name" value={team} onChange={onChange}/>
                       </FormGroup> 
                    
                    <FormGroup>
                        <Label for="exampleEmail2">Manager</Label>
                        <Input type="text" name="manager" id="examplemanager2" placeholder="Enter Manager Name" value={manager} onChange={onChange}/>
                          </FormGroup>
                
                    <FormGroup>
                        <Label for="exampleEmail2">Source Of Hire</Label>
                        <Input type="text" name="sourceOfHire" id="examplesourceOfHire2" placeholder="Linkedin..." value={sourceOfHire} onChange={onChange}/>
            
                    </FormGroup> 
                    
                  
                    <FormGroup>
                        <Label for="exampleEmail2">Joining Date</Label>
                        <Input type="date" name="joiningDate" id="examplejoiningDate2" placeholder="Linkedin..." value={joiningDate} onChange={onChange}/>
            
                    </FormGroup> 
                        </Form>
                    </Col>
                </Row>
               
            </CardBody>
        </Card>
     
      </Modal.Body>


      {/* <Link className="btn text-right" to="/">continue</Link> */}
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
</Button>
        <Button variant="primary" onClick={onSubmit}>
          Save
</Button>
      </Modal.Footer>
    </Modal>
  </>
  )
    
}

export default ModalAddCandidate;