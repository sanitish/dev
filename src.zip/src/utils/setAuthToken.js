import axios from 'axios';
import {Cookies} from 'react-cookie';
const setAuthToken = () => {

  const cookies = new Cookies();
let token = cookies.get('token');
  // console.log('latest noitsh', token)
  if (token) {
    // console.log('settoken' , token)
    axios.defaults.headers.common['Authorization'] = "Bearer" + " " +token;
  } else {
    delete axios.defaults.headers.common['Authorization'];
  }
};

export default setAuthToken;
