import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

import PrivateRoute from './routing/PrivateRoute';

import AuthState from './context/auth/AuthState';
import CompanyState from './context/company/CompanyState';

import './App.css'
import './assets/scss/theme.scss';

//layout
import Footer from './layout/footer';
import Sidebar from './layout/sidebar';
import Navbar from './layout/navbar';

//apps routes
import CalendarApp from './pages/Calendar';
import Inbox from './pages/Email/Inbox';
import Error404 from './pages/Error404';

//auth routes
import Login from './pages/auth/Login';
import Logout from './pages/auth/Logout';
import CompanyRegister from './pages/auth/companyRegister';
import CompanyRegister1 from './pages/auth/companyRegisterStep1';
import CompanyRegister2 from './pages/auth/companyRegisterStep2';
import CompanyRegister3 from './pages/auth/companyRegisterStep3';
import Confirm from './pages/auth/Confirm';
import Register from './pages/auth/Register';
import TeamAddForm from './pages/team/TeamAddForm';
import CandidateAddForm from './pages/candidate/CandidateAddForm';
import TeamList from './pages/team/TeamList';
import TaskList from './pages/tasks/List';
import Profile from './pages/candidate/Profile';
import Compose from './pages/Email/Compose';
import Workflow from './pages/workflow/src/workflow';
import Form from './pages/CreateForm/form';
import CandidateState from './context/candidate/CandidateState';
import EmployeeState from './context/employee/EmployeeState';
import CandidateList from './pages/candidate/CandidateList';
import CandidateLifecycle from './pages/candidate/CandidateLifecycle.';
import SavedTemplates from './pages/workflow/src/savedtemplates';
import ShowForm from './pages/CreateForm/displayform';
import ShowSavedWorkflows from './pages/workflow/src/ShowSavedWorkflow';
import ShowSaved from './pages/workflow/src/ShowSaved';
import MessageTemplates from './pages/workflow/src/messagetemplate';
import EmailTemplates from './pages/workflow/src/emailtemplates';
import FormTemplates from './pages/workflow/src/formtemplates';
import Dashboard from './pages/dashboard';
function App() {
  return (
    <div>
      <AuthState>
        <CompanyState>
          <EmployeeState>
            <CandidateState>
          <Router>

            <Navbar/>
            <Sidebar/>
            <Switch>
              <>
                <div className="content">
                  <PrivateRoute exact path='/' component={ShowSavedWorkflows} />
                  <PrivateRoute exact path='/apps/createTemplate' component={Form} />
                  <PrivateRoute exact path='/apps/savedTemplates' component={SavedTemplates} />       
                  <PrivateRoute exact path='/apps/workflowTemplates' component={Workflow} />
                  <PrivateRoute exact path='/apps/dashboard' component={Dashboard} />
                  <PrivateRoute exact path='/apps/calendar' component={CalendarApp} />
                  <PrivateRoute exact path='/apps/inbox' component={Inbox} />
                  <PrivateRoute exact path='/apps/addCandidate' component={CandidateAddForm} />
                  <PrivateRoute exact path='/apps/addTeam' component={TeamAddForm} />
                  <PrivateRoute exact path='/apps/teams' component={TeamList} />
                  <PrivateRoute exact path='/apps/taskList' component={TaskList} />
                  <PrivateRoute exact path='/apps/candidate/:id' component={Profile} />
                  <PrivateRoute exact path='/apps/candidateLifecycle' component={CandidateLifecycle} />
                  <PrivateRoute exact path='/apps/composeEmail' component={Compose} />
                  <PrivateRoute exact path='/apps/candidateList' component={CandidateList} />
                  <PrivateRoute path='/account/logout' component={Logout} />
                  <Route path="/saved/select" render={(props)=><ShowSaved {...props}/>}/>
                  <PrivateRoute exact path="/apps/savedTemplates/message" component={MessageTemplates}/>
                  <PrivateRoute exact path="/apps/savedTemplates/email" component={EmailTemplates}/>
                  <PrivateRoute exact path="/apps/savedTemplates/form" component={FormTemplates}/>


                </div>

                  <Route exact path='/account/login' component={Login} />
            
                  <Route
                    path='/account/companyRegister'
                    name='CompanyRegister'
                    component={CompanyRegister}
                  />
                  <Route
                    path='/account/companyRegister1'
                    name='CompanyRegister'
                    component={CompanyRegister1}

                  />
                  <Route
                    path='/account/companyRegister2'
                    name='CompanyRegister'
                    component={CompanyRegister2}

                  />
                  <Route
                    path='/account/companyRegister3'
                    name='CompanyRegister'
                    component={CompanyRegister3}

                  />

                  <Route
                    path='/account/register/:id'
                    name='Register'
                    component={Register}
                  />
                  <Route
                    path='/account/confirm'
                    name='Confirm'
                    component={Confirm}
                  />
              </>
            </Switch>
            <Footer />
          </Router>
          </CandidateState>
          </EmployeeState>
        </CompanyState>
      </AuthState>
    </div>
  )
}

export default App;
