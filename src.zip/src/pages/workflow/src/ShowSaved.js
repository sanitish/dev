import React,{useState} from 'react';
import SelectCompo from './SelectComp';
import { Modal} from 'react-bootstrap';

const ShowSaved=(props)=>{
    const [editname,setEdit]=useState(false);
    const [deleteworkflow,setDelete]=useState(false);

    const changeworkflowname=()=>{
        setEdit(!editname);
    }
    let saved='';
    let deleted='';
    const deleteworkflowHandler=()=>{
        setDelete(!deleteworkflow);
    }
    if(deleteworkflow){
        deleted=(
        <Modal show={deleteworkflow} onHide={deleteworkflowHandler}>
        <Modal.Header closeButton>
          <Modal.Title>Delete this Workflow?</Modal.Title>
        </Modal.Header>
        <Modal.Body>
                <div className="form-group">
                        <button style={{marginLeft:'15%', paddingLeft:'10', paddingRight:'10'}}className="btn btn-danger .btn-block mt-2" type="submit">
                        Cancel
                        </button>
                        <button style={{marginLeft:'20%'}} className="btn btn-primary .btn-block mt-2" type="submit">
                        Confirm
                        </button>
                </div>
            </Modal.Body>
        </Modal>
    )}
    if(editname){
        saved=(
            <Modal show={editname} onHide={changeworkflowname}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Workflow Name</Modal.Title>
        </Modal.Header>
        <Modal.Body>
                <input type="text" class="form-control" placeholder="Workflow Name" value=""  />
                <div className="form-group">
                        <button style={{marginLeft:'15%', paddingLeft:'10', paddingRight:'10'}}className="btn btn-danger .btn-block mt-2" type="submit">
                        Cancel
                        </button>
                        <button style={{marginLeft:'20%'}} className="btn btn-primary .btn-block mt-2" type="submit">
                        Confirm
                        </button>
                </div>
            </Modal.Body>
        </Modal>
        )
    }
    else{
    let newworkname=props.location.state.newworkname;
    let newworkarray=props.location.state.newworkarray;    
    saved=(<div style={{margin:'100px 20px 0 20px'}}>
    <h3><span style={{paddingLeft:'20px'}}>Workflow: {newworkname}<i class="far fa-edit" onClick={changeworkflowname} 
  style={{ cursor:'pointer', padding:'10px'}}></i></span>
  <span style={{marginLeft:'88%',display:'flex'}}><button className="btn btn-danger .btn-block mt-3" onClick={deleteworkflowHandler}>Delete Workflow</button></span>
  </h3>
   {
       newworkarray.map((indivObj)=>{
           return <SelectCompo label={indivObj.label} time={indivObj.time} dayNo={indivObj.dayNo} template={indivObj.template} actionType={indivObj.actionType} id={indivObj._id}/>
       })
   }</div>    )
    }

    
return <>{saved}{deleted}</>
}

export default ShowSaved