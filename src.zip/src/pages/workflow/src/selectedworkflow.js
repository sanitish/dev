import React, { Component} from 'react';
import { Card, CardGroup} from 'react-bootstrap';
import './savedworkflow.css';
import axios from 'axios';
import { Modal} from 'react-bootstrap';

class SelectComp extends Component{
    state={
        newworkarray:[],
        task:{...this.props.editobj},
        deleteobj:{"id":this.props.id},
        newworkname:'',
        visible: false,
        editshow:false,
        deleteshow:false
    }
;

        toggle=()=>{
            this.setState(prevState=>({
                visible: !prevState.visible
            }))
            // console.log(this.state.visible)
        }

        edittoggle=()=>{
            this.setState(prevState=>({
                editshow: !prevState.editshow
            }))
        }
        deleteHandler=()=>{
            console.log(this.state.deleteobj);
            axios.post("/api/workflowProcess/deleteWorkflowProcessAction",this.state.deleteobj)
            .then(response=>{
                console.log(response);
                this.setState(prevState=>({
                    deleteshow: false
                }))
            })
            .catch(err=>{
                this.setState(prevState=>({
                    deleteshow: false
                }))
                console.log(err)
            })
        }
        removetoggle=()=>{
            this.setState(prevState=>({
                deleteshow:!prevState.deleteshow
            }))
        }
        render(){
const onChange= e =>{
  this.setState({task:{...this.state.task, [e.target.name]:e.target.value}});
}
const handleFormSubmit=(event)=>{
    event.preventDefault();
    console.log(this.state.task,this.props.id);
    axios.post("/api/workflowProcess/editWorkflowProcessAction?id="+this.props.id,this.state.task)
    .then(response=>{
        this.setState(prevState=>({
            editshow: false
        }))
        console.log(response)
    })
    .catch(err=>{
        this.setState(prevState=>({
            editshow: false
        }))
        console.log(err);
    })
}
    let moremenu=null;
    if(!this.state.visible){
        moremenu="more"
    }

    if(this.state.visible){
        moremenu="more show-more-menu"
    }
    let saved=(
        <Modal show={this.state.editshow} onHide={this.edittoggle}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Workflow</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <form >
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Label: </label>
                    <div class="col-sm-9">
                            <input type="text" class="form-control"  placeholder="Enter Name" name="label" value={this.state.task.label} onChange={onChange} required='true'/>
                    </div>
                    <div class="col-sm-1">
                            <i class="far fa-edit fa-1x"></i>                         
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Template: </label>
                    <div class="col-sm-9">
                        <textarea type="text" class="form-control" placeholder="Template" name="template" value={this.state.task.template} onChange={onChange} required/>                        
                    </div>
                    <div class="col-sm-1">
                            <i class="far fa-edit fa-1x"></i>                         
                    </div>
                </div>
                <div class="form-group row">
                        <label class="col-sm-1 col-form-label">Day: </label>
                        <div class="col-sm-4">
                            <input type="number" class="form-control" placeholder="Day" name="dayNo" value={this.state.task.dayNo} onChange={onChange} required/>                        
                        </div>
                        <div class="col-sm-1">
                            <i class="far fa-edit fa-1x"></i>                         
                        </div>
                        <label class="col-sm-1 col-form-label">Time: </label>
                        <div class="col-sm-4">
                            <input type="time" class="form-control" placeholder="Time" name="time" value={this.state.task.time} onChange={onChange} required/>                        
                        </div>
                        <div class="col-sm-1">
                            <i class="far fa-edit fa-1x"></i>                         
                        </div>
                </div>
                <div className="form-group">
                        <button style={{marginLeft:'15%', paddingLeft:'10', paddingRight:'10'}}  onClick={this.edittoggle} className="btn btn-danger .btn-block mt-2" type="submit">
                        Cancel
                        </button>
                        <button style={{marginLeft:'20%'}} onClick={handleFormSubmit} className="btn btn-primary .btn-block mt-2" type="submit">
                        Save Changes
                        </button>
                </div>
            </form>
            </Modal.Body>
        </Modal>
    )

    if(this.state.deleteshow){
        saved=(
            <Modal show={this.state.deleteshow} onHide={this.removetoggle}>
        <Modal.Header closeButton>
          <Modal.Title>Delete Workflow Action</Modal.Title>
        </Modal.Header>
        <Modal.Body>
                <h5>Are you sure you want to delete this workflow action?</h5>
                <div className="form-group">
                        <button style={{marginLeft:'20%'}} onClick={this.deleteHandler} className="btn btn-primary .btn-block mt-2" type="submit">
                        Confirm
                        </button>
                        <button style={{marginLeft:'15%', paddingLeft:'10', paddingRight:'10'}}  onClick={this.removetoggle} className="btn btn-danger .btn-block mt-2" type="submit">
                        Cancel
                        </button>
                </div>
            </Modal.Body>
        </Modal>
        )
    }

    if(!this.state.editshow&& !this.state.deleteshow){
        saved=(
<div style={{width: '100%', margin: '50px 10px 0px 10px'}}>
        <CardGroup >
            <Card text='white'>
                <Card.Header style={{paddingBottom:'33px', backgroundColor:'dodgerblue', borderLeft:'2px solid dodgerblue',borderRadius:'15px 0 0 0'}}>{this.props.label}</Card.Header>
                <Card.Body style={{backgroundColor:'lightskyblue', borderLeft:'2px solid lightskyblue',borderRadius:'0 0 0 15px'}}>
                    <Card.Text>
                        {this.props.actionType}
                    </Card.Text>
                </Card.Body>
            </Card>
            {this.props.actionType==='Video'||this.props.actionType==='Call'||this.props.actionType==='Meet'?
            (<Card text='white'>
                    <Card.Header style={{paddingBottom:'33px', backgroundColor:'dodgerblue'}}>Assign</Card.Header>
                        <Card.Body style={{backgroundColor:'lightskyblue'}}>
                            <Card.Text>
                                Assigned To:
                                {this.props.assignedTo}
                            </Card.Text>
                            <Card.Text>
                                Call Type:
                                {this.props.assignedTo}
                            </Card.Text>
                        </Card.Body>
                    </Card>)
                :(<Card text='white'>
                    <Card.Header style={{paddingBottom:'33px', backgroundColor:'dodgerblue'}}>Template</Card.Header>
                        <Card.Body style={{backgroundColor:'lightskyblue'}}>
                            <Card.Text>
                                {this.props.template}
                            </Card.Text>
                        </Card.Body>
                    </Card>)}
            <Card text='white'>
                <Card.Header style={{paddingBottom:'18px', backgroundColor:'dodgerblue', borderRight:'2px solid dodgerblue',borderRadius:'0 15px 0 0'}}><span style={{display:'inlineBlock', left:'10'}}>Scheduled on</span>
                <div class="container">
                        <div class={moremenu}>
                            <button id="more-btn" class="more-btn" onClick={this.toggle}>
                                <span class="more-dot"></span>
                                <span class="more-dot"></span>
                                <span class="more-dot"></span>
                            </button>
                            <div class="more-menu" style={{marginLeft:'36%'}}>
                                <div class="more-menu-caret">
                                    <div class="more-menu-caret-outer"></div>
                                    <div class="more-menu-caret-inner"></div>
                                </div>
                                <ul style={{marginRight:'100%'}} class="more-menu-items" tabindex="-1" role="menu" aria-labelledby="more-btn" aria-hidden="true">
                                    <li class="more-menu-item" role="presentation">
                                        <button type="button" class="more-menu-btn" role="menuitem" onClick={this.edittoggle}>Edit</button>
                                    </li>
                                    <li class="more-menu-item" role="presentation">
                                        <button type="button" class="more-menu-btn" role="menuitem" onClick={this.removetoggle}>Remove</button>
                                    </li>
                                    <li class="more-menu-item" role="presentation">
                                        <button type="button" class="more-menu-btn" role="menuitem" style={{cursor:'not-allowed'}} disabled>Insert After</button>
                                    </li>
                                    <li class="more-menu-item" role="presentation">
                                        <button type="button" class="more-menu-btn" role="menuitem" style={{cursor:'not-allowed'}} disabled>Insert Before</button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>                    
                </Card.Header>
                <Card.Body style={{backgroundColor:'lightskyblue', borderRight:'2px solid lightskyblue',borderRadius:'0 0 15px 0'}}>
                    <Card.Text>
                        Day: {this.props.dayNo}
                    </Card.Text>
                    <Card.Text>
                    Time: {this.props.time}
                    </Card.Text>
                </Card.Body>

            </Card>
        </CardGroup>
    </div>
        )
    }


    return (<>{saved}</>
)};
    }
export default SelectComp;