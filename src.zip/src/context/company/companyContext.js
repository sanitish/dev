import { createContext } from 'react';

const companyContext = createContext();

export default companyContext;
