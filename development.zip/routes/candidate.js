const express = require('express');
const router = express.Router();
const { protect, superAdmin } = require('../middleware/auth');

const {addCandidate,getCandidate,sendCandidateInvite,editCandidate,getCandidateInvite,getCandidateActivity,sendCandidateVideoInvite ,getMyCandidates,deleteCandidate} = require('../controllers/candidates');

router.post('/deleteCandidate',deleteCandidate);
router.post('/addCandidate', protect,addCandidate);
router.get('/getCandidate/:candidate', getCandidate);
router.get('/getMyCandidates', protect, getMyCandidates);


router.get('/getCandidateActivity', getCandidateActivity);

router.post('/sendCandidateInvite',protect, superAdmin,sendCandidateInvite);
router.get('/candidateInvite/:userId', getCandidateInvite);

router.post('/sendCandidateVideoInvite',protect,sendCandidateVideoInvite);
router.post('/editCandidate',editCandidate);

module.exports = router;