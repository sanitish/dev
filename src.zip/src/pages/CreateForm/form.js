import React, { Component } from 'react';
import axios from 'axios';
import classes from './workflow.module.css';
import Input from './input';
import EditableLabel from 'react-editable-label'; 
import { Card, CardBody, CardHeader, Row, Col } from 'reactstrap';

import { Modal,Button} from 'react-bootstrap';
class Form extends Component{
    state={
        formElementArray:[],
        workflowarray:[],
        workappend:[],
        workflowname: '',
        saved: false,
        orderForm:{
            Textfield:{
                elementType: 'input',
                elementConfig:{
                    type: 'text',
                    placeholder: 'Text Field'
                },
                value: '',
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'',
                id:'Textfield'
            },
            Number: {
                elementType: 'input',
                elementConfig:{
                    type: 'number',
                    placeholder: 'Number'
                },
                value: '',
                validation:{
                    required: true,
                    minLength: 1,
                    maxLength: 10
                },
                valid: false,
                touched: false,
                label:'',
                id:'Number'
            },
            Date: {
                elementType: 'input',
                elementConfig:{
                    type: 'date',
                    placeholder: 'Date',
                    min:"2020-01-01",
                    max:"2020-12-31"
                },
                value:"2020-05-30",
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'',
                id:'Date'
            },
            Time: {
                elementType: 'input',
                elementConfig:{
                    type: 'time',
                    placeholder: 'Time',
                },
                value:'',
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'',
                id:'Time'
            },
            Radio:{
                elementType: 'input',
                elementConfig:{
                    type: 'radio',
                    placeholder: 'Radio Button'
                },
                value: '',
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'First',
                id:'Radio'
            },
            URL:{
                elementType: 'input',
                elementConfig:{
                    type: 'url',
                    placeholder: 'URL'
                },
                value: '',
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'',
                id:'URL'
            },
            Email:{
                elementType: 'input',
                elementConfig:{
                    type: 'email',
                    placeholder: 'Email'
                },
                value: '',
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'',
                id:'Email'
            },
            File:{
                elementType: 'input',
                elementConfig:{
                    type: 'file',
                    placeholder: 'Upload File'
                },
                value: '',
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'',
                id:'File'
            },
            Checkbox:{
                elementType: 'input',
                elementConfig:{
                    type: 'checkbox',
                    placeholder: 'Checkbox'
                },
                value: 'I agree',
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'',
                id:'Checkbox'
            },
            Dropdown:{
                elementType: 'select',
                elementConfig:{
                    type: 'dropdown',
                    options:[
                        {value:'Yes', displayValue: 'Yes'},
                        {value:'No', displayValue: 'No'},
                    ]
                },
                value: 'Yes',
                valid: true,
                validation: {},
                label:'',
                id:'Dropdown'

            }
        },
        formIsValid: false,
        visible:false
    }
TextHandler=()=>{
        for(let key in this.state.orderForm){
            if(key=='Textfield')
            this.setState(prevState=>({
                formElementArray:[...prevState.formElementArray,{id: key, config: this.state.orderForm[key]}] 
            }))
        }

}
toggle=()=>{
    this.setState(prevState=>({
        visible: !prevState.visible
    }))
}
    NumberHandler=()=>{
        for(let key in this.state.orderForm){
            if(key=='Number')
            this.setState(prevState=>({
                formElementArray:[...prevState.formElementArray,{id: key, config: this.state.orderForm[key]}] 
            }))
        }
}
    DateHandler=()=>{
        for(let key in this.state.orderForm){
            if(key=='Date')
            this.setState(prevState=>({
                formElementArray:[...prevState.formElementArray,{id: key, config: this.state.orderForm[key]}] 
            }))
        }
}
    CheckboxHandler=()=>{
        for(let key in this.state.orderForm){
            if(key=='Checkbox')
            this.setState(prevState=>({
                formElementArray:[...prevState.formElementArray,{id: key, config: this.state.orderForm[key]}] 
            }))
        }
}
    DropdownHandler=()=>{
        for(let key in this.state.orderForm){
            if(key=='Dropdown')
            this.setState(prevState=>({
                formElementArray:[...prevState.formElementArray,{id: key, config: this.state.orderForm[key]}] 
            }))
        }
}
    TimeHandler=()=>{
        for(let key in this.state.orderForm){
            if(key=='Time')
            this.setState(prevState=>({
                formElementArray:[...prevState.formElementArray,{id: key, config: this.state.orderForm[key]}] 
            }))
        }
    }
    RadioHandler=()=>{
        for(let key in this.state.orderForm){
            if(key=='Radio')
            this.setState(prevState=>({
                formElementArray:[...prevState.formElementArray,{id: key, config: this.state.orderForm[key]}] 
            }))
        }
    }
    URLHandler=()=>{
        for(let key in this.state.orderForm){
            if(key=='URL')
            this.setState(prevState=>({
                formElementArray:[...prevState.formElementArray,{id: key, config: this.state.orderForm[key]}] 
            }))
        }
    }
    EmailHandler=()=>{
        for(let key in this.state.orderForm){
            if(key=='Email')
            this.setState(prevState=>({
                formElementArray:[...prevState.formElementArray,{id: key, config: this.state.orderForm[key]}] 
            }))
        }
    }
    FileHandler=()=>{
        for(let key in this.state.orderForm){
            if(key=='File')
            this.setState(prevState=>({
                formElementArray:[...prevState.formElementArray,{id: key, config: this.state.orderForm[key]}] 
            }))
        }
    }
    changeHandler=(value, id)=>{
        const newworkflow= [...this.state.formElementArray];
        newworkflow.map((indivObj, index)=>{
            if(index==id){
                const newindiobj= {...indivObj};
                newindiobj.config.label=value;
                newworkflow[index]=newindiobj;
            }
        this.setState({formElementArray:newworkflow});
        })  
    }

    inputshowhandler=(formElement)=>{
        console.log(formElement)
        return(
        <div style={{display:'block'}}>
            <Input
                key={formElement.id}
                elementType={formElement.config.elementType}
                elementConfig={formElement.config.elementConfig}
                value={formElement.config.value}
                invalid={!formElement.config.valid}
                shouldValidate={formElement.config.validation}
                touched={formElement.config.touched}
                changed={(event)=>this.inputchangeHandler(event,formElement.id)}
            />
            
        </div>)
    }

    orderHandler=(event)=>{
        event.preventDefault();
        const formData={};
        this.state.formElementArray.map((formElement, index)=>{
            formData[index]= {...formElement.config}     
        })
        console.log(formData)
        axios.post("/api/mixedForm/createMixedForm",formData)
        .then(response=>{
            if(response.status===200){
                alert("Form Created");
            }
            console.log("REsp",response)})
        .catch(error=>{
            alert(error);
        });
    }

    checkValidity(value, rules){
        let isValid= true;
        if(!rules){
            return true;
        }
        if(rules.required){
            isValid=value.trim() !== '' && isValid;
        }
        if(rules.minLength){
            isValid=value.length >= rules.minLength && isValid;
        }
        if(rules.maxLength){
            isValid=value.length <= rules.maxLength && isValid;
        }
        return isValid;
    }


    inputchangeHandler=(event, inputIdentifier)=>{
        const updatedOrderForm={
            ...this.state.orderForm
        }
        const updatedFormElement={
            ...updatedOrderForm[inputIdentifier]
        };
        console.log(event.target.value)
        updatedFormElement.value=event.target.value;
        updatedFormElement.valid=this.checkValidity(updatedFormElement.value, updatedFormElement.validation)
        updatedFormElement.touched=true;
        updatedOrderForm[inputIdentifier]=updatedFormElement;

        let formIsValid=true;
        for(let inputIdentifier in updatedOrderForm){
            formIsValid=updatedOrderForm[inputIdentifier].valid && formIsValid;
        }

        this.setState({orderForm: updatedOrderForm, formIsValid: formIsValid});
    }

        
    render(){

        console.log("formarraystate",this.state.formElementArray)
        const actions=(
            <ul className={classes.NavigationItems} >
                <h2 style={{textAlign:'center' , color:'white'}}>Form Builder</h2>
                <li className={classes.NavigationItem}>
                    <button onClick={this.TextHandler}><i style={{fontSize:'30px'}} class="uil uil-text-fields"></i><span className={classes.new}>Text</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.NumberHandler}><i class="fas fa-sort-numeric-down fa-2x"></i><span className={classes.new}>Number</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.DateHandler}><i style={{fontSize:'30px'}} class="uil uil-calendar-alt"></i><span className={classes.new}>Date</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.CheckboxHandler}><i style={{fontSize:'30px'}} class="uil uil-check-square"></i><span className={classes.new}>Checkbox</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.DropdownHandler}><i class="far fa-caret-square-down fa-2x"></i><span className={classes.new}>Dropdown</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.TimeHandler}><i class="far fa-clock fa-2x"></i><span className={classes.new}>Time</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.RadioHandler}><i class="far fa-dot-circle fa-2x"></i><span className={classes.new}>Radio</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.URLHandler}><i style={{display:'block', fontSize:'30px'}}>www</i><span className={classes.new}>URL</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.EmailHandler}><i class="fas fa-at fa-2x"></i><span className={classes.new}>Email</span></button>
                </li>
                <li className={classes.NavigationItem}>
                    <button onClick={this.FileHandler}><i class="fas fa-file-upload fa-2x"></i><span className={classes.new}>Upload</span></button>
                </li>
            </ul>
        );

        // this.state.workflowarray.map((i, index)=>{ 
        //     this.structureHandler(i, index)})

        const form=(
            <form onSubmit={this.orderHandler}>
                {this.state.formElementArray.map((formElement, index)=>
                            (<div>
                                <div style={{float: 'left', marginBottom:'10px', cursor:'pointer'}}>
                                    <EditableLabel
                                        inputClass="form-control"
                                        initialValue={formElement.id}
                                        save={(value) => {this.changeHandler(value,index)}}
                                    />                                    
                                </div>
 
                                <Input
                                    key={formElement.id}
                                    elementType={formElement.config.elementType}
                                    elementConfig={formElement.config.elementConfig}
                                    value={formElement.config.value}
                                    invalid={!formElement.config.valid}
                                    shouldValidate={formElement.config.validation}
                                    touched={formElement.config.touched}
                                    label={formElement.label}
                                    changed={(event)=>this.inputchangeHandler(event,formElement.id)}
                                />
                                <label>{formElement.label}</label>
                            </div>     
                            ))}      
                <button class="btn btn-outline-success" disabled={this.state.formIsValid}>Save</button>                    
            </form>
        )  
         let button='';
        if(this.state.visible)
        {
            button=(
                <div>
                    <div style={{padding:'20px'}}>
                <Col xl={12} lg={6}>
                <Card className="mb-4 mb-xl-0">
                    <CardHeader style={{backgroundColor:'dodgerblue', color:'white',  borderLeft:'2px solid dodgerblue',borderRadius:'15px 15px 0 0'}}>Email Templates</CardHeader>
                    <CardBody  style={{backgroundColor:'lightskyblue', color:'white', borderLeft:'2px solid lightskyblue',borderRadius:'0 0 15px 15px'}}>
                        <p className="card-text">Choose from one of our saved Email template collection which are frequently used.</p>
                        
                    </CardBody>
                </Card>
            </Col>
            </div>
            <div style={{padding:'20px'}}>
            <Col xl={12} lg={6}>
                <Card className="mb-4 mb-xl-0">
                <CardHeader style={{backgroundColor:'dodgerblue', color:'white',  borderLeft:'2px solid dodgerblue',borderRadius:'15px 15px 0 0'}}>SMS and Whatsapp Templates</CardHeader>
                <CardBody  style={{backgroundColor:'lightskyblue', color:'white', borderLeft:'2px solid lightskyblue',borderRadius:'0 0 15px 15px'}}>
                        <p className="card-text">Choose from one of our saved Message template collection which are frequently used.</p>
                       
                    </CardBody>
                </Card>
            </Col></div>
            <div style={{padding:'20px'}}>
            <Col xl={12} lg={6}>
                <Card className="mb-4 mb-xl-0">
                <CardHeader style={{backgroundColor:'dodgerblue', color:'white',  borderLeft:'2px solid dodgerblue',borderRadius:'15px 15px 0 0'}}>Form Templates</CardHeader>
                <CardBody  style={{backgroundColor:'lightskyblue', color:'white', borderLeft:'2px solid lightskyblue',borderRadius:'0 0 15px 15px'}}>
                        <p className="card-text">Choose from one of our saved Form template collection which are frequently used.</p>
                
                    </CardBody>
                </Card>
            </Col></div></div>
            )
        }



        let saved=(<div style={{marginTop:'300px'}}>
            <Modal size='lg' show={this.state.visible} onHide={this.toggle}>
            <Modal.Header closeButton>
              <Modal.Title>Create A Template: </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <form>
                    {button}
                    <div className="form-group">
                            <button style={{marginLeft:'35%'}} onClick={this.handleFormSubmit} className="btn btn-outline-primary .btn-block mt-2" type="submit">
                            Proceed
                            </button>
                            <button style={{marginLeft:'10%', paddingLeft:'10', paddingRight:'10'}}  onClick={this.toggle} className="btn btn-outline-danger .btn-block mt-2" type="submit">
                            Cancel
                            </button>
                    </div>
                </form>
            </Modal.Body>
            </Modal>
            <button className="btn btn-primary .btn-block mt-2" style={{padding:'10px',border:'none', margin:'40%'}} onClick={this.toggle}>Create a Template</button>        
        </div>
            )
    return (
        <div>     
            {/* <div className={classes.Toolbar}>
                {actions}
            </div>       
            <div className={classes.Content}>
                <div className={classes.ContactData}>
                    {form}         
            
                </div>    
            </div> */}
            {saved}
        </div>
    )
    }
}
export default Form;