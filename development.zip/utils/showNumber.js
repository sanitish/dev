const phone = require('phone');
const accountSid = 'AC258c6f56533761eab2188e71451a2648';
const authToken = '75ef322ec04f62073069e029f8396aa5';
const client = require('twilio')(accountSid, authToken);

 const showNumber=async(options)=>{
     var num=0;
    const result= await  client.availablePhoneNumbers('US')
      .local
      .list({areaCode: 510, limit: 1})
      .then(local => local.forEach(l => num= l.friendlyName
      ));
      num=phone(num)
      return num[0];

    }
    
module.exports = showNumber;
