import React,{useState} from 'react';
import { Row, Col, Card, CardBody } from 'reactstrap';
import { Modal, Button } from 'react-bootstrap';
import Axios from 'axios';
import Loader from './Loader';
import setAuthToken from '../utils/setAuthToken';
const ModalSendSms = ({candidate}) =>{
  const [task, setTask] = useState({
    textToSpeech:''
    });

const {textToSpeech} = task;

const onChange= e =>{
  setTask({...task, [e.target.name]:e.target.value});
}

    const [show, setShow] = useState(false);
    const [error, setError] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
const onSubmit = (e) =>{
  e.preventDefault();
     let data  = {candidate:candidate._id, 
      candidateMobileNumber :candidate.candidateMobileNumber,
      candidateName:candidate.candidateName,
      textToSpeech
    }
setLoading(true)
setAuthToken()
    Axios.post('/api/sendgrid/sendCall',data).
    then((res)=>{
      setLoading(false)

      setShow(false);
  }).catch((err)=>{
    setLoading(false)

      setShow(false);

  })
}
  return(  <>
    <button className="btn btn-sm btn-primary" onClick={handleShow}><i className='uil uil-call mr-1'></i>Call</button>

    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
  <Modal.Title>Send Call to {candidate.candidateName}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
      {loading && <Loader/>}

      <Row>
            <Col>
                <Card>
                    <CardBody>
                    <form>
            <div class="form-group">
              <label>Mobile Number : {candidate.candidateMobileNumber}</label>
            </div>
            <div class="form-group">
              <label>Text to Speech</label>
              <textarea type="text" class="form-control" name="textToSpeech" value={textToSpeech}  onChange={onChange}/>
            </div>
          </form>
                    </CardBody>
                </Card>
            </Col>
        </Row>    
      </Modal.Body>


      {/* <Link className="btn text-right" to="/">continue</Link> */}
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
</Button>
        <Button variant="primary" onClick={onSubmit}>
          Send
</Button>
      </Modal.Footer>
    </Modal>
  </>
  )
    
}

export default ModalSendSms;