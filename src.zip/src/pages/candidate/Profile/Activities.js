import React, {Component} from 'react';
import axios from 'axios';
import {Alert} from 'reactstrap'
import Loader from '../../../components/Loader';
const Activity = (item) => {
    // console.log("itemobj",item)
    return <div className="pb-4">
        <div className="media">
            <div className="event-date text-center mr-4">
                <div className="bg-soft-primary p-1 rounded text-primary font-size-14">{item.time}</div>
            </div>
            <div className="media-body">
                <h6 className="font-size-15 mt-0 mb-1">{item.status}</h6>
                {/* <p className="text-muted font-size-14">{item.description}</p> */}
            </div>
        </div>
    </div>
}

class Activities extends Component{

    state={
        activities:[],
        loading:false ,
        error:null
    }

    componentWillMount (){
        //  this.setState({isMounted:true})
        this.setState({loading:true})

        axios.get(`/api/candidate/getCandidateActivity?candidate=${this.props.props.match.params.id}`)
            .then(response=>{
                this.setState({loading:false})

                // console.log("fetcheddata89898",response.data.data);
                response.data.data.map(inditask=>{
                    let newinditask=inditask;
                this.setState(prevState=>({
                    activities: [...prevState.activities,{...newinditask}]
                }))              
      
                })
                }).catch((err)=>{
                    this.setState({loading:false})
                    this.setState({error:'something went wrong'})
                })
            }

    render(){
    // console.log("activityarray",this.state.activities)
    const activityshow=(
        this.state.activities.map(inditask=>(
            <div style={{border:'2px solid lightskyblue',borderRadius:'15px',padding:'10px', margin:'30px 10px'}} >
                <h5>Activity:  {inditask.actionType}</h5>
                <div><h6>Workflow Action Name <span style={{float:"right",marginRight:'110px'}}>Date and Time</span></h6>
                        <div style={{margin:'10px'}}>
                        <button class="btn btn-primary" disabled='true'>Status: {inditask.status}</button>  
                        <span style={{float:"right",marginRight:'60px'}}>{inditask.createdAt}</span>    
                        </div>
                </div>
            </div>            
        ))
    )

    return <>{this.state.loading && <Loader/>}
    {this.state.error && <Alert color="danger">  {this.state.error}</Alert >}
    <h5 className="">Activities       
</h5>
    {activityshow}</>;
    }
}
export default Activities;