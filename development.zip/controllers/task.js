const Task = require('../models/Tasks');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');

const sms  = require('../utils/sms');

exports.createTask = asyncHandler(async (req, res, next) => {
    console.log(req.body);
    req.body.createdBy= req.user._id
      const task = await Task.create(req.body);
      res.status(200).json({
        success: true,
        data: task
      });
    });
  

    exports.getMyTasks = asyncHandler(async (req, res, next) => {

       // console.log(req.body);
          const tasks = await Task.find({createdBy:req.user._id,...req.query});
   
          res.status(200).json({
            success: true,
            data: tasks
          });
        });


   
        
    // exports.getCandiadteTasks= asyncHandler(async (req, res, next) => {

    //     // console.log(req.body);
    //        const tasks = await Task.find({
    //          candidate:req.body.candidate
    //        });
    //        res.status(200).json({
    //          success: true,
    //          data: 'ok'
    //        });
    //      });
        

    
  exports.editTask=asyncHandler(async(req,res,next)=>{
    //params ya body decide kr lena
    console.log(req.body,req.query.id);
    
    const task = await Task.findByIdAndUpdate(req.query.id, req.body, {
      new: true,
      runValidators: true
    });

    console.log(task);
    
  
    res.status(200).json({
      success: true,
      data: task
    });

  })