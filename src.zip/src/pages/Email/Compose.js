import React, { useState, useContext, useEffect } from 'react';
import { Row, Col, Card, Button,Alert } from 'reactstrap';
import { AvForm, AvField } from 'availity-reactstrap-validation';

import PageTitle from '../../components/PageTitle';
import RichTextEditor from '../../components/RichTextEditor';

import LeftSide from './LeftSide';
import { emails } from './Data';

import AuthContext from '../../context/auth/authContext';
import Loader from '../../components/Loader';



const Compose = (props) =>  {
    const authContext = useContext(AuthContext);
    const { sendEmail, loading, error,addCandidate  } = authContext;

    const [user, setUser] = useState({
        email: '',
        subject: '',
        message:''
    });



      const { email, subject ,message} = user;

    /**
     * Handles the submit
     */
    const onChange = e => setUser({ ...user, [e.target.name]: e.target.value });
  
    const onSubmit = (e) => {
        e.preventDefault();
        console.log(e)

        sendEmail({email,subject, message},props.history)
        
    }
// Compose
  

        // state = {
        //     totalUnreadEmails: emails.filter(e => e.is_read === false).length,
        //     newReplyContent: null
        // };
      const  onEditorContentChange = 'hi'
   const     handleSave = 'hi'
    

    /**
     * On onEditorContentChange
     */


        return (
            <React.Fragment>
                <Row className="page-title">
                    <Col md={12}>
                        <PageTitle
                            breadCrumbItems={[
                                { label: 'Apps', path: '/apps/email/compose' },
                                { label: 'Email', path: '/apps/email/compose' },
                                { label: 'Compose', path: '/apps/email/compose', active: true },
                            ]}
                            title={'Compose Email'}
                        />
                    </Col>
                </Row>
                {loading && <Loader/>}
            {error && <Alert color="danger">  {error}</Alert >}
                <Row>
                    <Col className="col-12">
                        <div className="email-container">
                            <Card className="inbox-leftbar">
                                <LeftSide totalUnreadEmails={7} />
                            </Card>

                            <div className="inbox-rightbar p-4">
                                <AvForm onValidSubmit={onSubmit}>
                                {/* <AvField type="email" name="to" placeholder="To" label="To" required value={(props.location.aboutProps)?props.location.aboutProps.email.email:{email} }  onChange={onChange} ></AvField> */}

                                    <AvField type="email" name="email" placeholder="To" label="To" required value={(props.location.aboutProps)?props.location.aboutProps.email.email:email }  onChange={onChange} ></AvField>
                                    <AvField type="text" name="subject" label="Subject" placeholder="Subject" value={subject} onChange={onChange} required></AvField>

                                    <Row>
                                        <Col>
                                            {/* <RichTextEditor  /> */}
                                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="8"   name="message" value={message} onChange={onChange}></textarea>

                                            {/* <input className="text"   name="message" value={message} onChange={onChange} /> */}
                                        </Col>
                                    </Row>
                                    <Row className="mt-3 text-right">
                                        <Col>
                                            <Button color="primary">Send<i className='uil uil-message ml-2'></i></Button>
                                        </Col>
                                    </Row>
                                </AvForm>
                            </div>
                        </div>
                    </Col>
                </Row>
            </React.Fragment>
        );
    }

export default Compose;
