const mongoose = require('mongoose');

const TaskSchema = new mongoose.Schema({
taskName:{
    type:String,
    required:true
},
taskDescription:{
    type:String,
    required:false
},
date:{
    type:String,
   // required:true
},
isCompleted:{
type:Boolean,
required:true,
default:false
},
priority:{
    type:String
},
    candidate: {
        type: mongoose.Schema.ObjectId,
        ref: 'Candidate',
        //required: true
      },
      createdBy: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
       // required: true
      },
createdAt:{
    type:Date,
    default: Date.now
}
});

module.exports = mongoose.model('Task', TaskSchema);