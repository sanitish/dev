import React, { useContext, useEffect } from 'react';
import {
    Row, Col, Card, CardBody, Button, DropdownToggle, DropdownMenu, DropdownItem, UncontrolledDropdown
} from 'reactstrap';
import classNames from 'classnames';
import { Briefcase, FolderPlus, HardDrive } from 'react-feather';
import Sortable from 'react-sortablejs';
import moment from 'moment';
import PageTitle from '../../components/PageTitle';

import candidateContext from '../../context/candidate/candidateContext';
import { Link } from 'react-router-dom';
import Axios from 'axios';
import profilePic from '../../assets/images/profilePic.jpg';


const Task = ({task}) => {
    // console.log('please aao na yar q kar raeh oj jaskdjaskldjkl',task);
    // const project = props.project || {};
    let date = task && moment(task.joiningDate?task.joiningDate:'incalud' ).format('DD MMM');

    return <React.Fragment>
        <Card className="border mb-0">
            <CardBody className="p-3">
                <UncontrolledDropdown className="float-right" >
                    <DropdownToggle tag="a" className="dropdown-toggle p-0 arrow-none cursor-pointer">
                        <i className="uil uil-ellipsis-v font-size-14"></i>
                    </DropdownToggle>

                    <DropdownMenu>
                        <DropdownItem><Link to ={`/apps/candidate/${task._id}`}><i className="uil uil-edit-alt mr-2"></i>Assign Workflow</Link></DropdownItem>
                        {/* <DropdownItem><i className="uil uil-user-plus mr-2"></i>Add People</DropdownItem> */}
                        {/* <DropdownItem className="text-warning"><i className="uil uil-exit mr-2"></i>Leave</DropdownItem> */}
                        <DropdownItem divider />
                        <DropdownItem className="text-danger"><i className="uil uil-trash mr-2"></i>Delete</DropdownItem>
                    </DropdownMenu>
                </UncontrolledDropdown>

                <h6 className="mt-0 mb-2 font-size-15">
                    <a href="/" className="text-body text-capitalize">{task.candidateName}</a>
                </h6>

                <span className={classNames('badge', { 'badge-soft-danger': task.priority === undefined, 'badge-soft-info': task.priority === 'Medium', 'badge-soft-success': task.priority === 'Low' })}>{task.candidateDesignation}</span>

                <p className="mb-0 mt-4">
                    <img src={profilePic} alt="user-img"
                        className="avatar-xs rounded-circle mr-2" />

                    <span className="text-nowrap align-middle font-size-13 mr-2">
                        <i className="uil uil-calender text-muted mr-1"></i>{date}</span>

                    {/* <span className="text-nowrap align-middle font-size-13">
                        <i className="uil uil-calender mr-1 text-muted"></i></span>
                    <small className="float-right text-muted">{date}</small> */}
                </p>
            </CardBody>
        </Card>
    </React.Fragment>
}

const TaskContainer = ({ tasks }) => {

 //   tasks = tasks.map((task, idx) => (<Task key={idx}  {...task}></Task>));
//    console.log('CandidateLifecycle',tasks);

    return (
        <div
            options={{
                group: 'shared',
                animation: 150
            }}
            tag="div"
        >
            {/* {tasks} */}
            {tasks.map((task, idx) => {
                // console.log(task)
                    return (
                        <Task key={idx}  task={task}/>
                    );
                })}
        </div>
    );
};


const CandidateLifecycle = () => {
    // constructor(props) {
    //     super(props);
    //   const  state = {
    //         unassignedCandidates: [...allTasks.filter(x => x.stage === 'Todo')],
    //         assignedCandidates: [...allTasks.filter(x => x.stage === 'In-progress')],
    //         reviewTasks: [...allTasks.filter(x => x.stage === 'Review')],
    //         completedTasks: [...allTasks.filter(x => x.stage === 'Done')]
    //     };
    // }
    const CandidateContext = useContext(candidateContext);

    const {  loading, error, addCandidate, candidates, getCandidates } = CandidateContext;
    useEffect(() => {
        getCandidates()
        //console.log('candidates')
       // console.log(candidates)

        // Axios.get(`/api/candidate/getCandidateActivity?candidate=${this.props.props.match.params.id}`)
        // .then(response=>{
        //     this.setState({loading:false})

        //     console.log("fetcheddata",response.data.data);
        //     response.data.data.map(inditask=>{
        //         let newinditask=inditask;
        //     this.setState(prevState=>({
        //         activities: [...prevState.activities,{...newinditask}]
        //     }))              
  
        //     })
        //     }).catch((err)=>{
        //         this.setState({loading:false})
        //         this.setState({error:'something went wrong'})
        //     })
    }, []);
 

    //console.log("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",candidates)
    let count=0;let count2=0;
    let unassigned=[...candidates.filter(x => x.workflowActivity.length===0 )];
    let assigned=candidates.filter(x => !unassigned.includes(x));
    let completed=assigned.filter(x=>{count=0;
        x.workflowActivity.map(y=>{
            if(y.processed===true){
            count++;
        }})
        if(count===x.workflowActivity.length){
            return true
        }
    })
    let onlyassigned=assigned.filter(x=>{count2=0;
        x.workflowActivity.map(y=>{
            if(y.processed===false){
            count2++;
        }})
        if(count2===x.workflowActivity.length){
            return true
        }
    })
    let reviewTasks=assigned.filter(x=>!completed.includes(x) && !onlyassigned.includes(x));
    const  state = {
        unassignedCandidates: unassigned,
        assignedCandidates: onlyassigned,
        reviewTasks: reviewTasks,
        completedTasks: completed
    };
   // console.log(state.unassignedCandidates)
        return <React.Fragment>
            <Row className="page-title">
                <Col md={12}>
                    <PageTitle
                        breadCrumbItems={[
                            { label: 'Apps', path: '/apps/tasks/board' },
                            { label: 'Tasks', path: '/apps/tasks/board' },
                            { label: 'Board', path: '/apps/tasks/board', active: true },
                        ]}
                        title={'WorkFlow Board'}
                    />
                </Col>
            </Row>

            {/* <Row>
                <Col>
                    <Card>
                        <CardBody>
                            <Row className="align-items-center">
                                <Col>
                                    <label className="font-weight-bold d-inline mr-2"><Briefcase className="icon-dual icon-xs mr-2" data-feather="hard-drive"></Briefcase>task: </label>
                                    <UncontrolledDropdown className="d-inline">
                                        <DropdownToggle tag="a" className="dropdown-toggle p-0 arrow-none font-weight-bold cursor-pointer">
                                            Shreyu Design
                                            <i className='uil uil-angle-down font-size-16 align-middle ml-1'></i>
                                        </DropdownToggle>
                                        <DropdownMenu>
                                            <DropdownItem>
                                                <HardDrive className="icon-dual icon-xs mr-2"></HardDrive>Shreyu Design
                                            </DropdownItem>
                                            <DropdownItem>
                                                <Briefcase className="icon-dual icon-xs mr-2" data-feather="briefcase"></Briefcase>Development
                                            </DropdownItem>
                                            <DropdownItem divider />
                                            <DropdownItem>
                                                <FolderPlus className="icon-dual icon-xs mr-2" data-feather="briefcase"></FolderPlus>Shreyu Angular
                                            </DropdownItem>
                                            <DropdownItem>
                                                <FolderPlus className="icon-dual icon-xs mr-2" data-feather="briefcase"></FolderPlus>Shreyu React
                                            </DropdownItem>
                                        </DropdownMenu>
                                    </UncontrolledDropdown>
                                </Col>
                                <Col className="col text-right">
                                    <Button color="primary" id="btn-new-event"><i className="uil-plus mr-1"></i>Add New</Button>
                                </Col>
                            </Row>
                        </CardBody>
                    </Card>
                </Col>
            </Row> */}


 <div style={{overflowX:"scroll"}}>
 <div className="row">
                    <div className="tasks border col">
                        <h5 className="mt-0 task-header header-title"><span className="text-danger">Workflow Unassigned</span><span className="font-size-13">({state.unassignedCandidates.length})</span></h5>
                        <TaskContainer id="task-list-one" classNames="task-list-items" tasks={state.unassignedCandidates}></TaskContainer>
                    </div>

                    <div className="tasks border col">
                        <h5 className="mt-0 task-header header-title"><span className="text-info">Workflow Assigned</span> <span className="font-size-13">({state.assignedCandidates.length})</span></h5>
                        <TaskContainer id="task-list-two" classNames="task-list-items" tasks={state.assignedCandidates}></TaskContainer>
                    </div>

                    <div className="tasks border col">
                        <h5 className="mt-0 task-header header-title"><span className="text-primary">Workflow Ongoing </span><span className="font-size-13">({state.reviewTasks.length})</span></h5>
                        <TaskContainer id="task-list-three" classNames="task-list-items" tasks={state.reviewTasks}></TaskContainer>
                    </div>

                    <div className="tasks border col">
                        <h5 className="mt-0 task-header header-title"><span className="text-success">Workflow Completed </span><span className="font-size-13">({state.completedTasks.length})</span></h5>
                        <TaskContainer id="task-list-four" classNames="task-list-items" tasks={state.completedTasks}></TaskContainer>
                    </div>
            </div >
            </div>
        </React.Fragment>
    }

export default CandidateLifecycle;