import React, { useState,useEffect , useContext} from 'react';
import { Modal, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import AuthContext from '../../context/auth/authContext';
import employeeContext from '../../context/employee/employeeContext';
import candidateContext from '../../context/candidate/candidateContext';
import Select from 'react-select';
const TaskForm = (props) => {
console.log('candidate',props)
  const EmployeeContext = useContext(employeeContext);
  const CandidateContext = useContext(candidateContext);

  const { addEmployee, loading, error , addTask ,tasks} = EmployeeContext;
  
  useEffect(() => {
    CandidateContext.getCandidates()
      console.log('candidates')

  }, []);

  const [show, setShow] = useState(false);


  const [task, setTask] = useState({
    taskName:'',
    taskDescription:'',
    date:'',
    priority:'',
    assignedcandidate:null
    });

    // useEffect(()=>{
      
    // },[])
const {taskName,taskDescription,date,priority,assignedcandidate} = task;

const onChange= e =>{
  setTask({...task, [e.target.name]:e.target.value});
}


const onSubmit = e =>{
  e.preventDefault();

      console.log(task);
      if(assignedcandidate){
        task.candidate = assignedcandidate.value
      }
      else if (props.id){
        task.candidate = props.id
      }
      addTask(task);
      props.reloadHandler(task);
      setShow(false);
      ///createTask(task);

}
  const handleClose = () =>{
   setShow(false); 
  } 
  const handleShow = () => setShow(true);

const handleAssign = assignedcandidate =>{
  setTask({...task, assignedcandidate:assignedcandidate});
}

  let options = CandidateContext.candidates.map((candidate) =>{
      return({
        value:candidate._id , label:candidate.candidateName
      })
  }) 
  console.log(assignedcandidate);
  
  return (
    <>

      <Button color="primary" onClick={handleShow}><i className='uil uil-plus mr-1'></i>Add New</Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Create Task</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form>
            <div class="form-group">
              <label>Task Name</label>
              <input type="text" class="form-control" name="taskName" value={taskName} onChange={onChange} />
            </div>
            <div className="row">
              <div className="col">
                <div class="form-group">
                  <label for="exampleFormControlSelect1">Priority</label>
                  <select class="form-control" name ="priority" value={priority}  onChange={onChange}>
                  <option >--select--</option>
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>


                  </select>
                </div>
              </div>

         
              <div className="col">
                <div class="form-group">
                  <label>date</label>
                  <input type="date" class="form-control" name="date" value={date} onChange={onChange}  />
                </div>
              </div>
            </div>

      
                <div class="form-group">
              <label >Candidate (optional)</label>
    {!props.id ?         <Select 
                isSearchable={true}
                isClearable={true}
                options={options}
                onChange={handleAssign}
                value={assignedcandidate}
                />:
                <Select 
                // isSearchable={true}
                // isClearable={true}
                // options={
                //   [{
                //   value:props.id ,
                //   label:props.candidateName
                // }]}
                // onChange={handleAssign}
                isDisabled={true}
                defaultValue ={{value:props.id , label:props.candidateName}}
                />
                }
            </div>
            <div class="form-group">
              <label >Description (optional)</label>
              <textarea class="form-control" rows="3" name="taskDescription" value={taskDescription} onChange={onChange}></textarea>
            </div>
          </form>
        </Modal.Body>


        {/* <Link className="btn text-right" to="/">continue</Link> */}
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
</Button>
          <Button variant="primary" onClick={onSubmit}>
            Save Changes
</Button>
        </Modal.Footer>
      </Modal>
    </>
  )

}

export default TaskForm;