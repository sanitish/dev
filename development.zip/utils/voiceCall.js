const accountSid = 'AC258c6f56533761eab2188e71451a2648';
const authToken = '75ef322ec04f62073069e029f8396aa5';
const client = require('twilio')(accountSid, authToken);
const voiceCall = (options)=>{
    console.log(options)
    return(
        client.calls
        .create({
            method: 'GET',
            statusCallback: 'https://app.beamfox.io/api/sendgrid/callWebhook',
            statusCallbackEvent: ['initiated', 'answered',  'ringing', 'completed'],
            statusCallbackMethod: 'POST',
        //    url: 'http://demo.twilio.com/docs/voice.xml',
        // url: 'http://demo.twilio.com/docs/classic.mp3',
        twiml: (options.textToSpeech)?`<Response><Say>${options.textToSpeech}</Say></Response>`:
        `<Response><Say>hi ${options.candidateName} happy to have you onboard. </Say></Response>`,
        to: `+91${options.candidateMobileNumber&&options.candidateMobileNumber}`,
        from: '+15108903395'

         })
        .then(call => {return call})
        .catch(err=>console.log(err))
    );
}
module.exports = voiceCall;