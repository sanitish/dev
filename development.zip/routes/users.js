const express = require('express');
const router = express.Router();

const upload = require('../utils/fileUpload');

const { protect, superAdmin } = require('../middleware/auth');

const {addUser,getUsers,sendEmployeeInvitaion,getEmployeeInvitaion,uploadFile,getFiles,reSendEmployeeInvitaion} = require('../controllers/users');

router.post('/addUser', addUser);
router.get('/getUsers',protect, getUsers);
router.post('/sendEmployeeInvite',protect, sendEmployeeInvitaion);
router.get('/employeeInvite/:companyId/:role', getEmployeeInvitaion);
router.post('/reSendEmployeeInvitaion', reSendEmployeeInvitaion);

router.post('/uploadFile', upload.uploadFile.single('file'), protect,uploadFile);
router.get('/getFiles/:candidate',getFiles);


module.exports = router;