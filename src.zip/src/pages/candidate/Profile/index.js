import React, { Component } from 'react';
import { Row, Col, Card, CardBody, Nav, NavItem, NavLink, TabContent, TabPane,Alert } from 'reactstrap';
import classNames from 'classnames';
import PageTitle from '../../../components/PageTitle';
import Loader from '../../../components/Loader';
import SavedWorkflows from '../../workflow/src/savedworkflows';
import UserBox from './UserBox';
import Activities from './Activities';
import Messages from './Messages';
import Projects from './Projects';
import Tasks from './Tasks';
import Files from './Files';
import axios from 'axios';
import { DropdownToggle, DropdownMenu, DropdownItem, UncontrolledDropdown
} from 'reactstrap';
import { Briefcase, FolderPlus, HardDrive } from 'react-feather';

class Profile extends Component {
    constructor(props) {
        super(props);
        this.toggleTab = this.toggleTab.bind(this);
        this.state = {
            activeTab: '2'
        };
    }

    
    state={
candidate : null,
loading:false ,
error:null
   }
    
        componentWillMount(){
            //  this.setState({isMounted:true})

          this.data()
                }
  
                async   data () {
            try{
                this.setState({loading:true})

              const res=  await axios.get(`/api/candidate/getCandidate/${this.props.match.params.id}`);
                    // console.log("candiadate info",res.data.data);
                    this.setState({candidate: res.data.data})    
                    this.setState({loading:false})
                    }catch(err){
                        // console.log('isme hai err')
                        // console.log(err.messages);
                        this.setState({loading:false})
                        this.setState({error:'something went wrong'})
                    }
          }      
    /**
     * Toggles tab
     * @param {*} tab 
     */
    toggleTab(tab) {
        if (this.state.activeTab !== tab) {
            this.setState({
                activeTab: tab
            });
        }
    }

    render() {
        return (
            <React.Fragment>
                <Row className="page-title">
                    <Col md={12}>
                        <PageTitle
                            breadCrumbItems={[
                                { label: 'Pages', path: '/pages/profile' },
                                { label: 'Profile', path: '/pages/profile', active: true },
                            ]}
                            title={'Profile'}
                        />
                    </Col>
                </Row>
{this.state.error && <Alert color="danger">  {this.state.error}</Alert >}

                <Row>
                    <Col lg={3}>
                    {this.state.loading && <Loader/>}

                        {/* User information */}
                        <UserBox props={this.props} candidate={this.state.candidate}/>
                    </Col>

                    <Col lg={9}>
                        <Card>
                            <CardBody>
                                <Nav className="nav nav-pills navtab-bg nav-justified">
                                    <NavItem>
                                        <NavLink
                                            href="#"
                                            className={classNames({ active: this.state.activeTab === '1' })}
                                            onClick={() => { this.toggleTab('1'); }}
                                        >Activity</NavLink>
                                    </NavItem>
                                    <NavItem>
                                        <NavLink
                                            href="#"
                                            className={classNames({ active: this.state.activeTab === '2' })}
                                            onClick={() => { this.toggleTab('2'); }}
                                        >Workflow</NavLink>
                                    </NavItem>
                                    <NavItem>
                                        <NavLink
                                            href="#"
                                            className={classNames({ active: this.state.activeTab === '3' })}
                                            onClick={() => { this.toggleTab('3'); }}
                                        >Messages
                                              <UncontrolledDropdown className="d-inline">
                                        <DropdownToggle tag="a" className="dropdown-toggle p-0 arrow-none font-weight-bold cursor-pointer">
                                            
                                            <i className='uil uil-angle-down font-size-16 align-middle ml-1'></i>
                                        </DropdownToggle>
                                        <DropdownMenu>
                                            <DropdownItem>
                                                <HardDrive className="icon-dual icon-xs mr-2"></HardDrive>SMS
                                            </DropdownItem>
                                            <DropdownItem>
                                                <Briefcase className="icon-dual icon-xs mr-2" data-feather="briefcase"></Briefcase>Whatsapp
                                            </DropdownItem>
                                            <DropdownItem>
                                                <FolderPlus className="icon-dual icon-xs mr-2" data-feather="briefcase"></FolderPlus>Email
                                            </DropdownItem>
                                            <DropdownItem>
                                                <FolderPlus className="icon-dual icon-xs mr-2" data-feather="briefcase"></FolderPlus>Call
                                            </DropdownItem>
                                        </DropdownMenu>
                                    </UncontrolledDropdown>
                       </NavLink>
                                    </NavItem>
                                    {/*< NavItem>
                                        <NavLink
                                            href="#"
                                            className={classNames({ active: this.state.activeTab === '4' })}
                                            onClick={() => { this.toggleTab('4'); }}
                                        >Projects</NavLink>
                                    </NavItem> */}
                                    <NavItem>
                                        <NavLink
                                            href="#"
                                            className={classNames({ active: this.state.activeTab === '5' })}
                                            onClick={() => { this.toggleTab('5'); }}
                                        >Tasks</NavLink>
                                    </NavItem>
                                    <NavItem>
                                        <NavLink
                                            href="#"
                                            className={classNames({ active: this.state.activeTab === '6' })}
                                            onClick={() => { this.toggleTab('6'); }}
                                        >Files</NavLink>
                                    </NavItem>
                                </Nav>
                                <TabContent activeTab={this.state.activeTab}>
                                     <TabPane tabId="1">
                                        <Activities  props={this.props}/>
                                    </TabPane>
                                    <TabPane tabId="2">
                                        <SavedWorkflows  props={this.props} />
                                    </TabPane>
                                     <TabPane tabId="3">
                                        <Messages candidate={this.state.candidate}/>
                                    </TabPane>
                                    {/*<TabPane tabId="4">
                                        <Projects />
                                    </TabPane> */}
                                    <TabPane tabId="5">
                                        <Tasks  props={this.props}  candidateName={this.state.candidate && this.state.candidate.candidateName}/>
                                    </TabPane> 
                                    <TabPane tabId="6">
                                        <Files  props={this.props}/>
                                    </TabPane>
                                </TabContent>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </React.Fragment>
        );
    }
}

export default Profile;
