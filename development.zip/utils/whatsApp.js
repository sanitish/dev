const accountSid = 'AC0e65c7830b7cee16f8d349a20f8713ec';
const authToken = 'e866a80f5dc209d85a26febc43e710dd';
const client=require('twilio')(accountSid,authToken);


const whatsapp = async ()=> {
    const result = await
    client.messages.create({
        from:'whatsapp:+14155238886',
        to:'whatsapp:+917550167626',
        body:'hello fsdvfw'
    })
    return result;
}
module.exports = whatsapp; 
