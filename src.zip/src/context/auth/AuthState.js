import React, { useReducer } from 'react';
import axios from 'axios';
import AuthContext from './authContext';
import authReducer from './authReducer';
import setAuthToken from '../../utils/setAuthToken';
import { Cookies } from 'react-cookie';

import {
  REGISTER_SUCCESS,
  REGISTER_FAIL,
  USER_LOADED,
  AUTH_ERROR,
  LOGIN_SUCCESS,
  LOGIN_FAIL,
  LOGOUT,
  CLEAR_ERRORS,
  ADD_CONTACT,
  CONTACT_ERROR,
  GET_CONTACTS,
  ADD_TASK,
  GET_TASK
} from '../types';

const AuthState = props => {
  const initialState = {
    token: localStorage.getItem('token'),
    isAuthenticated: null,
    loading: false,
    user: null,
    error: null
  };

  const [state, dispatch] = useReducer(authReducer, initialState);


    //add candiadte


  const googleCalanderEvents = async () =>{

    const cookies = new Cookies();
    let token = cookies.get('token');
    setAuthToken(token);
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    setLoading()
    try {
      const res = await axios.get('/addGoogelCalanderEvents', config);
      dispatch({
        type: GET_CONTACTS,
        payload: res.data.data
      });
    } catch (error) {
      dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
    }
  }
 //get candidate
 const syncGoogleCalander = async (history) => {
  const cookies = new Cookies();
  let token = cookies.get('token');
  setAuthToken(token);
  const config = {
    headers: {
      'Content-Type': 'application/json'
    }
  };
  setLoading()
  try {
    const res = await axios.get('/syncCalander', config);
    dispatch({
      type: REGISTER_SUCCESS
    
    });
    // console.log('urlllllllllllllllll',res.data.url);
     window.location.assign(res.data.url);

  } catch (error) {
    dispatch({
      type: LOGIN_FAIL,
      payload: error.response.data.error || error.response.data
    });
  }
};



  // Load User
  const loadUser = async () => {
    setLoading()
    const cookies = new Cookies();
    let token = cookies.get('token');
    setAuthToken(token);
    try {
      const res = await axios.get('/api/auth/me');
      cookies.set('user',res.data.data)

      dispatch({
        type: USER_LOADED,
        payload: res.data.data
      });
    } catch (err) {
      dispatch({ type: AUTH_ERROR });
    }
  };


  //Register company
  const companyRegister = async (formData, history) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    setLoading()
    // console.log(formData)
    try {
      const res = await axios.post('/api/company/addCompany', formData, config);

      history.push('/account/confirm');

      dispatch({
        type: REGISTER_SUCCESS,
        payload: res.data
      });


    } catch (error) {
      dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
    }
  };


    //SendInviteTo Employee
    const sendEmail = async (formData, history) => {
     // const cookies = new Cookies();
      //let token = cookies.get('token');
    //  setAuthToken(token);
  
      const config = {
        headers: {
          'Content-Type': 'application/json'
        }
      };
     console.log(config)
      //setLoading();
      // console.log(formData)
      setLoading()
  
      try {
        const response = await axios.post('/api/sendgrid/sendEmail', formData, config);
        // console.log(response)
                dispatch({
          type: LOGIN_SUCCESS
        });
      //  history.push('/apps/settings/list')
        // const a =
        // {
        //   name: formData.name,
        //   email: formData.email,
        //   role: formData.role.value
  
        // }
        // dispatch({
        //   type: ADD_CONTACT,
        //   payload: a
        // });
  
        //  loadUser();
      } catch (error) {
       
  
        console.log(typeof(error))
        dispatch({
          type: LOGIN_FAIL,
          payload: error.response.data.error || error.response.data
        });
      }
    };
  
  

 













  // Register User
  const register = async (formData, history) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    setLoading()
    // console.log(formData);
    try {
      const res = await axios.post('/api/auth/updatedetails', formData, config);
      dispatch({
        type: REGISTER_SUCCESS,
        payload: res.data
      });
      // console.log(res);
      history.push('/account/login');

    } catch (error) {
      dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
    }
  };

  // Login User
  const login = async (formData) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    setLoading();

    try {

      const response = await axios.post('/api/auth/login', formData, config);
      const cookies = new Cookies();
      const problem = cookies.get('token');
      // console.log('froom loginnnnnnnnnnnnnnnn',cookies.getAll());
      if(problem){

        throw Error;
      }
      cookies.set('token', response.data.token);
      cookies.set('user', response.data.data);
  
      const reactToken = cookies.get('token');

      // console.log('reactToken', reactToken)
      dispatch({
        type: LOGIN_SUCCESS,
        payload: response.data
      });
      loadUser();

    } catch (error) {
      // console.log(error.response)
      // console.log(error.message)

      console.log(typeof(error))

      dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
    }
  };

  // Logout
  const logout = (history) => {
    // console.log('calloed logout')
    const cookies = new Cookies();
    cookies.remove('token');
    cookies.remove('user');

    // console.log('from logut',cookies.getAll());

    dispatch({ type: LOGOUT });
    history.push('/account/login');

  }
  const setLoading = () => dispatch({ type: 'SET_LOADING' })

  // Clear Errors
  const clearErrors = () => dispatch({ type: CLEAR_ERRORS });

  return (
    <AuthContext.Provider
      value={{
        token: state.token,
        isAuthenticated: state.isAuthenticated,
        loading: state.loading,
        user: state.user,
        error: state.error,
        register,
        loadUser,
        login,
        logout,
        setLoading,
        companyRegister,
  
        syncGoogleCalander,
        sendEmail,
        setAuthToken,
        googleCalanderEvents,
     
      }}
    >
      {props.children}
    </AuthContext.Provider>
  );
};

export default AuthState;
