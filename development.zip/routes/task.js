const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');

const {createTask,getMyTasks,getCandiadteTasks,editTask} = require('../controllers/task');

router.post('/createTask',protect,createTask);
router.get('/getMyTasks',protect,getMyTasks);
//router.get('/getCandiadteTasks',getCandiadteTasks);
router.post('/editTask',editTask );
module.exports = router;