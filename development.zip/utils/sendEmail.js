const sgMail = require('@sendgrid/mail');


const sendEmail = async options => {
  sgMail.setApiKey("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");
  console.log(options)
const msg = {
  to: options.candidateEmail||options.email,
  from: {email:'no-reply@beamfox.io',
          name:options.senderName?options.senderName:'via beamfox'},
    replyTo:options.replyToEmail&&options.replyToEmail,
    subject: options.subject,
    text: options.message,
//  html: '<strong>and easy to do anywhere, even with Node.js</strong><img src="/sadhiasl">',
};
return result = await sgMail.send(msg);

};
module.exports = sendEmail;
