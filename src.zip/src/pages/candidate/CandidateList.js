// @flow
import React, { useContext, useEffect } from 'react';
import { Row, Col, Card, CardBody, Progress, UncontrolledTooltip, Button ,Alert} from 'reactstrap';
import classNames from 'classnames';
import { Link } from 'react-router-dom';
import avatar1 from '../../assets/images/users/avatar-6.jpg';
import avatar3 from '../../assets/images/users/avatar-8.jpg';
import Avatar from 'react-avatar';
import profilePic from '../../assets/images/profilePic.jpg';
import Loader from '../../components/Loader';
import candidateContext from '../../context/candidate/candidateContext';
import moment from 'moment';
// single project
const Project = props => {

    const project = props.project || {};
    let date = moment(project.joiningDate?project.joiningDate:'incalud' ).format('DD MMM');

    return (
        <Card>
            <CardBody>
                <Link to= {`/apps/candidate/${project._id}`}>
                <div className={classNames(
                    'badge', 'float-right',
                    {
                        'badge-info': project.state === undefined,
                        'badge-primary': project.state === 'Ongoing',
                        'badge-war': project.state === 'Planned',
                    }
                )}> 
                    {project.candidateDesignation}
                </div>
                <p className={classNames("text-uppercase", "font-size-12", "mb-2",
                    {
                        'text-success': project.state === undefined,
                        'text-warning': project.state === 'Ongoing',
                        'text-info': project.state === 'Planned',
                    })}>{project.team}</p>

                <h5>
                    <a href="/" className="text-dark">
                        {project.candidateName}
                    </a>
                </h5>

{/* 
                <p className="text-muted mb-4">
                    <a href="/" className="font-weight-bold text-muted ml-2">
                    {project.candidateEmail}, {project.candidateMobileNumber}
                    </a>
                </p> */}

                <div>
                    <a href="/" className="d-inline-block mr-1">
                        <img src={profilePic} className="avatar-sm m-1 rounded-circle" alt="friend" />
                    </a> 

                     {/* <a href="/" className="d-inline-block mr-1">
                        <img src={project.profileic} className="avatar-sm m-1 rounded-circle" alt="Manager pic" />
                    </a> */}
                </div>
                </Link>
            </CardBody>

            <CardBody className="border-top">
                <Row className="align-items-center">
                    <Col className="col-sm-auto">
                        <ul className="list-inline mb-0">
                            <li className="list-inline-item pr-2">
                                <a href="/" className="text-muted d-inline-block" id={`dueDate-${project.id}`}>
                                    <i className="uil uil-calender mr-1"></i> {date!='Invalid date'?date:'-'}
                                </a>
                                <UncontrolledTooltip placement="top" target={`dueDate-${project.id}`}>Joining date</UncontrolledTooltip>
                            </li>
                            <li className="list-inline-item pr-2">
                                <a href="/" className="text-muted d-inline-block" id={`noTasks-${project.id}`}>
                                    <i className="uil uil-bars mr-1"></i> {project.totalTasks|| 20}</a>
                                <UncontrolledTooltip placement="top" target={`noTasks-${project.id}`}>Tasks</UncontrolledTooltip>
                            </li>
                            <li className="list-inline-item">
                                <a href="/" className="text-muted d-inline-block" id={`noComments-${project.id}`}>
                                    <i className="uil uil-comments-alt mr-1"></i> {project.totalComments||100}
                                </a>
                                <UncontrolledTooltip placement="top" target={`noComments-${project.id}`}>Comments</UncontrolledTooltip>
                            </li>
                        </ul>
                    </Col>
                    <Col className="offset-sm-1">
                    <Progress value={100} color="success" className="progress-sm" />

                        {project.progress < 30 && (
                            <Progress value={project.progress} color="warning" className="progress-sm" />
                        )}
                        {project.progress > 30 && project.progress < 100 && (
                            <Progress value={project.progress} color="info" className="progress-sm" />
                        )}
                        {project.progress === 100 && (
                            <Progress value={project.progress} color="success" className="progress-sm" />
                        )}
                    </Col>
                </Row>
            </CardBody>
        </Card>
    );
};

const CandidateList = () => {
        // const project = props.project || {};
        const CandidateContext = useContext(candidateContext);

        const {  loading, error, addCandidate, candidates, getCandidates } = CandidateContext;
    useEffect(() => {
        getCandidates()
        // console.log('candidates')

    },[]);

    // console.log('nitish lkaiofduasd',candidates)

    return (

        <React.Fragment>
         
                 <Row className="page-title">
                <Col md={3} xl={6}>
                    <h4 className="mb-1 mt-0">Candidates</h4>
                </Col>
                <Col md={9} xl={6} className="text-md-right">
                    <div className="mt-4 mt-md-0">
                        <Link to="/apps/addCandidate" type="button" className="btn btn-danger mr-4 mb-3  mb-sm-0"><i className="uil-plus mr-1"></i> Add Candidates</Link>
                    </div>
                </Col>
            </Row>
            {loading && <Loader/>}
            {error && <Alert color="danger">  {error}</Alert >}
            <Row>

                {candidates && candidates.map((project, i) => {
                    return (
                        <Col lg={6} xl={4} key={'proj-' + project._id}>
                            <Project project={project} />
                        </Col>
                    );
                })}
            </Row>

            <Row className="mb-3 mt-2">
                <Col>
                    <div className="text-center">
                        {/* <Button color="white">
                            <Loader className="icon-dual icon-xs mr-2"></Loader>Load more 
                        </Button> 
                        */}
                    </div>
                </Col>
            </Row>
        </React.Fragment>
    );
};

export default CandidateList;