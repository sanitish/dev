
const mongoose=require('mongoose');

const MixedSchema=new mongoose.Schema({
    formElements:{
        type:mongoose.Schema.Types.Mixed,
    }
});


module.exports = mongoose.model('Mixes', MixedSchema)