import React from 'react';
import { Card, CardBody, Table, Button } from 'reactstrap';

const Orders = () => {
    return (
        <Card>
            <CardBody className="pb-0">

                <h5 className="card-title mt-0 mb-0 header-title">Recent Candidate Activity</h5>

                <Table hover responsive className="mt-4">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Candidate Name</th>
                            <th scope="col">Team</th>
                            <th scope="col">Communication</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>#12</td>
                            <td>Avinash Kumar</td>
                            <td>Product</td>
                            <td>SMS</td>
                            <td><span className="badge badge-soft-warning py-1">Read</span></td>
                        </tr>
                        <tr>
                            <td>#3</td>
                            <td>Balakishore B</td>
                            <td>QA</td>
                            <td>Email</td>
                            <td><span className="badge badge-soft-success py-1">Delivered</span>
                            </td>
                        </tr>
                        <tr>
                            <td>#22</td>
                            <td>Venkat Reddy</td>
                            <td>Marketing</td>
                            <td>Call</td>
                            <td><span className="badge badge-soft-danger py-1">Declined</span>
                            </td>
                        </tr>
                        <tr>
                            <td>#39</td>
                            <td>Martin Browne</td>
                            <td>Finance</td>
                            <td>VideoCall</td>
                            <td><span className="badge badge-soft-success py-1">Answered</span>
                            </td>
                        </tr>
                        <tr>
                            <td>#18</td>
                            <td>Joice Josh</td>
                            <td>Legal</td>
                            <td>Whatsapp</td>
                            <td><span className="badge badge-soft-warning py-1">Read</span>
                            </td>
                        </tr>
                    </tbody>
                </Table>
            </CardBody>
        </Card>
    );
};

export default Orders;
