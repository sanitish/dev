const mongoose = require('mongoose');

const WorkflowSchema = new mongoose.Schema({
workflowName:{
    type:String,
    required:true
},
workflowItems:[

    {
        _id:false,
        actionType:{
            type:String,
            required:false
        },
        dayNo:{
            type:Number,
            require:false
        },
        label:{
            type:String
        },
        template:{
            type:String
        },
        time:{
            type:String
        }
    }],

    company: {
        type: mongoose.Schema.ObjectId,
        ref: 'Company',
        //required: true
      },
      createdBy: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
       // required: true
      },
createdAt:{
    type:Date,
    default: Date.now
}
});

module.exports = mongoose.model('Workflow', WorkflowSchema);