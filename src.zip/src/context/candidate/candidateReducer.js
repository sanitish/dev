import {

  ADD_TASK,
  GET_TASK,
  SET_LOADING,
  LOGIN_FAIL,
  GET_CANDIDATE,
  ADD_CANDIDATE
} from '../types';

export default (state, action) => {
  switch (action.type) {



        case GET_CANDIDATE:

          return {
            ...state,
            candidates: action.payload,
            loading: false,
            error:null
          };
        case ADD_CANDIDATE:
          return {
            ...state,
            candidates: [action.payload,...state.candidates ],
            loading: false,
            error:null
          };


    case LOGIN_FAIL:
   
        return { ...state, error: action.payload, loading: false,
         };



      case SET_LOADING:
        return{
          ...state,
          loading:true
        }
    default:
      return state;
  }
};
