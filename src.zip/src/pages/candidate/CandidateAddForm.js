import React, { useState, useContext, useEffect } from 'react';
import {
    Row,
    Col,
    Card,
    CardBody,
    CustomInput,
    Form,
    FormGroup,
    Label,
    Input,
    FormText,
    Button,
    Alert
    
} from 'reactstrap';
import Select from 'react-select';

import PageTitle from '../../components/PageTitle';

import AuthContext from '../../context/auth/authContext';

import Loader from '../../components/Loader';
import CandidateContext from '../../context/candidate/candidateContext';



const DefaultForm = ({props}) => {
    const candidateContext = useContext(CandidateContext);
    const { addCandidate, loading, error  } = candidateContext;

    const [user, setUser] = useState({
        candidateEmail: '',
        candidateName: '',
        team:'',
        manager:'',
        sourceOfHire:'',
        candidateMobileNumber:'',
        candidateDesignation:'',
        joiningDate:''

    });



      const { candidateEmail, candidateName ,team,manager,sourceOfHire,candidateMobileNumber,candidateDesignation,joiningDate} = user;

    /**
     * Handles the submit
     */
    const onChange = e => setUser({ ...user, [e.target.name]: e.target.value });
  
    const onSubmit = (e) => {
        e.preventDefault();
        console.log(user)

        addCandidate({candidateEmail,candidateName, team,manager,sourceOfHire,candidateMobileNumber,candidateDesignation,joiningDate},props.history)
        
    }
    return (
        <Card>
            <CardBody>
                <h4 className="header-title mt-0">Add Potential Candidate</h4>
                <p className="text-muted">
                    Enter the name and candidateEmail of Candidate. And send invite{' '}
                </p>
                {error && <Alert color="danger" isOpen={error ? true : false}>
                                                    <div>{error}</div>
                                                </Alert>}
                                                {loading && <Loader />}

                <Row>
                    <Col xl={6}>
                        
                <Form onSubmit={onSubmit}> 
                <FormGroup>
                        <Label for="exampleNam2">Name</Label>
                        <Input type="text" name="candidateName" id="exampleNma2" placeholder="Enter name" value={candidateName} onChange={onChange}/>
                       </FormGroup>

                    <FormGroup>
                        <Label for="exampleEmal2">candidateEmail</Label>
                        <Input type="email" name="candidateEmail" id="exampleEmal2" placeholder="Enter Candidate candidateEmail" value={candidateEmail} onChange={onChange}/>
                        </FormGroup>

                    <FormGroup>
                        <Label for="exampleEmail2">Mobile Number</Label>
                        <Input type="text" name="candidateMobileNumber" id="examplemobileNo2" placeholder="Enter Candidate Mobile Number" value={candidateMobileNumber} onChange={onChange}/>
                           </FormGroup> 
                    
                    <FormGroup>
                        <Label for="exampledesignation2">candidateDesignation</Label>
                        <Input type="text" name="candidateDesignation" id="exampledesignation2" placeholder="Enter candidateDesignation" value={candidateDesignation} onChange={onChange}/>
                              </FormGroup>
                
                    
                </Form>
                </Col>
                <Col xl={6}>
                        <Form>
                            
                    <FormGroup>
                        <Label for="exampleEmail2">Team</Label>
                        <Input type="text" name="team" id="exampleteam2" placeholder="Team Or Function Name" value={team} onChange={onChange}/>
                       </FormGroup> 
                    
                    <FormGroup>
                        <Label for="exampleEmail2">Manager</Label>
                        <Input type="text" name="manager" id="examplemanager2" placeholder="Enter Manager Name" value={manager} onChange={onChange}/>
                          </FormGroup>
                
                    <FormGroup>
                        <Label for="exampleEmail2">Source Of Hire</Label>
                        <Input type="text" name="sourceOfHire" id="examplesourceOfHire2" placeholder="Linkedin..." value={sourceOfHire} onChange={onChange}/>
            
                    </FormGroup> 
                    
                  
                    <FormGroup>
                        <Label for="exampleEmail2">Joining Date</Label>
                        <Input type="date" name="joiningDate" id="examplejoiningDate2" placeholder="Linkedin..." value={joiningDate} onChange={onChange}/>
            
                    </FormGroup> 
                        </Form>
                    </Col>
                </Row>
                <Button color="primary" type="submit" onClick={onSubmit}>
                        Add Candidate    
                    </Button>
            </CardBody>
        </Card>
    );
};




const CandidateAddForm = (props) => {

    return (
        <React.Fragment>
            <Row className="page-title">
                <Col md={12}>
                <h4 className="mb-1 mt-0">Add Candidate Form</h4>
                 
                    
                </Col>
                </Row>

            <Row>
                <Col lg={12} >
                <DefaultForm const props={props} />
                </Col>
            </Row>

        </React.Fragment>
    );
};
export default CandidateAddForm;
