const express = require('express');
const router = express.Router();
const { protect, superAdmin } = require('../middleware/auth');


const { getNumber,sendEmail,sendWhatsapp,sendCall,sendSms,handleWhatsappWebhook,handleEmailWebhook,handleSmsWebhook,handleCallWebhook} = require('../controllers/twilioWebhook');

router.post('/smsWebhook', handleSmsWebhook);
router.post('/callWebhook', handleCallWebhook);
router.post('/whatsappWebhook',handleWhatsappWebhook)
router.post('/handleEmailWebhook',handleEmailWebhook)


router.post('/sendSms',protect,sendSms);
router.post('/sendCall',protect,sendCall);
router.post('/sendWhatsapp',protect,sendWhatsapp);
    router.post('/sendEmail',protect,sendEmail)
    router.post('/receiveSms',(req,res)=>{console.log('sms',req.body ,res)})


router.post('/getNumber',getNumber)



module.exports = router;