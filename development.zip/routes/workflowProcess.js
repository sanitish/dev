const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');

const {assignWorkflow,processWorkflowAction,getWorkflowProcessAction,deleteWorkflowProcessAction,getWorkflowProcessActionCandidate,editWorkflowProcessAction} = require('../controllers/workflowProcess');
//const {createMixedForm,getMixedForm} = require('../controllers/mixedForm');

router.post('/assignWorkflow',protect,assignWorkflow);
router.get('/getWorkflowProcessAction',protect,getWorkflowProcessAction);
router.get('/getWorkflowProcessActionCandidate',getWorkflowProcessActionCandidate);

router.post('/processWorkflowAction',protect,processWorkflowAction);

router.post('/deleteWorkflowProcessAction',deleteWorkflowProcessAction);
router.post('/editWorkflowProcessAction',editWorkflowProcessAction);


module.exports = router;