const Candidate = require('../models/Candidate');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const sendEmail = require('../utils/sendEmail');
const videoCall = require('../utils/videoCall');

const TwilioWebhook = require('../models/TwilioWebhook');
const WorkflowProcessAction = require('../models/WorkflowProcessAction');

// @desc      Get all users
// @access    Private/Admin
exports.getCandidate = asyncHandler(async (req, res, next) => {
const candidate = await Candidate.findById(req.params.candidate);
console.log(candidate);

  res.status(200).json({
    success: true,
    data: candidate
  });
});


// exports.getCandidates = asyncHandler(async (req, res, next) => {
//   const candidates = await Candidate.find({
//     _id:req.params.candidate
//   }).sort('-createdAt');
//   console.log(candidates);
  
//     res.status(200).json({
//       success: true,
//       data: candidates
//     });
//   });
  
// @desc      Get all users
// @access    Private/Admin
exports.getMyCandidates = asyncHandler(async (req, res, next) => {
    const candidates = await Candidate.find({
        // addedBy:req.user._id
        company:req.user.company._id

    }).populate('workflowActivity','processed').sort('-createdAt');
    console.log(candidates);
      res.status(200).json({
        success: true,
        data: candidates
      });
    });
    
    
    


// @desc      Create user
// @route     POST /api/users/adduser
// @access    Private/Admin
exports.addCandidate = asyncHandler(async (req, res, next) => {
  console.log(req.body)
  const  {    candidateName,
    candidateEmail,
    candidateMobileNumber,
    candidateDesignation,team,manager,sourceOfHire,joiningDate}  = req.body
  const candidate = new Candidate({
    company:req.user.company,
    addedBy:req.user._id,
    candidateName,
    candidateEmail,
    candidateMobileNumber,
    candidateDesignation,
    manager,
    sourceOfHire,
    team,
    joiningDate
  
  });
  console.log(candidate)
  const result  =await  candidate.save() 
  res.status(200).json({
    success: true,
    data: result
  });
});

exports.sendCandidateInvite = asyncHandler(async (req, res, next) => {
    console.log(req.user);
    
      // Create invite url
      const employeeInviteUrl = `${req.protocol}://${req.get(
        'host'
      )}/api/user/candidateInvite/${req.user._id}`;
    console.log(employeeInviteUrl)
      const message = `You are receiving this email because you (or someone else) has requested the reset of a password. Please make a PUT request to: \n\n ${employeeInviteUrl}`;
    
      try {
      const result=   await sendEmail({
          email: req.body.email,
          subject: 'invite url',
          message
        });
    
        res.status(200).json({ success: true, data: 'Email sent' });
      } catch (err) {
        console.log(err);
    
    
        return next(new ErrorResponse('Email could not be sent', 500));
      }
    
    
    });
    

    
exports.getCandidateInvite = asyncHandler( async (req,res,next)=>{
    console.log(req.params.companyId);
    const userId = req.params.userId;
    const user = await User.findById(userId).select('name').populate('company','name');
    res.status(200).json({
      success: true,
      data: user
    });
  });

    
  exports.getCandidateActivity = asyncHandler( async (req,res,next)=>{
    //console.log(req.params.companyId);
   // const userId = req.params.userId;
    const webhooks = await TwilioWebhook.find(req.query).sort('createdAt');
    res.status(200).json({
      success: true,
      data: webhooks
    });
  });



  exports.sendCandidateVideoInvite = asyncHandler(async (req, res, next) => {
     let Email = req.body.Mail.split(',');
    const candidate = await Candidate.findById(req.body.candidate);
    Email.push(candidate.candidateEmail, req.user.email) 
if(!candidate){
  return next(new ErrorResponse('candidate not a part of orgnisation', 400));
}

Email.forEach(async(e)=>{

const token =  await videoCall(e, candidate._id);

  // Create invite url
  const videoInviteUrl = `${req.protocol}://${req.get(
    'host'
  )}/video?identity=${token}`;
console.log(videoInviteUrl)
  const message = `use this link to join video call: \n\n ${videoInviteUrl}`;

  const result=   await sendEmail({
      email: e,
      subject: 'video call invite url',
      message
    });

})



res.status(200).json({ success: true, data: 'Email sent' });

    
    });

    exports.editCandidate=asyncHandler(async(req,res,next)=>{
      //params ya body decide kr lena
      const candidate = await Candidate.findByIdAndUpdate(req.query.id, req.body, {
        new: true,
        runValidators: true
      });
    
      res.status(200).json({
        success: true,
        data: candidate
      });
  
    })
    exports.deleteCandidate=asyncHandler(async(req,res,next)=>{
      //params ya body decide kr lena
      const candidate = await Candidate.findById(req.body.id);
  
      if (!candidate) {
        return next(
          new ErrorResponse(`No Candidate with the candidate of ${req.body.id}`, 404)
        );
      }
      else{
        await candidate.remove();
        await WorkflowProcessAction.remove({candidate:req.body.id});

        res.status(200).json({
          success: true,
          data: {'delete post':'successfull'}
        });
      }
  
    })


  