// @flow
import jwtDecode from 'jwt-decode';
import { Cookies } from 'react-cookie';

/**
 * Checks if user is authenticated
 */
const isUserAuthenticated = () => {
    const user = getLoggedInUser();
    if (!user) {
        return false;
    }
    const currentTime = Date.now() / 1000;
    if (user.exp < currentTime) {
        console.warn('access token expired');
        return false;
    } else {
        return true;
    }
};

/**
 * Returns the logged in user
 */
const  getLoggedInUser = () => {
    const cookies = new Cookies();
    const token = cookies.get('token');
    if(token){
        const user = jwtDecode(token);
        return user;

    }

};

const  getMe = () => {
    const cookies = new Cookies();
    const me = cookies.get('user');
    if(me){
        return me;

    }

};


export { isUserAuthenticated, getLoggedInUser,getMe };
