import React from 'react';
import avatar4 from '../../../assets/images/users/avatar-4.jpg';
import avatar7 from '../../../assets/images/users/avatar-7.jpg';
import { DropdownToggle, DropdownMenu, DropdownItem, UncontrolledDropdown,Card
} from 'reactstrap';
import { Briefcase, FolderPlus, HardDrive } from 'react-feather';
import ChatList from '../../../components/ChatList';
const Chat = ({candidate}) => {
    const chatMessages = [
        { id: 1, userPic: avatar4, userName: 'Geneva', text: 'Hello!', postedOn: '10:00' },
        {
            id: 2,
            userPic: avatar7,
            userName: 'Shreyu',
            text: 'Hi, How are you? What about our next meeting?',
            postedOn: '10:01',
        },
        { id: 3, userPic: avatar4, userName: 'Geneva', text: 'Yeah everything is fine', postedOn: '10:02' },
        { id: 4, userPic: avatar7, userName: 'Shreyu', text: "Wow that's great!", postedOn: '10:03' },
        { id: 5, userPic: avatar7, userName: 'Shreyu', text: 'Cool!', postedOn: '10:03' },
    ];

    return (
        <ChatList candidate={candidate} messages={chatMessages} height="268px"></ChatList>
    );
};
const Messages = ({candidate}) => {

    return (
        <React.Fragment>
            <Chat candidate={candidate}/>
        </React.Fragment>
    );
};

export default Messages;
