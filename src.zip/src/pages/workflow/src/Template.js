import React from 'react';

const template=(props)=>{
    // const templateSummary=Object.keys(props.templates).map(temp=>{
    // return (
    //     <li key={temp} >
    //         <button onClick={props.tempchooseHandler('why')} style={{ width:'100%'}}>{props.templates[temp]}</button>
    //     </li>)
    // })
    // function templateChooseHandler(temp){
    //     console.log(temp);
    // }
    
    return(
        <div>
            <h5>Choose one:</h5>
            <ul>
                {/* {templateSummary} */}
                {props.templates.map(temp=>{
                    return(
                        <button key={temp} onClick={()=>props.templatechoosehandler(temp)} style={{ width:'100%'}}>{temp}</button>
                    )
                })}
            </ul>
        </div>
    );
}

export default template;