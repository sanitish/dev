const mongoose = require('mongoose');

const WorkflowProcessActionSchema = new mongoose.Schema({
    actionType: {
        type: String,
        required: false
    },
    dayNo: {
        type: Number,
        require: false
    },
    label: {
        type: String
    },
    template: {
        type: String
    },
    time: {
        type: String
    },
    processed: {
        type: Boolean,
        required: true,
        default: false
    },
    doe: {
        type: String
    },
    candidate: {
        type: mongoose.Schema.ObjectId,
        ref: 'Candidate',
        required: true
    },
    workflow: {
        type: mongoose.Schema.ObjectId,
        ref: 'Workflow',
        required: true
    },
    addedBy: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: true
    }
});

module.exports = mongoose.model('WorkflowProcessAction', WorkflowProcessActionSchema);