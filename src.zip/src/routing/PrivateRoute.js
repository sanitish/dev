import React, { useContext } from 'react';
import { Route, Redirect } from 'react-router-dom';
import { isUserAuthenticated } from '../helpers/authUtils';

const PrivateRoute = ({ component: Component, ...rest }) => {
  const isAuthTokenValid = isUserAuthenticated();
  console.log(isAuthTokenValid,'nitish');
  return (
    
    <Route
        {...rest}
        render={props => {
            console.log(isUserAuthenticated())
            if (!isUserAuthenticated()) {
                // not logged in so redirect to login page with the return url
                return <Redirect to={{ pathname: '/account/login', state: { from: props.location } }} />;
            }

            // const loggedInUser = getLoggedInUser();
            // check if route is restricted by role
            // if (roles && roles.indexOf(loggedInUser.role) === -1) {
            //     // role not authorised so redirect to home pagecon
            //     return <Redirect to={{ pathname: '/pages/error-500' }} />;
            // }

            // authorised so return component
            return <Component {...props} />;
        }}
    />
  );
};

export default PrivateRoute;
