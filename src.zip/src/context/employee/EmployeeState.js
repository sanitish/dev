import React, { useReducer } from 'react';
import axios from 'axios';
import EmployeeContext from './employeeContext';
import employeeReducer from './employeeReducer';
import setAuthToken from '../../utils/setAuthToken';

import { Cookies } from 'react-cookie';

import {
  REGISTER_SUCCESS,
  REGISTER_FAIL,
  USER_LOADED,
  AUTH_ERROR,
  LOGIN_SUCCESS,
  LOGIN_FAIL,
  LOGOUT,
  CLEAR_ERRORS,
  GET_CONTACTS,
  ADD_CONTACT,
  ADD_TASK,
  GET_TASK,
  ADD_EMPLOYEE,
  GET_EMPLOYEE
} from '../types';

const EmployeeState = props => {
  const initialState = {
    loading: false,
    error: null,
    employee:[],
    tasks:[]

  };

  const [state, dispatch] = useReducer(employeeReducer, initialState);

   //SendInviteTo Employee
   const sendInviteToEmployee = async (formData, history) => {
    const cookies = new Cookies();
    let token = cookies.get('token');
    setAuthToken(token);

    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    // console.log(config)
    //setLoading();
    // console.log(formData)
    setLoading()

    try {
      const response = await axios.post('/api/user/sendEmployeeInvite', formData, config);
      // console.log(response)
      history.push('/apps/teams')
      const a =
      {
        name: formData.name,
        email: formData.email,
        role: formData.role.value

      }
      dispatch({
        type: ADD_EMPLOYEE,
        payload: a
      });

      //  loadUser();
    } catch (error) {
      // console.log('mera wala',error.response)
      // console.log('defautk',error.message)

      // console.log(typeof(error))

    
       

      dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
    }
  };


    //get Users all of a company

    const getEmployees = async () => {
      const cookies = new Cookies();
      let token = cookies.get('token');
      setAuthToken(token);
      const config = {
        headers: {
          'Content-Type': 'application/json'
        }
      };
      setLoading()
  
      try {
        const res = await axios.get('/api/user/getUsers', config);
        // console.log(res)
        dispatch({
          type: GET_EMPLOYEE,
          payload: res.data.data
        });
      } catch (error) {
        // console.log(error.response)
        // console.log(error.message)
  
        // console.log(typeof(error))
        dispatch({
          type: LOGIN_FAIL,
          payload: error.response.data.error || error.response.data
        });
      }
    };


    const addTask = async (task, history) => {
      const cookies = new Cookies();
      let token = cookies.get('token');
      setAuthToken(token);
  
      const config = {
        headers: {
          'Content-Type': 'application/json'
        }
      };
      setLoading()
  
      try {
        const res = await axios.post('/api/task/createTask', task, config);
        // console.log(res)
        dispatch({
          type: ADD_TASK,
          payload: res.data.data
        });
       // history.push('/apps/candidates/list')
      } catch (error) {
        // console.log(error.response)
        // console.log(error.message)
  
        // console.log(typeof(error))
  
           dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
      }
    };
  

    const editTask = async (task, history) => {
      const cookies = new Cookies();
      let token = cookies.get('token');
      setAuthToken(token);
  
      const config = {
        headers: {
          'Content-Type': 'application/json'
        }
      };
      setLoading()
  
      try {
        const res = await axios.post(`/api/task/editTask?id=${task.id}`, task, config);
        dispatch({
          type: ADD_TASK,
          payload: res.data.data
        });
        getTasks()
        console.log(res);
        
      } catch (error) {
 
           dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
      }
    };
  
    const getTasks = async (task, history) => {
      const cookies = new Cookies();
      let token = cookies.get('token');
      setAuthToken(token);
  
      const config = {
        headers: {
          'Content-Type': 'application/json'
        }
      };
      setLoading()
  
      try {
        const res = await axios.get('/api/task/getMyTasks', config);
        // console.log(res)
        dispatch({
          type: GET_TASK,
          payload: res.data.data
        });
        console.log(res);

       // history.push('/apps/candidates/list')
      } catch (error) {
        // console.log(error.response)
        // console.log(error.message)
  
        // console.log(typeof(error))
  
           dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
      }
    };
  

    const setLoading = () => dispatch({ type: 'SET_LOADING' })


  return (
    <EmployeeContext.Provider
      value={{
        loading: state.loading,
        error: state.error,
        employee:state.employee,
        tasks: state.tasks,

       sendInviteToEmployee,
       getEmployees,
       addTask,
       editTask,
       getTasks,
       setLoading,
      }}
    >
      {props.children}
    </EmployeeContext.Provider>
  );
};

export default EmployeeState;
