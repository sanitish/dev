import React,{useState} from 'react';
import EditableLabel from 'react-editable-label'; 
import {Modal, Card, CardGroup} from 'react-bootstrap';
import './template.css';
const SmsComp=(props)=>{
    const [show, setShow] = useState(false);
    const [select,setSelect]=useState(false);
    const [id,setIndex]=useState(null);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const templatehandler=(ind)=>{
        props.templateChange(props.dropdown[ind], index)
        setIndex(ind);
        setSelect(true);
        setShow(false);
    }
    const index=props.index; 
    let button=(
        <div>
        {props.dropdown.map((indivtemp, index)=>(
            <div class="templatecomp" >
                <p onClick={()=>{templatehandler(index)}} >{indivtemp}</p>
            </div>
        ))}
        </div>
    )
    return(
<div style={{width: '100%', margin: '30px 10px 0px 10px'}}>
        <CardGroup>
            <Card>
                <Card.Header style={{cursor:'pointer',display:'flex', backgroundColor:'darkcyan', color:'white', borderLeft:'2px solid darkcyan',borderRadius:'15px 0 0 0', fontSize:'15px'}}>
                        <EditableLabel
                            inputClass="form-control col-md-11"
                            initialValue={'Reminder'}
                            save={(value) => {props.inputchangeHandler(value, 'label',index)}}
                        /><i style={{margin:'5px'}} class="far fa-edit col-md-1"></i>
                    </Card.Header>
                <Card.Body style={{backgroundColor:'lightseagreen', color:'white', borderLeft:'2px solid lightseagreen',borderRadius:'0 0 0 15px'}}>
                    <Card.Text>
                        SMS
                    </Card.Text>
                </Card.Body>
            </Card>
            <Card>
            <Card.Header style={{backgroundColor:'darkcyan', color:'white', fontSize:'15px'}}>Choose from the template below</Card.Header>
                <Card.Body style={{backgroundColor:'lightseagreen', color:'white'}}>
                    <Card.Text>
                    {!select?<button className="btn" onClick={handleShow}><i className='uil uil-sms mr-1'></i>Templates</button>:<p>{props.dropdown[id]}</p>}
                            <Modal show={show} onHide={handleClose}>
                                <Modal.Header closeButton>
                                <Modal.Title>Choose a template from the given:</Modal.Title>
                                </Modal.Header>
                                <Modal.Body>
                                    {button}
                                </Modal.Body>
                            </Modal>
                    </Card.Text>
                </Card.Body>
            </Card>
            <Card>
            <Card.Header style={{fontSize:'15px', backgroundColor:'darkcyan', color:'white', borderRight:'2px solid darkcyan',borderRadius:'0 15px 0 0'}}>Scheduled on</Card.Header>
                <Card.Body style={{backgroundColor:'lightseagreen', color:'white', borderRight:'2px solid lightseagreen',borderRadius:'0 0 15px 0'}}>
                    <Card.Text>
                    <input type="number" class="form-control" placeholder="Day 0" onChange={(event)=>{props.inputchangeHandler(event.target.value, 'dayNo', index)}}/>
                    </Card.Text>
                    <Card.Text>
                    <input type="time" class="form-control" onChange={(event)=>{props.inputchangeHandler(event.target.value, 'time', index)}}/>
                    </Card.Text>
                </Card.Body>
            </Card>
        </CardGroup>
    </div>
)}

export default SmsComp;