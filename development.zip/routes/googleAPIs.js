const express = require('express');
const router = express.Router();

const {getAuthUrl,handleOauthCallback,addCalanderEvents} = require('../utils/googleCalander');
const { protect } = require('../middleware/auth');


router.get("/syncCalander",protect, getAuthUrl);

router.get("/oauthcallback", handleOauthCallback);
// router.post("/addCalanderEvents", addCalanderEvents);


///router.get("/getGoogelCalanderEvents", getCalanderEvents);
module.exports = router;