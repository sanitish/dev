// Refer to the Node.js quickstart on how to setup the environment:
// https://developers.google.com/calendar/quickstart/node
// Change the scope to 'https://www.googleapis.com/auth/calendar' and delete any
// stored credentials.


const ErrorResponse = require('./errorResponse');


const { google } = require('googleapis');
const User = require('../models/User');


// If modifying these scopes, delete token.json.
const SCOPES = ['https://www.googleapis.com/auth/calendar'];

const oAuth2Client = new google.auth.OAuth2(
    "815027652864-pe1e9s6f441rq0acje2dn91bgimfj0a9.apps.googleusercontent.com",
    "oAEeKEKkDmudIHVIj7vobuE5",
    // "https://app.beamfox.io/oauthcallback"
    "http://localhost:8080/oauthcallback"

);



exports.getAuthUrl = async (req, res, next) => {
    const authUrl = await oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: SCOPES,
    })
    console.log(authUrl)
 res.send({url:authUrl});
    try {
       //res.redirect(authUrl);
    } catch (err) {
        console.log(err);
    }
}

exports.handleOauthCallback = async (req,res,next) => {
//   console.log('reqqqqqq',req) ;
  
    try {
       const { tokens } = await oAuth2Client.getToken(req.query.code)
     let auth1 =    oAuth2Client.setCredentials(tokens);
     console.log(tokens);
     
    //  oauth2Client.on('tokens', (tokens) => {
    //     if (tokens.refresh_token) {
    //       // store the refresh_token in my database!
    //       console.log(tokens.refresh_token);
    //     }
    //     console.log(tokens.access_token);
    //   });

    const calendar = google.calendar({ version: 'v3', auth:oAuth2Client });

    calendar.events.list({
        calendarId: 'primary',
        timeMin: (new Date()).toISOString(),
        maxResults: 10,
        singleEvents: true,
        orderBy: 'startTime',
    }, (err, res) => {
        if (err) return console.log('The API returned an error: ' + err);
        const events = res.data.items;
        if (events.length) {
            console.log('Upcoming 10 events:');
            events.map((event, i) => {
                const start = event.start.dateTime || event.start.date;
                console.log(`${start} - ${event.summary}`);
            });
        } else {
            console.log('No upcoming events found.');
        }
    })
        let event ={
            'summary': 'Google I/O 2015',
            'location': '800 Howard St., San Francisco, CA 94103',
            'description': 'A chance to hear more about Google\'s developer products.',
            'start': {
                'dateTime': '2020-05-28T09:00:00-07:00',
                'timeZone': 'Asia/Kolkata',
            },
            'end': {
                'dateTime': '2021-05-28T17:00:00-07:00',
                'timeZone': 'Asia/Kolkata',
            },
            'recurrence': [
                'RRULE:FREQ=DAILY;COUNT=2'
            ],
            'attendees': [
                { 'email': 'nitish@beamfox.io' },
            ],
            'reminders': {
                'useDefault': false,
                'overrides': [
                    { 'method': 'email', 'minutes': 24 * 60 },
                    { 'method': 'popup', 'minutes': 10 },
                ],
            },
        };
        // let auth =await oAuth2Client.setCredentials(tokens)
        console.log('token' ,tokens);
        console.log('auth1',oAuth2Client);
        
        // const calendar = google.calendar({ version: 'v3', auth:oAuth2Client});
        calendar.events.insert({
            auth:  oAuth2Client,
            calendarId: 'primary',
            resource: event,
        }, function (err, event) {
            if (err) {
                console.log('There was an error contacting the Calendar service: ' + err);
                return;
            }
            console.log(event);
            console.log('Event created: %s', event);
        });
    //    console.log('token' ,tokens.access_token);
     res.redirect(`http://localhost:3000/apps/calendar?token=${tokens.access_token}`)
    //    const user = await User.findByIdAndUpdate(req.user._id, {googleAuthToken:tokens}, {
    //     new: true,
    //     runValidators: true
    //   });

    //   console.log('elk nsdas',user);
      
    //    res.redirect('/apps/calendar' , token.access_token);
    //    return tokens

    }
    catch (err) {
        return next(new ErrorResponse('Calander could not be synced', 500));
    }
}



// exports.getCalanderEvents = (auth='ya29.a0AfH6SMBR55zzbvlLm13vWRuZ3zywU5FYXD8G26YfVZi78Vrz6ijnf492S2khq2et0vU3ItDw-VUJhmLPPaiWXJ2yv2Ii565iRgIuXAQUQ97s6KyKxxei40t-HJq53w6O_yJb73-ASD13h54LnlrOvyACaA6_Yw3QbHo') => {
//     const calendar = google.calendar({ version: 'v3', auth });

//     calendar.events.list({
//         calendarId: 'primary',
//         timeMin: (new Date()).toISOString(),
//         maxResults: 10,
//         singleEvents: true,
//         orderBy: 'startTime',
//     }, (err, res) => {
//         if (err) return console.log('The API returned an error: ' + err);
//         const events = res.data.items;
//         if (events.length) {
//             console.log('Upcoming 10 events:');
//             events.map((event, i) => {
//                 const start = event.start.dateTime || event.start.date;
//                 console.log(`${start} - ${event.summary}`);
//             });
//         } else {
//             console.log('No upcoming events found.');
//         }
//     })
// };



// exports.addCalanderEvents = () => {
//     let event ={
//         'summary': 'Google I/O 2015',
//         'location': '800 Howard St., San Francisco, CA 94103',
//         'description': 'A chance to hear more about Google\'s developer products.',
//         'start': {
//             'dateTime': '2015-05-28T09:00:00-07:00',
//             'timeZone': 'America/Los_Angeles',
//         },
//         'end': {
//             'dateTime': '2015-05-28T17:00:00-07:00',
//             'timeZone': 'America/Los_Angeles',
//         },
//         'recurrence': [
//             'RRULE:FREQ=DAILY;COUNT=2'
//         ],
//         'attendees': [
//             { 'email': 'lpage@example.com' },
//             { 'email': 'sbrin@example.com' },
//         ],
//         'reminders': {
//             'useDefault': false,
//             'overrides': [
//                 { 'method': 'email', 'minutes': 24 * 60 },
//                 { 'method': 'popup', 'minutes': 10 },
//             ],
//         },
//     };
//     const calendar = google.calendar({ version: 'v3', auth });
//     calendar.events.insert({
//         auth: auth,
//         calendarId: 'primary',
//         resource: event,
//     }, function (err, event) {
//         if (err) {
//             console.log('There was an error contacting the Calendar service: ' + err);
//             return;
//         }
//         console.log(event);
//         console.log('Event created: %s', event.htmlLink);
//     });
// }

