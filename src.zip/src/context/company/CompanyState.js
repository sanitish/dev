import React, {useReducer} from 'react';
import axios from 'axios';
import companyReducer from './companyReducer';
import {SET_ALERT, REMOVE_ALERT, LOGIN_FAIL} from '../types';
import CompanyContext from './companyContext';

const CompanyState = props => {
  const initialState = {
    registerDetail:[],
    error: null,
  };
  const [state, dispatch] = useReducer(companyReducer, initialState);

  // Set Alert
  const  formInput = formData => {
    // console.log(formData);
    dispatch({
      type: SET_ALERT,
      payload: formData
    });

  };

  const clearForm = () => {
    dispatch({
      type: "CLEAR_FORM"
    });

  };

  //Register company
  const companyRegister = async (formData, history) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };
    // console.log(formData)
    try {
      const res = await axios.post('/api/company/addCompany', formData, config);

      history.push('/account/confirm');

      dispatch({
        type: "REGISTER_SUCCESS",
        payload: res.data
      });


    } catch (error) {
      dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
    }
  };
  return (
    <CompanyContext.Provider
      value={{
        registerDetail: state.registerDetail,
        error:state.error,
        formInput,
        clearForm,
        companyRegister

      }}>
      {props.children}
    </CompanyContext.Provider>
  );
};

export default CompanyState;
