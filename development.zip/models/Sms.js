// const mongoose = require('mongoose');

// const SmsSchema = new mongoose.Schema({
// body:{
//     type:String,
//     required:true
// },
//     user: {
//         type: mongoose.Schema.ObjectId,
//         ref: 'User',
//         //required: true
//       },
//       candidate: {
//         type: mongoose.Schema.ObjectId,
//         ref: 'Candidate',
//        // required: true
//       },
// createdAt:{
//     type:Date,
//     default: Date.now
// }
// });

// module.exports = mongoose.model('Sms', SmsSchema);