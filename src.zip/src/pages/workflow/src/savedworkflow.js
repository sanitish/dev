import React, {Component} from 'react';
import { Card, CardGroup} from 'react-bootstrap';
import './savedworkflow.css';

class SavedWorkflow extends Component{
    state={
        newworkarray:[],
        newworkname:'',
        visible: false
    }
        toggle=()=>{
            this.setState(prevState=>({
                visible: !prevState.visible
            }))
            // console.log(this.state.visible)
        }

    render(){
    return(
        <div style={{width: '100%', margin: '20px 10px 0px 10px',cursor:'pointer'}}>
        <CardGroup >
            <Card>
           <Card.Header style={{backgroundColor:'dodgerblue', color:'white', paddingBottom:'33px', borderLeft:'2px solid dodgerblue',borderRadius:'15px 0 0 0'}}>{this.props.newworkname}</Card.Header>
                <Card.Body style={{backgroundColor:'lightskyblue', color:'white', borderLeft:'2px solid lightskyblue',borderRadius:'0 0 0 15px'}}>
                    <Card.Text>
                        Created by: John Doe
                    </Card.Text>
                </Card.Body>
            </Card>
            <Card>
                <Card.Header style={{backgroundColor:'dodgerblue', color:'white', paddingBottom:'33px'}}>Total Actions</Card.Header>
                <Card.Body style={{backgroundColor:'lightskyblue', color:'white'}}>
                    <Card.Text>
                        {this.props.totalactions}
                    </Card.Text>
                </Card.Body>
            </Card>
            <Card>
                <Card.Header style={{backgroundColor:'dodgerblue', color:'white', paddingBottom:'33px'}}>Total Days</Card.Header>
                <Card.Body style={{backgroundColor:'lightskyblue', color:'white'}}>
                    <Card.Text>
                        {this.props.totaldays}
                    </Card.Text>
                </Card.Body>
            </Card>
            <Card>
                <Card.Header style={{backgroundColor:'dodgerblue', color:'white'}}>Candidates Assigned</Card.Header>
                <Card.Body style={{backgroundColor:'lightskyblue', color:'white'}}>
                    <Card.Text>
                        11
                    </Card.Text>
                </Card.Body>
            </Card>
            <Card>
                <Card.Header style={{backgroundColor:'dodgerblue', color:'white', paddingBottom:'33px', borderRight:'2px solid dodgerblue',borderRadius:'0 15px 0 0'}}>Completion Rate</Card.Header>
                <Card.Body style={{backgroundColor:'lightskyblue', color:'white', borderRight:'2px solid lightskyblue',borderRadius:'0 0 15px 0'}}>
                    <Card.Text>
                        69%
                    </Card.Text>
                </Card.Body>                
            </Card>
        </CardGroup>
    </div>
    );
}}
export default SavedWorkflow;