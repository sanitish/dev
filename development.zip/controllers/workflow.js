const jwt = require('jsonwebtoken');

const Workflow = require('../models/Workflow');
const User = require('../models/User');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const sendEmail = require('../utils/sendEmail');



exports.createWorkflow = asyncHandler(async (req, res, next) => {
  req.body.company = req.user.company._id;
  req.body.createdBy = req.user._id;

  console.log(req.body)
    const workFlow = await Workflow.create(req.body);
    res.status(200).json({
      success: true,
      data: workFlow
    });
  });


  exports.getWorkflow = asyncHandler(async (req, res, next) => {
    const workFlow = await Workflow.find({company:req.user.company._id}).populate('createdBy' , 'name');
    console.log(workFlow,'nitish')
    res.status(200).json({
      success: true,
      data: workFlow
    });
  });

  exports.deleteWorkflow=asyncHandler(async(req,res,next)=>{
    //params ya body decide kr lena
    const workflow = await Workflow.findById(req.body.id);

    if (!workflow) {
      return next(
        new ErrorResponse(`No workflow with the id of ${req.body.id}`, 404)
      );
    }
    else{
      await workflow.remove();

      res.status(200).json({
        success: true,
        data: {'delete post':'successfull'}
      });
    }

  })


  exports.editWorkflow=asyncHandler(async(req,res,next)=>{
    //params ya body decide kr lena
    const workflow = await Workflow.findByIdAndUpdate(req.query.id, req.body, {
      new: true,
      runValidators: true
    });
  
    res.status(200).json({
      success: true,
      data: workflow
    });

  })

 