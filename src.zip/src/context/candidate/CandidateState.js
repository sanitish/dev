import React, { useReducer } from 'react';
import axios from 'axios';
import CandidateContext from './candidateContext';
import candidateReducer from './candidateReducer';
import setAuthToken from '../../utils/setAuthToken';
import { Cookies } from 'react-cookie';

import {
  LOGIN_FAIL,
  GET_CONTACTS,
  ADD_CONTACT,
  GET_CANDIDATE,
  ADD_CANDIDATE
} from '../types';

const CandidateState = props => {
  const initialState = {
    loading: false,
    error: null,
    candidates:[]
  };

  const [state, dispatch] = useReducer(candidateReducer, initialState);

    //get candidate
    const getCandidates = async () => {
      // console.log('yes yeys ye s')
      const cookies = new Cookies();
      let token = cookies.get('token');
      setAuthToken(token);
      const config = {
        headers: {
          'Content-Type': 'application/json'
        }
      };
      setLoading()
      try {
        const res = await axios.get('/api/candidate/getMyCandidates', config);
        // console.log('nitish ka resospdfsdj', res);
        dispatch({
          type: GET_CANDIDATE,
          payload: res.data.data
        });
      } catch (error) {
          dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
      }
    };
  
    
    //add candiadte
    const addCandidate = async (contact, history) => {
      const cookies = new Cookies();
      let token = cookies.get('token');
      setAuthToken(token);
  
      const config = {
        headers: {
          'Content-Type': 'application/json'
        }
      };
      setLoading()
  
      try {
        const res = await axios.post('/api/candidate/addCandidate', contact, config);
        // console.log(res)
        dispatch({
          type: ADD_CANDIDATE,
          payload: res.data.data
        });
        history.push('/apps/candidateList')
      } catch (error) {
        // console.log(error.response)
        // console.log(error.message)
  
        console.log(typeof(error))
  
          dispatch({
        type: LOGIN_FAIL,
        payload: error.response.data.error || error.response.data
      });
      }
    };
  
    const setLoading = () => dispatch({ type: 'SET_LOADING' })

  return (
    <CandidateContext.Provider
      value={{
        loading: state.loading,
        error: state.error,
        candidates:state.candidates,
        addCandidate,
        getCandidates,
        setLoading
      }}
    >
      {props.children}
    </CandidateContext.Provider>
  );
};

export default CandidateState;
