import React,{useState} from 'react';
import { Card, CardBody, Row, Col, Button } from 'reactstrap';


const FormTemplates = () => {
const [messages,setMessages]=useState([`
First Name
Last Name 
Have you used a different name in the past?
⛒ Yes
⛒ No
Current Address 
Address Line 1
Address Line 2
City
State
Zip Code
Have you lived at the previous address?
⛜ Yes
⛜ No
Date of Birth
Social Security Number
Phone
Drivers License Number
Driver's License State
The information above is correct to the best of my knowledge.*
⛛ Yes
`,
`Available To Start_______________________
Referral Source___________________________
Have you ever been employed by us before:   Yes/No
Are you legally permitted to work in this country:    Yes/No
Are you above the minimum working age of _______:  Yes/No
Have you ever been convicted of a felony:   Yes/No
If yes please explain__________________________
A positive response is not an automatic bar to employment with the company. The offense for which the person was convicted in relation to the position to which they have applied will be considered.
Please indicate availability to work:
Monday
Tuesday
Wednesday
Thursday
Friday
Saturday
Sunday
`
]);
    return (
        <React.Fragment>
            <Card>
                <CardBody>
                    <h2 className="mb-3 mt-0 header-title">Form Templates</h2>
                    <Row className="bg-light p-3">
                        {messages.map(message=>(
                            <div style={{border:'2px solid lightskyblue',borderRadius:'15px',padding:'10px', margin:'30px 10px'}} >
                            <Card>
                                <Row>
                                    <Col>
                                        <CardBody>
                                            <h5 className="card-text text-muted">{message}</h5>
                                            <p className="card-text"><small className="text-muted">Last updated 7 mins ago</small></p>
                                        </CardBody>
                                    </Col>
                                </Row>
                            </Card></div>))}
                    </Row>
                </CardBody>
            </Card>
        </React.Fragment>
    );
};

export default FormTemplates;
