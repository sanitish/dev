import React from 'react';
import { Card, CardBody, Row, Col, Progress } from 'reactstrap';

import profileImg from '../../../assets/images/users/avatar-7.jpg';
import VidTrigg from './VidTrigger';
import ModalSendSms from '../../../components/ModalSendSms';
import ModalSendCall from '../../../components/ModalSendCall';
import ModalSendEmail from '../../../components/ModalSendEmail';
import ModalAddCandidate from '../../../components/ModalAddCandidate';
import profilePic from '../../../assets/images/profilePic.jpg';
import Axios from 'axios';
const UserBox = ({props, candidate}) => {
//     console.log(props)

    const handleDelete = async() =>{
        try{
            const result = await  Axios.post('/api/candidate/deleteCandidate', {id:candidate._id});
           // console.log(result)
            props.history.push('/apps/candidateList');
        }catch(err){
          //  console.log(err);
        }

    }
    return (
        <>
 { candidate &&
        <Card className="">
            <CardBody className="profile-user-box">
                <Row>
                    <Col>
                        <div className="text-center mt-3">
                            <img src={profilePic} alt=""
                                className="avatar-lg rounded-circle" />
                            <h5 className="mt-2 mb-0">{candidate.candidateName}</h5>
                            <h6 className="text-muted font-weight-normal mt-1 mb-4">{candidate.candidateDesignation}</h6>

                            <Progress className="mb-4" value={60} color="success" style={{ 'height': '14px' }}>
                                <span className="font-size-12 font-weight-bold">Health Score is <span className="font-size-11">60%</span> completed</span>
                            </Progress>

                     

                            <ModalSendEmail candidate={candidate}/>
                            <ModalSendCall candidate={candidate}/>
                            <ModalSendSms candidate={candidate}/>
                            <VidTrigg candidate={candidate}/>
                            {/* <button type="button" className="btn btn-primary btn-sm mr-1">Video Call</button> */}
                        </div>
{/* 
                        <div className="mt-5 pt-2 border-top">
                            <h4 className="mb-3 font-size-15">About</h4>
                            <p className="text-muted mb-4">Hi I'm Shreyu. I am user experience and user
                                interface designer. I have been working on UI & UX since last 10 years.</p>
                        </div> */}

                        <div className="mt-3 pt-2 border-top">
                            <h4 className="mb-3 font-size-15">Contact Information
                            <ModalAddCandidate candidate={candidate}/>
                            </h4>
                            
                                                        <div className="table-responsive">
                                <table className="table table-borderless mb-0 text-muted">
                                    <tbody>
                                        <tr>
                                            <th scope="row">Email</th>
 <td>{candidate.candidateEmail}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Phone</th>
 <td>{candidate.candidateMobileNumber}</td>
                                        </tr>
                                        {/* <tr>
                                            <th scope="row">Address</th>
                                            <td>1975 Boring Lane, San Francisco, California, United States -
                                                            94108</td>
                                        </tr> */}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div className="mt-3 pt-2 border-top">
                        <button className="btn btn-danger btn-block" onClick={handleDelete}><i className="uil uil-edit mr-2"></i>Delete Candidate</button>
                             {/*
                            <h4 className="mb-3 font-size-15">Skills</h4>
                            <label className="badge badge-soft-primary mr-1">UI design</label>
                            <label className="badge badge-soft-primary mr-1">UX</label>
                            <label className="badge badge-soft-primary mr-1">Sketch</label>
                            <label className="badge badge-soft-primary mr-1">Photoshop</label>
                            <label className="badge badge-soft-primary mr-1">Frontend</label>*/}
                        </div> 

                    </Col>
                </Row>
            </CardBody>
        </Card>
}
</>
    );
};

export default UserBox;
