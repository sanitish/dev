import { createContext } from 'react';

const candidateContext = createContext();

export default candidateContext;
