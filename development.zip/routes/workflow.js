const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');

const {createWorkflow,getWorkflow,deleteWorkflow,editWorkflow} = require('../controllers/workflow');
const {createMixedForm,getMixedForm} = require('../controllers/mixedForm');

router.post('/createWorkflow',protect,createWorkflow);
router.get('/getWorkflow',protect,getWorkflow);
router.post('/editWorkflow',protect,editWorkflow);
router.delete('/deleteWorkflow',protect,deleteWorkflow);

module.exports = router;