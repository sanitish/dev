import React,{useState} from 'react';
import { Card, CardBody, Row, Col, Button } from 'reactstrap';


const EmailTemplates = () => {
const [messages,setMessages]=useState([` Welcome to [Company name]
Dear [Employee’s name],
We are all really excited to welcome you to our team! As agreed, your start date is [date.] We expect you to be in our offices by [time] and our dress code is [casual/ business casual.]
[If necessary, remind your employee that they need to bring their ID/ paperwork.]
At [Company name], we care about giving our employees everything they need to perform their best. As you will soon see, we have prepared your workstation with all necessary equipment. Our team will help you set up your computer, software and online accounts on your first day. [Plus, if applicable, mention any extra things you’ve prepared for your new hire, like a parking spot, a coffee mug with their name or a company t-shirt.]
We’ve planned your first days to help you settle in properly. You can find more details in the enclosed agenda. As you will see, you’ll have plenty of time to read and complete your employment paperwork (HR will be there to help you during this process!) You will also meet with your hiring manager to discuss your first steps. For your first week, we have also planned a few training sessions to give you a better understanding of our company and operations.
Our team is excited to meet you and look forward to introducing themselves to you during [planned event/ lunchtime].
If you have any questions prior to your arrival, please feel free to email or call me and I’ll be more than happy to help you.
We are looking forward to working with you and seeing you achieve great things!
Best regards,
[Your name]
[Your signature]
`,
  `Subject: <Candidate Name> employee verification 

  Dear <First Name>,
  
   I am <Your Name> from <Company Name>.
   This is with regard to the referral check of <Name>, who worked with you as .
  
  
  Can you please let me know the following details about them: 
  
  Name: 
  Period of Employment:
  Designation: 
  CTC: 
  Reason for leaving the organization: 
  Exit formalities: Completed / Uncompleted 
  Verified By: 
  
  It would be very kind if you could spare a few minutes and provide your feedback. Your cooperation in this regard will be highly appreciated. , a quick response by return email would be appreciated. 
  
  Thanks 
  <Your Name>
  
  You can also attach scanned documents (relieving ,experience letters,pay slip) provided by candidates. `,`Please welcome [First and last name] who will be the new [job title] !

  We are excited for you to join the team.[First Name] will be responsible for [job duties]. [First name] joins us from previously working at [employment background] and graduated from [academic background] 
 
 We know you’re going to be a valuable asset to our company and can’t wait to see what you accomplish at [company name].
 
 Cheers! 
 [Name]
 `,`I am very pleased to announce that our team is growing. [Start date, e.g. Next week or Next Monday], [Name] will be joining us as our new [job title.] [Add information about what they’ll be doing / what they’ll be responsible]. [He/She] has previously worked at [Add information about employment background] / [He/She] has recently graduated from [Add information about academic background.]. Please join me in welcoming our new team member and make sure to stop by to introduce yourselves!
 In behalf of [company], we would like to welcome [name] as the new [job title]. All of us here are excited to get to know you and work with you on upcoming projects. [Name] joins us from having graduated from [academic background] and working at [employment background]. Welcome [name] to our team.”
 [name] will be joining [company] on [start date] to fill our position in the [division] department. [name]’s experience comes from working at [employment background] and graduated from [academic background]. [insert fun personal fact about new hire]. Thanks for joining me in welcoming [name] to the team.
 `,
      `Hi <First Name>

      Sharing company dress code policy brief at your perusal. Feel free to reach out in case of any query or details. 
      
      Dress code policy
       
      Policy brief & purpose
      Our dress code company policy outlines how we expect our employees to dress at work. Employees should note that their appearance matters when representing our company in front of clients, visitors or other parties. An employee’s appearance can create a positive or negative impression that reflects on our company and culture.
      Scope
      This policy applies to all our employees.
      Policy elements
      These dress code rules always apply:
      All employees must be clean and well-groomed. Grooming styles dictated by religion and ethnicity aren’t restricted.
      All clothes must be work-appropriate. Clothes that are typical in workouts and outdoor activities aren’t allowed.
      All clothes must project professionalism. Clothes that are too revealing or inappropriate aren’t allowed.
      All clothes must be clean and in good shape. Discernible rips, tears or holes aren’t allowed.
      Employees must avoid clothes with stamps that are offensive or inappropriate.
      What is Business Dress Code?
      Our company’s official dress code is [ Business/ Business Casual/ Smart Casual/ Casual. ]
      We may change our dress code in special cases. For example, we may require employees to wear semi-formal attire for an event. Then, both male and female employees should wear suits, ties, white shirts and appropriate shoes. Our company may also introduce [dress-down Friday] when employees can wear more casual clothing like jeans, simple blouses and boots. This won’t apply if employees are meeting with clients, partners and other external parties.
      An employee’s position may inform their dress code. If employees frequently meet with clients or prospects, they should conform to a business dress code.
      Disciplinary Consequences
      When an employee disregards our dress code, their supervisor should reprimand them. The employee should start respecting our dress code immediately. In some cases, supervisors may ask employees to return home to change.
      Employees may face more severe consequences up to and including termination, if:
      Their appearance causes irreparable damage, like loss of a major client.
      They repeatedly violate our dress code.
       Thank You 
      <Name>
      `,
      `Appropriate Business Attire
      Business attire is to be worn Monday and through Friday. Appropriate business attire for employee include the following:
      Men:
                     Blazers, suits, or sport coats
      Dress slacks            
      @Ties                
      @Dress shirts with buttons and collars
      @Dress shoes
      Women:
      Dresses
      Skirts or skorts*
      Dress slacks
      Blouses
      Dress shoes
      Sweaters
      Nylons or stocking
             
      * Skorts are defined as non-tailored split skirts. They do not include walking shorts or Bermuda shorts.
      Appropriate Casual Business Attire
      Casual business attire may be worn on Friday of each week. Appropriate casual business
      attire for employees including the following:
      Men:
      Sport coats or blazers
      Slacks, Chinos or Dockers
      Polo shirts with collars
      Oxford button-down shirts
      Sweaters and cardigans
      Loafers and huaraches
      Sweaters
      Women
      Slacks
      Stirrup pants
      Walking shorts
      Polo shirts
      Culottes, skorts, or splint skirts
      Loafers and huaraches
      Sweaters
      Unacceptable Attire
      Plain or pocket T-shirts
      Cutoffs
      T-shirts with logos          
      Athletic wear
      Thongs of any kind          
      Blue denim jeans
      Spandex or Lycra such as biker shorts    
      Tennis shoes
      Tank tops, tube tops, halter tops with spaghetti straps          
      Deck shoes
      Underwear as outerwear
      Beach wear            
      Midriff length tops
      Provocative attire          
      Off-the-shoulder tops
      Workout clothes or shoes        
      Evening wear
      Enforcement
      Department managers and supervisors are responsible for monitoring and enforcing this policy. The policy will be administered according to the following action steps:
      1.    If questionable attire is worn in the office, the respective department             supervisor/manager will hold a personal, private discussion with the employee to advise and counsel the employee regarding the inappropriateness of the attire.
      2.    If an obvious policy violation occurs, the department supervisor/manager will hold a private discussion with the employee and ask the employee to go home and change his/her attire immediately.
      3.    Repeated policy violations will result in disciplinary action, up to and including termination.
      `,`To All Employees,
      The management of [company or department] would like to invite everyone to come out and enjoy some food and fun. You have all worked so hard this past [length of time], and we would like to show how much we appreciate all you do for the company and the customer.
      The Employee Luncheon will be held at [time] on [date]. The Luncheon will be located [location]. We will serve [including a summary of the menu], and there will be entertainment in the form of [list entertainment].
      Everyone is encouraged to attend and enjoy the food and company.
      Thanks,
      `,`You are invited to lunch with [Manager Name] and a member of the HR team. 
      This is an opportunity to meet some of the team members, as well as share and provide any suggestions about your Pre-bording experience here at [Company name]. 
      
      Date -
      Time -
      Location -
      Contact- 
      
      RSVP no later than - [Date]
      
      [Address]
      
      
      
      See you on the lunch
      
      Cheers!
      First Name
      `,`You are cordially invited to our office dinner party as an expression of our gratitude for being highly dedicated to lead your team this whole year. The dinner will be on Friday, July 29th starting from 6 o'clock in the evening at The Hilton, Cambridge.
      Winnie Schwab.
      `
]);
    return (
        <React.Fragment>

                    <h2 className="mb-3 mt-0 header-title">Email Templates</h2>
                    <Row className="bg-light p-3">
                        {messages.map(message=>(
                            <div style={{border:'2px solid lightskyblue',borderRadius:'15px',padding:'10px', margin:'30px 10px'}} >
                            <Card>
                                <Row className="no-gutters align-items-center">
                                    <Col>
                                        <CardBody>
                                            <h5 className="card-text text-muted">{message}</h5>
                                            <p className="card-text"><small className="text-muted">Last updated 1 mins ago</small></p>
                                        </CardBody>
                                    </Col>
                                </Row>
                            </Card>
                            </div>
                            ))}</Row>
        </React.Fragment>
    );
};

export default EmailTemplates;
