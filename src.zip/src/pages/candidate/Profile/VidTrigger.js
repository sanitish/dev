import React, { useState,useEffect , useContext} from 'react';
import { Modal, Button } from 'react-bootstrap';
import CandidateContext from '../../../context/candidate/candidateContext';
import Axios from 'axios';
import setAuthToken from '../../../utils/setAuthToken';

const VidTrigg = ({candidate}) => {
  const [show, setShow] = useState(false);
  const [task, setTask] = useState({
    Name:'',
    Mail:'',
    Description:'',
    date:'',
    time:'',
    candidate:candidate._id
    });

const {Name,Mail,Description,date,time} = task;

const onChange= e =>{
  setTask({...task, [e.target.name]:e.target.value});
}

const onSubmit = e =>{
  e.preventDefault();
      console.log(task);
      setAuthToken();
      Axios.post('/api/candidate/sendCandidateVideoInvite',task).
      then((res)=>{
        console.log(res)
      }).catch((err)=>{
        console.log(err);
      })
      alert("Video Triggered");
      setShow(false);

} 
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <>
      <button className="btn btn-sm btn-primary" onClick={handleShow}><i className='uil  mr-1'></i>Video</button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Video Conference Settings for {candidate.candidateName}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form>
            <div class="form-group">
              <label>Conference Name</label>
              <input type="text" class="form-control" name="Name" value={Name} onChange={onChange}/>
            </div>
            <div class="form-group">
              <label>Email IDs</label>
              <input type="email" class="form-control" name="Mail" value={Mail} onChange={onChange} multiple/>
            </div>
            <div className="row">
                <div className="col">
                    <div class="form-group">
                    <label>Time</label>
                    <input type="time" class="form-control" name="time" value={time} onChange={onChange}  />
                    </div>
                </div>
              <div className="col">
                <div class="form-group">
                  <label>Date</label>
                  <input type="date" class="form-control" name="date" value={date} onChange={onChange}  />
                </div>
              </div>
            </div>


            <div class="form-group">
              <label >Event Description(Optional)</label>
              <textarea class="form-control" rows="3" name="Description" value={Description} onChange={onChange}></textarea>
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
</Button>
          <Button variant="primary" onClick={onSubmit}>
            Save Changes
</Button>
        </Modal.Footer>
      </Modal>
    </>
  )

}

export default VidTrigg;