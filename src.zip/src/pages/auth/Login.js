import React, { useState, useContext, useEffect } from 'react';
import { connect } from 'react-redux';
import { Redirect, Link } from 'react-router-dom'

import { Container, Row, Col, Card, CardBody, Label, FormGroup, Button, Alert, InputGroup, InputGroupAddon } from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { Mail, Lock, User } from 'react-feather';

import { isUserAuthenticated } from '../../helpers/authUtils';
import Loader from '../../components/Loader';
import logo from '../../assets/images/logo.png';



import AuthContext from '../../context/auth/authContext';

const  Login = props => {
    const authContext = useContext(AuthContext);
    const { login, loading, error, clearErrors, isAuthenticated } = authContext;

    //   useEffect(() => {
    //     document.body.classList.add('authentication-bg'); 
    //     // Specify how to clean up after this effect:
    //     return function cleanup() {
    //         document.body.classList.remove('authentication-bg');
    //     };
    //   },[]);
    
      const [user, setUser] = useState({
        email: '',
        password: ''
      });

      const { email, password } = user;

    /**
     * Handles the submit
     */

    const onChange = e => setUser({ ...user, [e.target.name]: e.target.value });

    const handleValidSubmit = (event) => {
        // console.log(email,password)
        login({email, password},props.history);
        
    }

    /**
     * Redirect to root
     */
    const renderRedirectToRoot = () => {
        const isAuthTokenValid = isUserAuthenticated();
        if (isAuthTokenValid) {
            return <Redirect to='/' />
        }
    }

   
        const isAuthTokenValid = isUserAuthenticated();
        // console.log('isAuthTokenValid called form login ',isAuthTokenValid)
        return (
            <React.Fragment>

                {renderRedirectToRoot()}

                {( !isAuthTokenValid) && <div className="account-pages my-5">
                    <Container>
                        <Row className="justify-content-center">
                            <Col xl={10}>
                                <Card className="">
                                    <CardBody className="p-0">
                                        <Row>
                                            <Col md={6} className="p-5 position-relative">
                                                { /* preloader */}
                                                {loading && <Loader />}

                                                <div className="mx-auto mb-5">
                                                    <a href="/">
                                                        <img src={logo} alt="" height='24' />
                                                        <h3 className="d-inline align-middle ml-1 text-logo  ">Beamfox <span className=""></span></h3>
                                                    </a>
                                                </div>

                                                <h6 className="h5 mb-0 mt-4">Welcome back!</h6>
                                                <p className="text-muted mt-1 mb-4">Enter your email and password to access admin panel.</p>


                                                {error && <Alert color="danger" isOpen={error ? true : false}>
                                                    <div>{error}</div>
                                                </Alert>}

                                                <AvForm onValidSubmit={handleValidSubmit} className="authentication-form">
                                                    <AvGroup className="">
                                                        <Label for="email">Email</Label>
                                                        <InputGroup>
                                                            <InputGroupAddon addonType="prepend">
                                                                <span className="input-group-text">
                                                                    <User className="icon-dual" />
                                                                </span>
                                                            </InputGroupAddon>
                                                            <AvInput type="text" name="email" id="email" placeholder="Enter your email" value={email} required onChange={onChange} />
                                                        </InputGroup>
                                                        
                                                        <AvFeedback>This field is invalid</AvFeedback>
                                                    </AvGroup>


                                                    <AvGroup className="mb-3">
                                                        <Label for="password">Password</Label>
                                                        <Link to="/account/forget-password" className="float-right text-muted text-unline-dashed ml-1">Forgot your password?</Link>
                                                        <InputGroup>
                                                            <InputGroupAddon addonType="prepend">
                                                                <span className="input-group-text">
                                                                    <Lock className="icon-dual" />
                                                                </span>
                                                            </InputGroupAddon>
                                                            <AvInput type="password" name="password" id="password" placeholder="Enter your password" value={password} required  onChange={onChange}/>
                                                        </InputGroup>
                                                        <AvFeedback>This field is invalid</AvFeedback>
                                                    </AvGroup>
                                                    
                                                    <FormGroup className="form-group mb-0 text-center">
                                                        <Button color="primary" className="btn-block">Log In</Button>
                                                    </FormGroup>

                                                </AvForm>
                                            </Col>

                                            <Col md={6} className="d-none d-md-inline-block">
                                                <div className="auth-page-sidebar">
                                                    <div className="overlay"></div>
                                                    {/* <div className="auth-user-testimonial">
                                                        <p className="font-size-20 font-weight-bold text-white mb-1">Loved by 100s of recrutiers!</p>
                                                        <p className="lead">"It's a elegent . I love it very much!"</p>
                                                        {/* <p>-Admin User</p> 
                                                    </div> */}
                                                </div>
                                            </Col>
                                        </Row>

                                        
                                    </CardBody>
                                </Card>
                            </Col>
                        </Row>

                        <Row className="mt-3">
                            <Col className="col-12 text-center">
                                <p className="text-muted">Don't have an account? <Link to="/account/companyRegister1" className="text-primary font-weight-bold ml-1" >Sign Up</Link></p>
                            </Col>
                        </Row>

                    </Container>
                </div>}
            </React.Fragment>
        )
    };




export default Login;