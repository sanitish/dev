const AccessToken = require('twilio').jwt.AccessToken;
const VideoGrant = AccessToken.VideoGrant;
require('dotenv').config();

const MAX_ALLOWED_SESSION_DURATION = 14400;
const twilioAccountSid = process.env.TWILIO_ACCOUNT_SID;
const twilioApiKeySID = process.env.TWILIO_API_KEY_SID;
const twilioApiKeySecret = process.env.TWILIO_API_KEY_SECRET;


//=========================
const accountSid = 'AC0e65c7830b7cee16f8d349a20f8713ec';
const authToken = 'e866a80f5dc209d85a26febc43e710dd';
const client = require('twilio')(accountSid, authToken);

const createRoom=async ({roomName})=>{
  var res=null;
  // console.log('name',roomName);
  
    const result = await client.video.rooms
            .create({
               recordParticipantsOnConnect: true,
               statusCallback: 'http://48edcedbce63.ngrok.io/MessageStatus',
               type: 'group-small',
               uniqueName: {roomName}
             })
             
            // console.log('yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy',result);
            
           return result;  
        
       }

//========================




const videoCall = async (identity, roomName) =>{
        const token = new AccessToken(twilioAccountSid, twilioApiKeySID, twilioApiKeySecret, {
          ttl: MAX_ALLOWED_SESSION_DURATION
        });

        let r = await createRoom ({roomName})
        // console.log(r,"video call");


        
      if(r){
          token.identity = identity;
        
        
          const videoGrant = new VideoGrant({room:roomName});
          // console.log(r.sid,"sidsid");
          
          token.addGrant(videoGrant);
          console.log("videoGrant",videoGrant);
          
  
         console.log(token.toJwt());
          // console.log(`issued token for ${identity} in room ${roomName}`);
          return(token.toJwt());
        
      }

       

}

module.exports = videoCall;