import React, { useState, useContext, useEffect } from 'react';
import { connect } from 'react-redux';
import { Redirect, Link ,useParams} from 'react-router-dom'
import jwtDecode from 'jwt-decode';

import { Container, Row, Col, Card, CardBody, Label, FormGroup, Button, Alert, InputGroup, InputGroupAddon, CustomInput } from 'reactstrap';
import { AvForm, AvGroup, AvInput, AvFeedback } from 'availity-reactstrap-validation';
import { Mail, Lock, User, Eye, Phone } from 'react-feather';

import { isUserAuthenticated } from '../../helpers/authUtils';
import Loader from '../../components/Loader';
import logo from '../../assets/images/logo.png';



import AuthContext from '../../context/auth/authContext';

const  Register = props => {
    const authContext = useContext(AuthContext);
    const { register, loading, error, clearErrors, isAuthenticated } = authContext;


    
      let {id} = useParams();
     console.log(id)
     let token =  jwtDecode(id);

     const [user, setUser] = useState({
         userId:token.user,
        companyName:token.companyName,
        email: token.email,
        password: '',
        designation:(token.designation)?token.designation:'',
        name:(token.name)?token.name:'',    
        contactNumber:(token.contactNumber)?token.contactNumber:''
      });

      const { companyName, email, password,role ,designation,name,contactNumber,userId} = user;

    /**
     * Handles the submit
     */

    const onChange = e => setUser({ ...user, [e.target.name]: e.target.value });
    //   console.log(user)
    const handleValidSubmit = (event) => {
        register({email, password,designation,name,companyName,contactNumber,userId}, props.history);
        // console.log(user)
  
    }

    /**
     * Redirect to root
     */
    const renderRedirectToRoot = () => {
        const isAuthTokenValid = isUserAuthenticated();
        if (isAuthTokenValid) {
            return <Redirect to='/' />
        }
    }

   
        const isAuthTokenValid = isUserAuthenticated();
        return (
            <React.Fragment>

                {renderRedirectToRoot()}

                {(!isAuthTokenValid) && <div className="account-pages mt-5 mb-5">
                    <Container>
                        <Row className="justify-content-center">
                            <Col xl={10}>
                                <Card className="">
                                    <CardBody className="p-0">
                                        <Row>
                                            <Col md={6} className="p-5 position-relative">
                                                { /* preloader */}
                                                {loading && <Loader />}

                                                <div className="mx-auto mb-5">
                                                    <a href="/">
                                                        <img src={logo} alt="" height="24" />
                                                        <h3 className="d-inline align-middle ml-1 text-logo text-primary">Beamfox</h3>
                                                    </a>
                                                </div>

                                                <h6 className="h5 mb-0 mt-4">Welcome back!</h6>
                                                <p className="text-muted mt-1 mb-4">Enter your email address and password to access admin panel.</p>


                                                {error && <Alert color="danger" isOpen={error ? true : false}>
                                                    <div>{error}</div>
                                                </Alert>}

                                                <AvForm onValidSubmit={handleValidSubmit} className="authentication-form">
                                                    <AvGroup className="">
                                                        <Label for="companyName">Company Name</Label>
                                                        <InputGroup>
                                                            <InputGroupAddon addonType="prepend">
                                                                <span className="input-group-text">
                                                                    {/* <User className="icon-dual" /> */}
                                                                    <i className="uil uil-building mr-1"></i>
                                                                </span>
                                                            </InputGroupAddon>
                                                            <AvInput type="text" name="companyName" id="companyName"value={companyName} placeholder="Shreyu N" required disabled className="bg-light"/>
                                                        </InputGroup>

                                                        <AvFeedback>field is invalid</AvFeedback>
                                                    </AvGroup>

                                                    <AvGroup className="">
                                                        <Label for="email">Email</Label>
                                                        <InputGroup>
                                                            <InputGroupAddon addonType="prepend">
                                                               <span className="input-group-text">
                                                                    <Mail className="icon-dual" />
                                                                </span>
                                                            </InputGroupAddon>
                                                            <AvInput type="email" name="email" id="email" value={email} placeholder="hello@coderthemes.com" required  disabled className="bg-light"/>
                                                        </InputGroup>

                                                        <AvFeedback>field is invalid</AvFeedback>
                                                    </AvGroup>
                                                    <AvGroup className="mb-3">
                                                        <Label for="name">name</Label>
                                                        <InputGroup>
                                                            <InputGroupAddon addonType="prepend">
                                                                <span className="input-group-text">
                                                                <User className="icon-dual" />
                                                                </span>
                                                            </InputGroupAddon>
                                                            <AvInput type="name" name="name" id="name" value={name} placeholder="Enter your name" required onChange={onChange}/>
                                                        </InputGroup>
                                                        <AvFeedback>field is invalid</AvFeedback>
                                                    </AvGroup>


                                                    <AvGroup className="">
                                                        <Label for="role">Designation</Label>
                                                        <InputGroup>
                                                            <InputGroupAddon addonType="prepend">
                                                                <span className="input-group-text">
                                                                    <Eye className="icon-dual" />
                                                                
                                                                </span>
                                                            </InputGroupAddon>
                                                            <AvInput type="text" name="designation" id="designation" value={designation} placeholder="your role in compamy" required onChange={onChange}/>
                                                        </InputGroup>

                                                        <AvFeedback>field is invalid</AvFeedback>
                                                    </AvGroup>
                                         
                                                    <AvGroup className="">
                                                        <Label for="contactNumber">Contact Number</Label>
                                                        <InputGroup>
                                                            <InputGroupAddon addonType="prepend">
                                                                <span className="input-group-text">
                                                                    <Phone className="icon-dual" />
                                                                
                                                                </span>
                                                            </InputGroupAddon>
                                                            <AvInput type="text" name="contactNumber" id="contactNumber" value={contactNumber} placeholder="your mobile number"    onChange={onChange}/>
                                                        </InputGroup>

                                                        <AvFeedback>field is invalid</AvFeedback>
                                                    </AvGroup>

                                                       
                                                       
                                         

                                       
                                                       
                                                       
                                                    <AvGroup className="mb-3">
                                                        <Label for="password">Password</Label>
                                                        <InputGroup>
                                                            <InputGroupAddon addonType="prepend">
                                                                <span className="input-group-text">
                                                                    <Lock className="icon-dual" />
                                                                </span>
                                                            </InputGroupAddon>
                                                            <AvInput type="password" name="password" id="password" value={password} placeholder="Enter your password" required onChange={onChange}/>
                                                        </InputGroup>
                                                        <AvFeedback>field is invalid</AvFeedback>
                                                    </AvGroup>

                                           
                                       
                                                    <AvGroup check className="mb-4">
                                                        <CustomInput type="checkbox" id="terms" defaultChecked="true" className="pl-1" label="I accept Terms and Conditions" />
                                                    </AvGroup>

                                                    <FormGroup className="form-group mb-0 text-center">
                                                        <Button color="primary" className="btn-block">Sign Up</Button>
                                                    </FormGroup>
                                                </AvForm>
                                            </Col>

                                            <Col md={6} className="d-none d-md-inline-block">
                                                <div className="auth-page-sidebar">
                                                    <div className="overlay"></div>
                                                    <div className="auth-user-testimonial">
                                                        <p className="font-size-24 font-weight-bold text-white mb-1">I simply love it!</p>
                                                        <p className="lead">"It's a elegent templete. I love it very much!"</p>
                                                        <p>- Admin User</p>
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </CardBody>
                                </Card>
                            </Col>
                        </Row>

                        <Row className="mt-1">
                            <Col className="col-12 text-center">
                                <p className="text-muted">Already have an account? <Link to="/account/login" className="text-primary font-weight-bold ml-1">Sign In</Link></p>
                            </Col>
                        </Row>
                    </Container>
                </div>}
             </React.Fragment>
        )
    };




export default Register;