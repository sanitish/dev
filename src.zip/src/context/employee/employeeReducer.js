import {

  ADD_TASK,
  GET_TASK,
  SET_LOADING,
  LOGIN_FAIL,
  ADD_EMPLOYEE,
  GET_EMPLOYEE
} from '../types';

export default (state, action) => {
  switch (action.type) {

    case ADD_TASK:
      return {
        ...state,
        tasks: [action.payload,...state.tasks ],
        loading: false,
        error:null
      };
      case GET_TASK:
        return {
          ...state,
          tasks: action.payload,
          loading: false,
          error:null
        };

        case GET_EMPLOYEE:
          return {
            ...state,
            employee: action.payload,
            loading: false,
            error:null
          };
        case ADD_EMPLOYEE:
          return {
            ...state,
            employee: [action.payload,...state.employee ],
            loading: false,
            error:null
          };


    case LOGIN_FAIL:
   
        return { ...state, error: action.payload, loading: false };



      case SET_LOADING:
        return{
          ...state,
          loading:true
        }
    default:
      return state;
  }
};
