const express = require('express');
const app = express();
const cors = require('cors');
const path = require('path');
const bodyParser = require('body-parser');

const errorHandler = require('./middleware/error');
const handleCron = require('./utils/cron');
const mongoose = require('mongoose');
// const beta = 'mongodb+srv://nitish:sanitsum@beamfox-beta-crngf.mongodb.net/beamfox_beta?retryWrites=true&w=majority'
const db = 'mongodb+srv://sanitish:sanitsum@stayspace-o9cle.mongodb.net/test?retryWrites=true&w=majority';
mongoose.connect(db, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,  
    useUnifiedTopology: true,
  })
  .then(()=>console.log('db connected...'))
  .catch((err)=>console.log(err));

//inti middleware
app.use(cors());
app.use(express.json({extended:false}));
app.use(bodyParser.urlencoded({ extended: true }));






// app.get('*', (_, res) => res.sendFile(path.join(__dirname, 'client/videoBuild/index.html')));


//load routes




app.use('/api/company',require('./routes/companies'));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/user',require('./routes/users'));
app.use('/api/candidate',require('./routes/candidate'));

app.use('/api/workflow',require('./routes/workflow'));
app.use('/api/workflowProcess',require('./routes/workflowProcess'));

app.use('/api/mixedForm',require('./routes/mixedForm'));
app.use('/api/task',require('./routes/task'));

app.use('/api/sendgrid',require('./routes/sendgridAPIs'));
app.use('/',require('./routes/googleAPIs'));




app.post('/MessageStatus', (req,res,next) => {
 // console.log(req);
 console.log(req.body)
  const messageSid = req.body.MessageSid;
  const messageStatus = req.body.MessageStatus;

  console.log(`SID: ${messageSid}, Status: ${messageStatus}`);

  res.sendStatus(200);
});
// handleCron();
//error handler
app.use(errorHandler);


//load client code..
app.use(express.static('client/build'));
app.use(express.static('client/videoBuild'));
//load client code..
app.get('/video', (req, res) =>
res.sendFile(path.resolve(__dirname, 'client', 'videoBuild', 'index.html'))
);

app.get('*', (req, res) =>
  res.sendFile(path.resolve(__dirname, 'client', 'build', 'index.html'))
);










 

   





const PORT = process.env.PORT||8080 ;
app.listen(PORT,()=>{
    console.log(`server is list enig on port ${PORT}`)
})