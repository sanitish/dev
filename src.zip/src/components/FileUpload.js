import React,{useState} from 'react';
import { Row, Col, Card, CardBody } from 'reactstrap';
import axios from 'axios';
import PageTitle from './PageTitle';
import FileUploader from './FileUploader';

import { Modal ,Button} from 'react-bootstrap';
import Loader from '../components/Loader';


const FileUpload = (props) => {
  console.log('nitishsdfsdfsd',props)
    const [show, setShow] = useState(false);
    const [error, setError] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleClose = () =>{
      
      setShow(false);
      
    } 
    const handleShow = () => setShow(true);
const onFileUploadd = async(file)=>{
    console.log('uahi hai' ,file);
    try{
      setLoading({loading:true})
const config = {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  };
  console.log(file)
  let formData = new FormData()
  formData.append('file', file[0])
  formData.append('candidate', props.props.match.params.id)
  console.log("fileupload",formData,config);

  const res = await axios.post('/api/user/uploadFile',formData,config);
  // setShow(false)
  setLoading(false)

  console.log('nitish response',res.data.data)
  props.reloadHandler(res.data.data);
}catch(err){
  setLoading(false)
 // setError(err.response.data);
    console.log(err);
}

}

    return (
        <>
        <button className="btn btn-sm btn-primary" onClick={handleShow}><i className='uil uil-plus mr-1'></i>Upload File</button>

        <Modal show={show} onHide={handleClose}>
          <Modal.Header closeButton>
            <Modal.Title>Create Task</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          {loading && <Loader/>}

          <Row>
                <Col>
                    <Card>
                        <CardBody>
                            <h4 className="header-title mt-0 mb-1">Dropzone File Upload</h4>
                            <p className="sub-header">DropzoneJS is an open source library that provides drag and drop file uploads with image previews.</p>

                            <FileUploader
                                onFileUpload={files => {
                                    onFileUploadd(files);
                                }}
                            />
                        </CardBody>
                    </Card>
                </Col>
            </Row>    
          </Modal.Body>
  
  
          {/* <Link className="btn text-right" to="/">continue</Link> */}
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
  </Button>
            {/* <Button variant="primary" onClick={onSubmit}>
              Save Changes
  </Button> */}
          </Modal.Footer>
        </Modal>
      </>
   
            );
};

export default FileUpload;
