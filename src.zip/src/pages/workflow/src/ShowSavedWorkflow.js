import React, {Component} from 'react';
import axios from 'axios';
import WorkflowLibrary from './workflowlibrarycomp';
import {Redirect} from 'react-router-dom';
import setAuthToken from '../../../utils/setAuthToken';
class ShowSavedWorkflows extends Component{
    state={
        saveddata:[            
        ],
        visible:false,
        selected: false,
        index: null
    }

    componentWillMount(){
        setAuthToken()
        axios.get("/api/workflow/getWorkflow")
            .then(response=>{
              //  console.log("fetcheddata",response.data.data);
                    response.data.data.map(key=>{
                    let indiwork=key;
                //    console.log("indiworkflow",indiwork)
                    this.setState(prevState=>({
                        saveddata: [...prevState.saveddata,{...indiwork}]
                    }))
                 //   console.log("ooooooooo",this.state.saveddata)
                })})
    }
//perfect
    toggle=(index)=>{
        this.setState({selected:true, index:index
        })
    }

        clickHandler=()=>{
            this.setState({visible:false, selected: false})
        }

        handleOptionChange = changeEvent => {
            this.setState({
              index: changeEvent.target.value
            });
          };
    
    
          handleFormSubmit = formSubmitEvent => {
            formSubmitEvent.preventDefault();
            this.setState({ selected: true, visible: false})
            //console.log("You have submitted:", this.state.index);
          }; 

    render(){
      //  console.log(this.state.visible);
    let button=null;
        button=(
            this.state.saveddata.map((indivworkflow, index)=>{
         //   console.log(indivworkflow);
            let newworkarray=indivworkflow.workflowItems;
            let newworkname=indivworkflow.workflowName;
            let totaldays=0;
            let totalactions=newworkarray.length;
            let createdBy = indivworkflow.createdBy.name;
            {newworkarray.map((indivObj)=>{
                    const newindiobj= {...indivObj};
                    if(Number(newindiobj.dayNo)>totaldays)
                        totaldays=Number(newindiobj.dayNo);
                })}   
                return  (<div className="form-check">
                                    {index==0?<h3 style={{display:'block',marginLeft:'30%'}}>Saved Workflows</h3>:null}
                                <label style={{cursor:'pointer'}} onClick={()=>{this.toggle(index)}}>
                                <WorkflowLibrary  newworkname={newworkname} totalactions={totalactions} totaldays={totaldays} createdBy={createdBy} />
                                </label>
                            </div>
                )
                        })
        )
        if(this.state.selected) {
            let newworkarray=this.state.saveddata[this.state.index].workflowItems;
            let newworkname=this.state.saveddata[this.state.index].workflowName;
           return <Redirect to={{
               pathname:"/saved/select",
               state:{newworkarray:newworkarray,newworkname:newworkname}}}/>
        }
    
return(<div style={{marginTop:'10%', marginLeft:'10%'}}>{button}</div>
            );
    }
}

    export default ShowSavedWorkflows;