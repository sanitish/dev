import React, {useState, useEffect,useContext} from 'react';
import {
    Row, Col, Card, CardBody, UncontrolledTooltip, CustomInput
} from 'reactstrap';
import classNames from 'classnames';
import axios from 'axios';
import { allTasks } from './Data';
import TaskForm from '../../tasks/TaskForm';
import         setAuthToken from '../../../utils/setAuthToken';
import employeeContext from '../../../context/employee/employeeContext';

const TaskSummary = (task) => {
    const EmployeeContext = useContext(employeeContext)
    const onChange = () =>{
        EmployeeContext.editTask({isCompleted:!task.isCompleted,id: task._id})
    }
    const clickHandler = task.onClickHandler || {};
let color='',background='';
                                if(task.priority === 'high'){
                                    color='red';background='lightcoral'
                                }
                                else if(task.priority === 'medium'){
                                    color='blue';background="lightskyblue"}
                                else if(task.priority === 'low'){
                                    color='green';background="palegreen"}
    return <React.Fragment>
        <Row className={classNames('justify-content-sm-between', 'border-bottom', 'mt-2', 'pt-2', 'cursor-pointer')}>
            <Col lg={6} className="mb-lg-0">
                <CustomInput type="checkbox" id={`task-${task._id}`} label={task.taskName} defaultChecked={task.isCompleted} onChange={onChange}></CustomInput>
            </Col>
            <Col lg={6}>
                <div className="d-sm-flex justify-content-between">
                    <div>
                        <p>{task.taskDescription}</p>
                    </div>

                    <div className="mt-3 mt-sm-0">
                        <ul className="list-inline font-13 text-sm-right">
                            <li className="list-inline-item pr-1"><i className='uil uil-schedule font-16 mr-1'></i>{task.date}</li>
                            <li className="list-inline-item pr-1">
                                <span style={{color:color, backgroundColor:background}}>{task.priority}</span>
                            </li> 
                            
                        </ul>
                    </div>
                </div>
            </Col>
        </Row> 
    </React.Fragment>
}

const Tasks=(props)=>{
    console.log(props);
    
    const [taskarray, setTaskarray]=useState([]);
    useEffect(()=>{
        setAuthToken();
        axios.get(`/api/task/getMyTasks?candidate=${props.props.match.params.id}`)
            .then(response=>{
                response.data.data.map(inditask=>{
                    let newinditask=inditask;
                    setTaskarray(oldArray=>[...oldArray,{...newinditask}])                   
                })
                })
    },[])

    const reload=(task)=>{
        setTaskarray(oldArray=>[...oldArray,{...task}])
    }
    return (<React.Fragment>
        <h5 className="">Tasks       <div className ="text-right">  <TaskForm reloadHandler={reload} id={props.props.match.params.id} candidateName={props.candidateName&&props.candidateName} /></div>
</h5>
        <Card className="mb-0 shadow-none">
            <CardBody>
                {taskarray.map((task, index) => {
                    // console.log(task[0])
                return <TaskSummary {...task} key={index} />
                })}
            </CardBody>
        </Card>
    </React.Fragment>)
}


export default Tasks;