import { createContext } from 'react';

const employeeContext = createContext();

export default employeeContext;
