import React,{useState} from 'react';
import { Card, CardBody, Row, Col, Button } from 'reactstrap';


const MessageTemplates = () => {
const [messages,setMessages]=useState([
    `Hello Trudy, here’s a link to the corporate office, where your first week’s training will be held. Have fun tomorrow! https://beamfox.io/txthq`,
    `We’re so excited to have you join our team, Carla! We made this welcome video for you with staff intros and a campus tour – enjoy! https://beamfox.io/textwel`,
    `Lisabeth – Welcome to Beamfox! Here’s a link to your schedule for this first week (https://beamfox.io/m9ph5uj). If you have any questions, don’t hesitate to text or call me! — Suhail`,
    `Hi, it’s Brad at Beamfox, and I’ll be your staff trainer this week! Do you have any questions I can help you out with before your first day?`,
    `Hi John, just a reminder to bring your social security card, current picture ID, and completed paperwork along with you on Tues.`,
    `Sparla, which compliance session would work best for you: M 9-1, M 1-5, or W 11-3?`,
    `Hi Bernice! Just a reminder that you still need to complete your workplace behavior module before the end of the month. Here’s the link: https://beamfox.com/txtmb`,
    `Lydia – have you heard about the Beamfox Knowledge series that starts next Wed.? I think it’d really help you with your developer questions.`,
    `Ty, don’t miss out on your team’s sales training on Fri! Text me if you’ll be there – and with any lunch requests`,
    `We Know you’re busy, just wanted to confirm you’ll be at the sales training tomorrow – lots of tips to help you hit your goals!`,
    `The Lock Down Leads training is going on run in the conference room – and there’s pizza. Come on up!`,
    `Betsy, tomorrow is the last day to opt-in for dental and vision coverage. You mentioned you were interested in this – can I help you get signed up?`,
    `Renauldo – you mentioned you wanted to change your 401K deductions this quarter. Deadline is next Tuesday.`,
    `Hey team! Our partner benefits have expanded – join Gold’s Gym at a 25% discount with your employee id. `,
    `Hi Bob – I hope you’re having a good summer! We haven’t heard from you for a bit, so I thought I’d check in.`,
    `Are you still interested in remaining active on our freelance developers list? If so, I have a position that might be perfect for you.`
]);
    return (
        <React.Fragment>
            <Card>
                <CardBody>
                    <h2 className="mb-3 mt-0 header-title">Message Templates</h2>
                    <Row className="bg-light p-3">
                    
                        {messages.map(message=>(
                        <div style={{border:'2px solid lightskyblue',borderRadius:'15px',padding:'10px', margin:'30px 10px'}} >
                            <Card>
                                <Row className="no-gutters align-items-center">
                                    <Col>
                                        <CardBody>
                                            <h5 className="card-text text-muted">{message}</h5>
                                            <p className="card-text"><small className="text-muted">Last updated 3 mins ago</small></p>
                                        </CardBody>
                                    </Col>
                                </Row>
                            </Card></div>))}
                    </Row>
                </CardBody>
            </Card>
        </React.Fragment>
    );
};

export default MessageTemplates;
