// @flow
import jwtDecode from 'jwt-decode';
import { Cookies } from 'react-cookie';

/**
 * Checks if user is authenticated
 */
const isUserAuthenticated = () => {
    const user =   getLoggedInUser();
    console.log(user)
    if (user==0) {
        console.log('ye baat    ')
        return false;
    }
    else if(user){
        const currentTime = Date.now() / 1000;
        if (user.exp < currentTime) {
            console.warn('access token expired');
            return false;
        } else {
            return true;
        }
    }

};

/**
 * Returns the logged in user
 */
const  getLoggedInUser = async () => {
    const cookies = new Cookies();
    const token = await cookies.get('token');
    console.log(token)
    if(token){
        const user = jwtDecode(token);
        console.log(user)

        return user;

    }else {
        console.log('else called')
        return 0;
    }

};

const  getMe =async () => {
    const cookies = new Cookies();
    const me =await cookies.get('user');
    if(me){
        return me;

    }else{
        return 0;
    }

};


export { isUserAuthenticated, getLoggedInUser,getMe };
