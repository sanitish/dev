import React, { Component } from 'react';
import Input from './input';
import axios from 'axios';
import classes from './workflow.module.css';


class ShowForm extends Component{
    state={
        formdata:[],
        stateform:[],
        orderForm:{
            Textfield:{
                elementType: 'input',
                elementConfig:{
                    type: 'text',
                    placeholder: 'Text Field'
                },
                value: '',
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'',
                id:'Textfield'
            },
            Number: {
                elementType: 'input',
                elementConfig:{
                    type: 'number',
                    placeholder: 'Number'
                },
                value: '',
                validation:{
                    required: true,
                    minLength: 1,
                    maxLength: 10
                },
                valid: false,
                touched: false,
                label:'',
                id:'Number'
            },
            Date: {
                elementType: 'input',
                elementConfig:{
                    type: 'date',
                    placeholder: 'Date',
                    min:"2020-01-01",
                    max:"2020-12-31"
                },
                value:"2020-05-30",
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'',
                id:'Date'
            },
            Checkbox:{
                elementType: 'input',
                elementConfig:{
                    type: 'checkbox',
                    placeholder: 'Checkbox'
                },
                value: 'I agree',
                validation:{
                    required: true
                },
                valid: false,
                touched: false,
                label:'',
                id:'Checkbox'
            },
            Dropdown:{
                elementType: 'select',
                elementConfig:{
                    type: 'dropdown',
                    options:[
                        {value:'Yes', displayValue: 'Yes'},
                        {value:'No', displayValue: 'No'},
                    ]
                },
                value: 'Yes',
                valid: true,
                validation: {},
                label:'',
                id:'Dropdown'

            }
        },
        formIsValid: false
    }


    componentWillMount (){
        //  this.setState({isMounted:true})
        axios.get("/api/mixedForm/getMixedForm")
            .then(response=>{
                console.log("fetcheddata",response.data.data);
                response.data.data.map(inditask=>{
                    let newinditask=inditask;
                this.setState(prevState=>({
                    formdata: [...prevState.formdata,{...newinditask}]
                }))                    
                })
                })
            }

    render(){
        const formElementArray=[];
        console.log("formdataarray",this.state.formdata);

        this.state.formdata.map((indform, id)=>{
            if(id==5){
                let formElement=indform.formElements;
                for(let key in formElement){
                    let indiinput=formElement[key];
                    let id=indiinput.id;
                    let label=indiinput.label;
                    let formdetails=this.state.orderForm[id];
                    formdetails.label=label;
                    formElementArray.push(formdetails)}}})
        console.log("aa5aaa",formElementArray);
        // this.setState({stateform:formElementArray});
                
        let form=(
                    <form onSubmit={this.orderHandler}>
                    {formElementArray.map(formdetails=>(<div>
                        <label style={{float:'left'}}>{formdetails.label}</label>
                        <Input
                                // key={formdetails.id}
                                elementType={formdetails.elementType}
                                elementConfig={formdetails.elementConfig}
                                value=''
                                invalid={!formdetails.valid}
                                shouldValidate={formdetails.validation}
                                touched={formdetails.touched}
                                // changed={(event)=>this.inputchangeHandler(event,formdetails.id)}
                            />
                    </div>
                        
                        ))}
                        <button btnType="Success" disabled={!this.state.formIsValid}>ORDER</button>                    
             </form>
        )

        return(
            <div className={classes.Content}>
                <div className={classes.ContactData}>   
                {form}
                </div>
            </div>
        )
    }
}

export default ShowForm