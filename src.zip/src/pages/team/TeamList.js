import React, { useContext, useEffect } from 'react';
import { Row, Col, Card, CardBody, Input,Alert, UncontrolledDropdown, DropdownMenu, DropdownItem, DropdownToggle } from 'reactstrap';
import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider, { Search, CSVExport } from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import { Link } from 'react-router-dom';
import PageTitle from '../../components/PageTitle';
import Avatar from 'react-avatar';
import classNames from 'classnames';
import LinesEllipsis from 'react-lines-ellipsis'


import Loader from '../../components/Loader';



import responsiveHOC from 'react-lines-ellipsis/lib/responsiveHOC'
import employeeContext from '../../context/employee/employeeContext';
const ResponsiveEllipsis = responsiveHOC()(LinesEllipsis)







const TeamList = () => {

    const EmployeeContext = useContext(employeeContext);

    const { addEmployee, loading, error, employee, getEmployees } = EmployeeContext;
    useEffect(() => {
        console.log('emoloyess')
       getEmployees()

    }, []);


    console.log(employee)
    const records = employee.map(({ _id, name, email, role, designation, contactNumber,state }, i) => {
        return (
            {

                id: _id,
                role: (designation)?designation:'N/A',
                phone: (contactNumber)?contactNumber:'N/A',
                state:
                    <div className={classNames(
                         'text-capitalize',
                        {
                            'text-info': state === 'invited',
                            'text-success': state === 'active',
                            'text-danger':state === 'inactive',
                        }
                )}>{state}</div>,
                email:
                
                    <ResponsiveEllipsis
                        text={email}
                        maxLine='1'
                        ellipsis='...'
                        trimRight basedOn='letters'/>
                    ,
                name:
                    <Row className="align-items-center">
                        <div className="col-2">
                            <Link to="#" className="text-muted d-inline-block p-0 m-0" >
                                <Avatar name={name} size="24" round={true} />
                            </Link>
                        </div>
                        <div className="col-10 align-items-center mb-0">
                            <ul className="list-inline mb-0 mt-0 p-0">
                                <li className="list-inline-item pr-2">
                                {name}
                                </li>
                                <li className={classNames(
                                    'badge', 'float-right','text-capitalize',
                                    {
                                        'badge-success': role === 'admin',
                                        'badge-danger': role === 'superAdmin',
                                        'badge-info': role === 'Planned',
                                    }
                                )}>{role}
                                </li>

                            </ul>
                        </div>
                    </Row>

            }
        );
    })


    const columns = [
        {
            dataField: 'name',
            text: '#  Name',
            sort: false,
            headerStyle: (colum, colIndex) => {
                return { width: '300px', textAlign: 'left' };
              }
        },
        {
            dataField: 'email',
            text: 'Email',
            sort: false,
        },
        {
            dataField: 'phone',
            text: 'Phone Number',
            sort: false,
            headerStyle: (colum, colIndex) => {
                return { width: '150px', textAlign: 'left' };
              }
        },

        {
            dataField: 'role',
            text: 'Role',
            sort: false,

        },
        {
            dataField: 'state',
            text: 'State',
            sort: false,
            headerStyle: (colum, colIndex) => {
                return { width: '100px', textAlign: 'left' };
              }
        },
    ];

    const defaultSorted = [
        {
            dataField: 'id',
            order: 'asc',
        },
    ];

    const sizePerPageRenderer = ({ options, currSizePerPage, onSizePerPageChange }) => (
        <React.Fragment>
            
            <label className="d-inline mr-1">Show</label>
            <Input type="select" name="select" id="no-entries" className="custom-select custom-select-sm d-inline col-1"
                defaultValue={currSizePerPage}
                onChange={(e) => onSizePerPageChange(e.target.value)}>
                {options.map((option, idx) => {
                    return <option key={idx}>{option.text}</option>
                })}
            </Input>
            <label className="d-inline ml-1">entries</label>
        </React.Fragment>
    );



    const selectRow = {
        mode: 'checkbox',
        clickToSelect: true,
        style: { backgroundColor: '#727cf5', color: '#fff' },
    };

    const coloumWidth = {
        headerStyle: (colum, colIndex) => {
            return { width: '1180px', textAlign: 'right' , backgroundColor: '#727cf5', color: '#fff'};
          }
    }

    const customTotal = (from, to, size) => (
        <span className="react-bootstrap-table-pagination-total ml-4">
            Showing {from} to {to} of {size} Results
        </span>
    );
    const paginationOptions = {
        paginationSize: 5,
        pageStartIndex: 1,
        firstPageText: 'First',
        prePageText: 'Back',
        nextPageText: 'Next',
        lastPageText: 'Last',
        nextPageTitle: 'First page',
        prePageTitle: 'Pre page',
        firstPageTitle: 'Next page',
        lastPageTitle: 'Last page',
        showTotal: true,
        paginationTotalRenderer: customTotal,
        sizePerPageRenderer: sizePerPageRenderer,
        sizePerPageList: [
            {
                text: '5',
                value: 5,
            },
            {
                text: '10',
                value: 10,
            },
            {
                text: '25',
                value: 25,
            },
            {
                text: 'All',
                value: employee.length,
            },
        ], // A numeric array is also available. the purpose of above example is custom the text
    };
    return (
        <React.Fragment>

            <Row className="page-title">
                <Col md={3} xl={6}>
                    <h4 className="mb-1 mt-0">Team Managment</h4>
                </Col>
                <Col md={9} xl={6} className="text-md-right">
                    <div className="mt-4 mt-md-0">
                        <Link to="/apps/addTeam" type="button" className="btn btn-primary mr-4 mb-3  mb-sm-0"><i className="uil-plus mr-1"></i> Add Team</Link>
                    </div>
                </Col>
            </Row>

            {loading && <Loader />}
            {error && <Alert color="danger">  {error}</Alert >}

            <Row>
                <Col>
                    <Card>
                        <CardBody>
                            {/* <h4 className="header-title mt-0 mb-1">Multiple Row Selection</h4> */}
                            {/* <p className="sub-header">This table allowing selection of multiple rows</p> */}

                            <BootstrapTable
                                bootstrap4
                                keyField="id"
                                bordered={true}
                                data={records}
                                columns={columns}
                                pagination={paginationFactory(paginationOptions)}
                                selectRow={selectRow}
                                coloumWidth={coloumWidth}
                                wrapperClasses="table-nonResponsive"
                            />
                        </CardBody>
                    </Card>
                </Col>
            </Row>


        </React.Fragment>
    );


}
export default TeamList;
