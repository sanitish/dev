const mongoose = require('mongoose');

const FileUploadSchema = new mongoose.Schema({
file:{
    type:String
},
  
    uploadedBy: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: false
    },
    candidate: {
        type: mongoose.Schema.ObjectId,
        ref: 'Candidate',
        required: false
    },

    createdAt: {
        type: Date,
        default: Date.now
    }
})

module.exports = mongoose.model('File', FileUploadSchema);