import React, { useState, useContext, useEffect } from 'react';
    import {
        Row,
        Col,
        Card,
        CardBody,
        CustomInput,
        Form,
        FormGroup,
        Label,
        Input,
        FormText,
        Button,
        Alert
        
    } from 'reactstrap';
import Select from 'react-select';

import PageTitle from '../../components/PageTitle';

import AuthContext from '../../context/auth/authContext';


import Loader from '../../components/Loader';
import employeeContext from '../../context/employee/employeeContext';

const DefaultForm = (props) => {
    const EmployeeContext = useContext(employeeContext);
    const { addEmployee, loading, error,sendInviteToEmployee  } = EmployeeContext;

    const [user, setUser] = useState({
        email: '',
        name: ''
    });

    const [role,setRole] = useState(null);


      const { email, name } = user;

    /**
     * Handles the submit
     */
    const onChange = e => setUser({ ...user, [e.target.name]: e.target.value });
   const  handleChange = role => {
       // this.setState({ selectedOption });
    setRole(role)
        console.log(role );
      };
    const onSubmit = (e) => {
        e.preventDefault();
        console.log(email,name)
        //login({email, password});
        sendInviteToEmployee({email, name, role},props.props.history)
        
    }
    return (
        <>
                {loading && <Loader />}

{error && <Alert color="danger">  {error}</Alert >}

        <Card>
            <CardBody>
                <h4 className="header-title mt-0">Assemble the team</h4>
                <p className="text-muted">
                    Enter the name and email of your team. And send invite{' '}
                </p>


                <Form onSubmit={onSubmit}> 
                <FormGroup>
                        <Label for="exampleName2">Name</Label>
                        <Input type="name" name="name" id="exampleNmae2" placeholder="Enter name" value={name} onChange={onChange}/>
                        <FormText>We'll never share your name with anyone else.</FormText>
                    </FormGroup>

                    <FormGroup>
                        <Label for="exampleEmail2">Email</Label>
                        <Input type="email" name="email" id="exampleEmail2" placeholder="name@example.com" value={email} onChange={onChange}/>
                        <FormText>We'll never share your email with anyone else.</FormText>
                    </FormGroup>
                        <FormGroup>
                    <p className="mb-1 mt-3 font-weight-bold">Role Selection</p>
                   
                        <Select
                        
                        value={role}
                        onChange={handleChange}
                            isMulti={false}
                            options={[
                                { value: 'superAdmin', label: 'Super Admin' },
                                { value: 'admin', label: 'Admin' },
                            ]}
                            className="react-select"
                            classNamePrefix="react-select">
                            </Select>
                            <FormText>Select the role which you want to assign to the person.</FormText>

                            </FormGroup>
                    <Button color="primary" type="submit">
                        Send invitations    
                    </Button>
                    
                </Form>
            </CardBody>
        </Card>
        </>
    );
};




const TeamAddForm = (props) => {

    return (
        <React.Fragment>
            <Row className="page-title">
                <Col md={12}>
                <h4 className="mb-1 mt-0">Invite Team Members</h4>

                </Col>
                </Row>
        
            <Row>
                <Col lg={12} >
                <DefaultForm props={props}/>
                </Col>
            </Row>

        </React.Fragment>
    );
};
export default TeamAddForm;
