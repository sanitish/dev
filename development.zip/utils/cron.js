var CronJob = require('cron').CronJob;
const WorkflowProcessAction = require('../models/WorkflowProcessAction');
const {sendSms,sendEmail,sendCall,whatsApp} = require('../controllers/twilioWebhook');
const handleAction = async actions =>{
    actions.forEach( async (action) =>{
        switch (action.actionType) {
            case 'Sms':
                  var option = await{
                      body:{
                        candidateMobileNumber:action.candidate.candidateMobileNumber,
                        data:action.template,
                        candidate:action.candidate._id,
                        workflow:action.workflow
                      }
                   
                }
             await sendSms(option);
             action.processed = true
             await action.save()
                break;
            case 'Email':
                   var a = await{
                       body:{
                        email:action.candidate.candidateEmail,
                        subject:action.template,
                        message:action.template,
                        candidate:action.candidate._id,
                        workflow:action.workflow                       }
                     
                }
               await sendEmail(a);
                action.processed = true
                await action.save()
                break;
            case 'WhatsApp':
              await  whatsapp(action);
              action.processed = true
             await action.save()
                break;
            case 'Form':
                break;
            case 'Call':
                var option = await{
                    body:{
                      candidateMobileNumber:action.candidate.candidateMobileNumber,
                      candidateName:action.candidate.candidateName,

                      data:action.template,
                      candidate:action.candidate._id,
                      workflow:action.workflow
                    }
                 
              }
              await  sendCall(option);
              action.processed = true
             await action.save()
                break;
            default:
                console.log(action);

        }
    })
 
}
const handleCron = () =>{
var job = new CronJob('* * * * * *',async function() {
    
    const actions = await WorkflowProcessAction.find({doe: {$lte: Date.now}, processed:false}).populate('candidate');
    console.log('You will see this message every second',actions);
 handleAction(actions);
}, null, true, 'Asia/Kolkata');
job.start();
}

module.exports = handleCron;